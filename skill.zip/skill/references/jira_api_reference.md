# Jira Cloud REST API v3 — Endpoint Reference

Extracted from the official Atlassian Postman collection. All endpoints use Basic Auth (email + API token).

Base path: `{base_url}/rest/api/3/`

## Announcement banner (2 endpoints)

### Get announcement banner configuration
`GET /rest/api/3/announcementBanner`
> Returns the current announcement banner configuration.

### Update announcement banner configuration
`PUT /rest/api/3/announcementBanner`
> Updates the announcement banner configuration.
Body example:
```json
{
  "isDismissible": false,
  "isEnabled": true,
  "message": "This is a public, enabled, non-dismissible banner, set using the API",
  "visibility": "public"
}
```

## App data policies (2 endpoints)

### Get data policy for the workspace
`GET /rest/api/3/data-policy`
> Returns data policy for the workspace.

### Get data policy for projects
`GET /rest/api/3/data-policy/project`
> Returns data policies for the projects specified in the request.

## App migration (3 endpoints)

### Bulk update custom field value
`PUT /rest/atlassian-connect/1/migration/field`
> Updates the value of a custom field added by Connect apps on one or more issues.

### Bulk update entity properties
`PUT /rest/atlassian-connect/1/migration/properties/:entityType`
> Updates the values of multiple entity properties for an object, up to 50 updates per request. This operation is for use by Connect apps during app migration.

### Get workflow transition rule configurations
`POST /rest/atlassian-connect/1/migration/workflow/rule/search`
> Returns configurations for workflow transition rules migrated from server to cloud and owned by the calling Connect app.

## App properties (8 endpoints)

### Get app properties
`GET /rest/atlassian-connect/1/addons/:addonKey/properties`
> Gets all the properties of an app. The reserved key `connect_client_key_019cdff3-8bfb-71fe-9628-875b700aebb8` is not returned.

### Get app property
`GET /rest/atlassian-connect/1/addons/:addonKey/properties/:propertyKey`
> Returns the key and value of an app's property. The property key `connect_client_key_019cdff3-8bfb-71fe-9628-875b700aebb8`

### Set app property
`PUT /rest/atlassian-connect/1/addons/:addonKey/properties/:propertyKey`
> Sets the value of an app's property. Use this resource to store custom data for your app.

### Delete app property
`DELETE /rest/atlassian-connect/1/addons/:addonKey/properties/:propertyKey`
> Deletes an app's property.

### Get app property keys (Forge)
`GET /rest/forge/1/app/properties`
> Returns all property keys for the Forge app.

### Get app property (Forge)
`GET /rest/forge/1/app/properties/:propertyKey`
> Returns the value of a Forge app's property.

### Set app property (Forge)
`PUT /rest/forge/1/app/properties/:propertyKey`
> Sets the value of a Forge app's property.

### Delete app property (Forge)
`DELETE /rest/forge/1/app/properties/:propertyKey`
> Deletes a Forge app's property.

## Application roles (2 endpoints)

### Get all application roles
`GET /rest/api/3/applicationrole`
> Returns all application roles. In Jira, application roles are managed using the [Application access configuration](https://confluence.atlassian.com/x/3YxjL) page.

### Get application role
`GET /rest/api/3/applicationrole/:key`
> Returns an application role.

## Audit records (1 endpoints)

### Get audit records
`GET /rest/api/3/auditing/record`
> Returns a list of audit records. The list can be filtered to include items:

## Avatars (7 endpoints)

### Get system avatars by type
`GET /rest/api/3/avatar/:type/system`
> Returns a list of system avatar details by owner type, where the owner types are issue type, project, user or priority.

### Get avatars
`GET /rest/api/3/universal_avatar/type/:type/owner/:entityId`
> Returns the system and custom avatars for a project, issue type or priority.

### Load avatar
`POST /rest/api/3/universal_avatar/type/:type/owner/:entityId`
> Loads a custom avatar for a project, issue type or priority.

### Delete avatar
`DELETE /rest/api/3/universal_avatar/type/:type/owner/:owningObjectId/avatar/:id`
> Deletes an avatar from a project, issue type or priority.

### Get avatar image by type
`GET /rest/api/3/universal_avatar/view/type/:type`
> Returns the default project, issue type or priority avatar image.

### Get avatar image by ID
`GET /rest/api/3/universal_avatar/view/type/:type/avatar/:id`
> Returns a project, issue type or priority avatar image by ID.

### Get avatar image by owner
`GET /rest/api/3/universal_avatar/view/type/:type/owner/:entityId`
> Returns the avatar image for a project, issue type or priority.

## Classification levels (1 endpoints)

### Get all classification levels
`GET /rest/api/3/classification-levels`
> Returns all classification levels.

## Dashboards (17 endpoints)

### Get all dashboards
`GET /rest/api/3/dashboard`
> Returns a list of dashboards owned by or shared with the user. The list may be filtered to include only favorite or owned dashboards.

### Create dashboard
`POST /rest/api/3/dashboard`
> Creates a dashboard.
Body example:
```json
{
  "description": "A dashboard to help auditors identify sample of issues to check.",
  "editPermissions": [],
  "name": "Auditors dashboard",
  "sharePermissions": [
    {
      "type": "global"
    }
  ]
}
```

### Bulk edit dashboards
`PUT /rest/api/3/dashboard/bulk/edit`
> Bulk edit dashboards. Maximum number of dashboards to be edited at the same time is 100.

### Get available gadgets
`GET /rest/api/3/dashboard/gadgets`
> Gets a list of all available gadgets that can be added to all dashboards.

### Search for dashboards
`GET /rest/api/3/dashboard/search`
> Returns a [paginated](#pagination) list of dashboards. This operation is similar to [Get dashboards](#api-rest-api-3-dashboard-get) except that the results can be refined to include dashboards that ha

### Get gadgets
`GET /rest/api/3/dashboard/:dashboardId/gadget`
> Returns a list of dashboard gadgets on a dashboard.

### Add gadget to dashboard
`POST /rest/api/3/dashboard/:dashboardId/gadget`
> Adds a gadget to a dashboard.
Body example:
```json
{
  "color": "blue",
  "ignoreUriAndModuleKeyValidation": false,
  "moduleKey": "com.atlassian.plugins.atlassian-connect-plugin:com.atlassian.connect.node.sample-addon__sample-dashboard-item",
  "position": {
    "column": 1,
    "row": 0
  },
  "title": "Issue statistics"
}
```

### Update gadget on dashboard
`PUT /rest/api/3/dashboard/:dashboardId/gadget/:gadgetId`
> Changes the title, position, and color of the gadget on a dashboard.
Body example:
```json
{
  "color": "red",
  "position": {
    "column": 1,
    "row": 1
  },
  "title": "My new gadget title"
}
```

### Remove gadget from dashboard
`DELETE /rest/api/3/dashboard/:dashboardId/gadget/:gadgetId`
> Removes a dashboard gadget from a dashboard.

### Get dashboard item property keys
`GET /rest/api/3/dashboard/:dashboardId/items/:itemId/properties`
> Returns the keys of all properties for a dashboard item.

### Get dashboard item property
`GET /rest/api/3/dashboard/:dashboardId/items/:itemId/properties/:propertyKey`
> Returns the key and value of a dashboard item property.

### Set dashboard item property
`PUT /rest/api/3/dashboard/:dashboardId/items/:itemId/properties/:propertyKey`
> Sets the value of a dashboard item property. Use this resource in apps to store custom data against a dashboard item.
Body example:
```json
{
  "number": 5,
  "string": "string-value"
}
```

### Delete dashboard item property
`DELETE /rest/api/3/dashboard/:dashboardId/items/:itemId/properties/:propertyKey`
> Deletes a dashboard item property.

### Get dashboard
`GET /rest/api/3/dashboard/:id`
> Returns a dashboard.

### Update dashboard
`PUT /rest/api/3/dashboard/:id`
> Updates a dashboard, replacing all the dashboard details with those provided.
Body example:
```json
{
  "description": "A dashboard to help auditors identify sample of issues to check.",
  "editPermissions": [],
  "name": "Auditors dashboard",
  "sharePermissions": [
    {
      "type": "global"
    }
  ]
}
```

### Delete dashboard
`DELETE /rest/api/3/dashboard/:id`
> Deletes a dashboard.

### Copy dashboard
`POST /rest/api/3/dashboard/:id/copy`
> Copies a dashboard. Any values provided in the `dashboard` parameter replace those in the copied dashboard.
Body example:
```json
{
  "description": "A dashboard to help auditors identify sample of issues to check.",
  "editPermissions": [],
  "name": "Auditors dashboard",
  "sharePermissions": [
    {
      "type": "global"
    }
  ]
}
```

## Dynamic modules (3 endpoints)

### Get modules
`GET /rest/atlassian-connect/1/app/module/dynamic`
> Returns all modules registered dynamically by the calling app.

### Register modules
`POST /rest/atlassian-connect/1/app/module/dynamic`
> Registers a list of modules.

### Remove modules
`DELETE /rest/atlassian-connect/1/app/module/dynamic`
> Remove all or a list of modules registered by the calling app.

## Field schemes (15 endpoints)

### Get field schemes
`GET /rest/api/3/config/fieldschemes`
> REST endpoint for retrieving a paginated list of field association schemes with optional filtering.

### Create field scheme
`POST /rest/api/3/config/fieldschemes`
> Endpoint for creating a new field association scheme.
Body example:
```json
{
  "description": "Field association scheme description",
  "name": "Field association scheme name"
}
```

### Update fields associated with field schemes
`PUT /rest/api/3/config/fieldschemes/fields`
> Update fields associated with field association schemes.
Body example:
```json
{
  "customfield_10000": [
    {
      "restrictedToWorkTypes": [
        1,
        2
      ],
      "schemeIds": [
        10000,
        10001
      ]
    }
  ],
  "customfield_10001": [
    {
      "schemeIds": [
        10002
      ]
    }
  ]
}
```

### Remove fields associated with field schemes
`DELETE /rest/api/3/config/fieldschemes/fields`
> Remove fields associated with field association schemes.
Body example:
```json
{
  "customfield_10000": {
    "schemeIds": [
      10000,
      10001
    ]
  },
  "customfield_10001": {
    "schemeIds": [
      10002
    ]
  }
}
```

### Update field parameters
`PUT /rest/api/3/config/fieldschemes/fields/parameters`
> Update field association item parameters in field association schemes.

### Remove field parameters
`DELETE /rest/api/3/config/fieldschemes/fields/parameters`
> Remove field association parameters overrides for work types.
Body example:
```json
{
  "customfield_10000": [
    {
      "parameters": [
        "description",
        "isRequired"
      ],
      "schemeId": 10000,
      "workTypeIds": [
        1,
        2
      ]
    }
  ],
  "description": [
    {
      "parameters": [
        "description"
      ],
      "schemeId": 10001,
      "workTypeIds": [
        3
      ]
    }
  ]
}
```

### Get projects with field schemes
`GET /rest/api/3/config/fieldschemes/projects`
> Get projects with field association schemes. This will be a temporary API but useful when transitioning from the legacy field configuration APIs to the new ones.

### Associate projects to field schemes
`PUT /rest/api/3/config/fieldschemes/projects`
> Associate projects to field association schemes.
Body example:
```json
{
  "10000": {
    "projectIds": [
      10000,
      10001
    ]
  },
  "10001": {
    "projectIds": [
      10002
    ]
  }
}
```

### Get field scheme
`GET /rest/api/3/config/fieldschemes/:id`
> Endpoint for fetching a field association scheme by its ID

### Update field scheme
`PUT /rest/api/3/config/fieldschemes/:id`
> Endpoint for updating an existing field association scheme.
Body example:
```json
{
  "description": "Field association scheme description",
  "name": "Field association scheme name"
}
```

### Delete a field scheme
`DELETE /rest/api/3/config/fieldschemes/:id`
> Delete a specified field association scheme

### Clone field scheme
`POST /rest/api/3/config/fieldschemes/:id/clone`
> Endpoint for cloning an existing field association scheme into a new one.
Body example:
```json
{
  "description": "Field association scheme description",
  "name": "Field association scheme name"
}
```

### Search field scheme fields
`GET /rest/api/3/config/fieldschemes/:id/fields`
> Search for fields belonging to a given field association scheme.

### Get field parameters
`GET /rest/api/3/config/fieldschemes/:id/fields/:fieldId/parameters`
> Retrieve field association parameters on a field association scheme

### Search field scheme projects
`GET /rest/api/3/config/fieldschemes/:id/projects`
> REST Endpoint for searching for projects belonging to a given field association scheme

## Filter sharing (6 endpoints)

### Get default share scope
`GET /rest/api/3/filter/defaultShareScope`
> Returns the default sharing settings for new filters and dashboards for a user.

### Set default share scope
`PUT /rest/api/3/filter/defaultShareScope`
> Sets the default sharing for new filters and dashboards for a user.
Body example:
```json
{
  "scope": "GLOBAL"
}
```

### Get share permissions
`GET /rest/api/3/filter/:id/permission`
> Returns the share permissions for a filter. A filter can be shared with groups, projects, all logged-in users, or the public. Sharing with all logged-in users or the public is known as a global share 

### Add share permission
`POST /rest/api/3/filter/:id/permission`
> Add a share permissions to a filter. If you add a global share permission (one for all logged-in users or the public) it will overwrite all share permissions for the filter.
Body example:
```json
{
  "groupname": "jira-administrators",
  "rights": 1,
  "type": "group"
}
```

### Get share permission
`GET /rest/api/3/filter/:id/permission/:permissionId`
> Returns a share permission for a filter. A filter can be shared with groups, projects, all logged-in users, or the public. Sharing with all logged-in users or the public is known as a global share per

### Delete share permission
`DELETE /rest/api/3/filter/:id/permission/:permissionId`
> Deletes a share permission from a filter.

## Filters (13 endpoints)

### Create filter
`POST /rest/api/3/filter`
> Creates a filter. The filter is shared according to the [default share scope](#api-rest-api-3-filter-post). The filter is not selected as a favorite.
Body example:
```json
{
  "description": "Lists all open bugs",
  "jql": "type = Bug and resolution is empty",
  "name": "All Open Bugs"
}
```

### Get favorite filters
`GET /rest/api/3/filter/favourite`
> Returns the visible favorite filters of the user.

### Get my filters
`GET /rest/api/3/filter/my`
> Returns the filters owned by the user. If `includeFavourites` is `true`, the user's visible favorite filters are also returned.

### Search for filters
`GET /rest/api/3/filter/search`
> Returns a [paginated](#pagination) list of filters. Use this operation to get:

### Get filter
`GET /rest/api/3/filter/:id`
> Returns a filter.

### Update filter
`PUT /rest/api/3/filter/:id`
> Updates a filter. Use this operation to update a filter's name, description, JQL, or sharing.
Body example:
```json
{
  "description": "Lists all open bugs",
  "jql": "type = Bug and resolution is empty",
  "name": "All Open Bugs"
}
```

### Delete filter
`DELETE /rest/api/3/filter/:id`
> Delete a filter.

### Get columns
`GET /rest/api/3/filter/:id/columns`
> Returns the columns configured for a filter. The column configuration is used when the filter's results are viewed in *List View* with the *Columns* set to *Filter*.

### Set columns
`PUT /rest/api/3/filter/:id/columns`
> Sets the columns for a filter. Only navigable fields can be set as columns. Use [Get fields](#api-rest-api-3-field-get) to get the list fields in Jira. A navigable field has `navigable` set to `true`.

### Reset columns
`DELETE /rest/api/3/filter/:id/columns`
> Reset the user's column configuration for the filter to the default.

### Add filter as favorite
`PUT /rest/api/3/filter/:id/favourite`
> Add a filter as a favorite for the user.

### Remove filter as favorite
`DELETE /rest/api/3/filter/:id/favourite`
> Removes a filter as a favorite for the user. Note that this operation only removes filters visible to the user from the user's favorites list. For example, if the user favorites a public filter that i

### Change filter owner
`PUT /rest/api/3/filter/:id/owner`
> Changes the owner of the filter.
Body example:
```json
{
  "accountId": "0000-0000-0000-0000"
}
```

## Group and user picker (1 endpoints)

### Find users and groups
`GET /rest/api/3/groupuserpicker`
> Returns a list of users and groups matching a string. The string is used:

## Groups (8 endpoints)

### Get group
`GET /rest/api/3/group`
> This operation is deprecated, use [`group/member`](#api-rest-api-3-group-member-get).

### Create group
`POST /rest/api/3/group`
> Creates a group.
Body example:
```json
{
  "name": "power-users"
}
```

### Remove group
`DELETE /rest/api/3/group`
> Deletes a group.

### Bulk get groups
`GET /rest/api/3/group/bulk`
> Returns a [paginated](#pagination) list of groups.

### Get users from group
`GET /rest/api/3/group/member`
> Returns a [paginated](#pagination) list of all users in a group.

### Add user to group
`POST /rest/api/3/group/user`
> Adds a user to a group.
Body example:
```json
{
  "accountId": "5b10ac8d82e05b22cc7d4ef5"
}
```

### Remove user from group
`DELETE /rest/api/3/group/user`
> Removes a user from a group.

### Find groups
`GET /rest/api/3/groups/picker`
> Returns a list of groups whose names contain a query string. A list of group names can be provided to exclude groups from the results.

## Issue attachments (8 endpoints)

### Get attachment content
`GET /rest/api/3/attachment/content/:id`
> Returns the contents of an attachment. A `Range` header can be set to define a range of bytes within the attachment to download. See the [HTTP Range header standard](https://developer.mozilla.org/en-U

### Get Jira attachment settings
`GET /rest/api/3/attachment/meta`
> Returns the attachment settings, that is, whether attachments are enabled and the maximum attachment size allowed.

### Get attachment thumbnail
`GET /rest/api/3/attachment/thumbnail/:id`
> Returns the thumbnail of an attachment.

### Get attachment metadata
`GET /rest/api/3/attachment/:id`
> Returns the metadata for an attachment. Note that the attachment itself is not returned.

### Delete attachment
`DELETE /rest/api/3/attachment/:id`
> Deletes an attachment from an issue.

### Get all metadata for an expanded attachment
`GET /rest/api/3/attachment/:id/expand/human`
> Returns the metadata for the contents of an attachment, if it is an archive, and metadata for the attachment itself. For example, if the attachment is a ZIP archive, then information about the files i

### Get contents metadata for an expanded attachment
`GET /rest/api/3/attachment/:id/expand/raw`
> Returns the metadata for the contents of an attachment, if it is an archive. For example, if the attachment is a ZIP archive, then information about the files in the archive is returned. Currently, on

### Add attachment
`POST /rest/api/3/issue/:issueIdOrKey/attachments`
> Adds one or more attachments to an issue. Attachments are posted as multipart/form-data ([RFC 1867](https://www.ietf.org/rfc/rfc1867.txt)).

## Issue bulk operations (9 endpoints)

### Bulk delete issues
`POST /rest/api/3/bulk/issues/delete`
> Use this API to submit a bulk delete request. You can delete up to 1,000 issues in a single operation.
Body example:
```json
{
  "selectedIssueIdsOrKeys": [
    "10001",
    "10002"
  ],
  "sendBulkNotification": false
}
```

### Get bulk editable fields
`GET /rest/api/3/bulk/issues/fields`
> Use this API to get a list of fields visible to the user to perform bulk edit operations. You can pass single or multiple issues in the query to get eligible editable fields. This API uses pagination 

### Bulk edit issues
`POST /rest/api/3/bulk/issues/fields`
> Use this API to submit a bulk edit request and simultaneously edit multiple issues. There are limits applied to the number of issues and fields that can be edited. A single request can accommodate a m

### Bulk move issues
`POST /rest/api/3/bulk/issues/move`
> Use this API to submit a bulk issue move request. You can move multiple issues from multiple projects in a single request, but they must all be moved to a single project, issue type, and parent. You c

### Get available transitions
`GET /rest/api/3/bulk/issues/transition`
> Use this API to retrieve a list of transitions available for the specified issues that can be used or bulk transition operations. You can submit either single or multiple issues in the query to obtain

### Bulk transition issue statuses
`POST /rest/api/3/bulk/issues/transition`
> Use this API to submit a bulk issue status transition request. You can transition multiple issues, alongside with their valid transition Ids. You can transition up to 1,000 issues in a single operatio
Body example:
```json
{
  "bulkTransitionInputs": [
    {
      "selectedIssueIdsOrKeys": [
        "10001",
        "10002"
      ],
      "transitionId": "11"
    },
    {
      "selectedIssueIdsOrKeys": [
        "TEST-1"
      ],
      "transitionId": "2"
    }
  ],
  "sendBulkNotification": false
}
```

### Bulk unwatch issues
`POST /rest/api/3/bulk/issues/unwatch`
> Use this API to submit a bulk unwatch request. You can unwatch up to 1,000 issues in a single operation.
Body example:
```json
{
  "selectedIssueIdsOrKeys": [
    "10001",
    "10002"
  ]
}
```

### Bulk watch issues
`POST /rest/api/3/bulk/issues/watch`
> Use this API to submit a bulk watch request. You can watch up to 1,000 issues in a single operation.
Body example:
```json
{
  "selectedIssueIdsOrKeys": [
    "10001",
    "10002"
  ]
}
```

### Get bulk issue operation progress
`GET /rest/api/3/bulk/queue/:taskId`
> Use this to get the progress state for the specified bulk operation `taskId`.

## Issue comment properties (4 endpoints)

### Get comment property keys
`GET /rest/api/3/comment/:commentId/properties`
> Returns the keys of all the properties of a comment.

### Get comment property
`GET /rest/api/3/comment/:commentId/properties/:propertyKey`
> Returns the value of a comment property.

### Set comment property
`PUT /rest/api/3/comment/:commentId/properties/:propertyKey`
> Creates or updates the value of a property for a comment. Use this resource to store custom data against a comment.

### Delete comment property
`DELETE /rest/api/3/comment/:commentId/properties/:propertyKey`
> Deletes a comment property.

## Issue comments (6 endpoints)

### Get comments by IDs
`POST /rest/api/3/comment/list`
> Returns a [paginated](#pagination) list of comments specified by a list of comment IDs.
Body example:
```json
{
  "ids": [
    1,
    2,
    5,
    10
  ]
}
```

### Get comments
`GET /rest/api/3/issue/:issueIdOrKey/comment`
> Returns all comments for an issue.

### Add comment
`POST /rest/api/3/issue/:issueIdOrKey/comment`
> Adds a comment to an issue.

### Get comment
`GET /rest/api/3/issue/:issueIdOrKey/comment/:id`
> Returns a comment.

### Update comment
`PUT /rest/api/3/issue/:issueIdOrKey/comment/:id`
> Updates a comment.

### Delete comment
`DELETE /rest/api/3/issue/:issueIdOrKey/comment/:id`
> Deletes a comment.

## Issue custom field associations (2 endpoints)

### Create associations
`PUT /rest/api/3/field/association`
> Associates fields with projects.
Body example:
```json
{
  "associationContexts": [
    {
      "identifier": 10000,
      "type": "PROJECT_ID"
    },
    {
      "identifier": 10001,
      "type": "PROJECT_ID"
    }
  ],
  "fields": [
    {
      "identifier": "customfield_10000",
      "type": "FIELD_ID"
    },
    {
      "identifier": "customfield_10001",
      "type": "FIELD_ID"
    }
  ]
}
```

### Remove associations
`DELETE /rest/api/3/field/association`
> Unassociates a set of fields with a project and issue type context.
Body example:
```json
{
  "associationContexts": [
    {
      "identifier": 10000,
      "type": "PROJECT_ID"
    },
    {
      "identifier": 10001,
      "type": "PROJECT_ID"
    }
  ],
  "fields": [
    {
      "identifier": "customfield_10000",
      "type": "FIELD_ID"
    },
    {
      "identifier": "customfield_10001",
      "type": "FIELD_ID"
    }
  ]
}
```

## Issue custom field configuration (apps) (3 endpoints)

### Bulk get custom field configurations
`POST /rest/api/3/app/field/context/configuration/list`
> Returns a [paginated](#pagination) list of configurations for list of custom fields of a [type](https://developer.atlassian.com/platform/forge/manifest-reference/modules/jira-custom-field-type/) creat
Body example:
```json
{
  "fieldIdsOrKeys": [
    "customfield_10035",
    "customfield_10036"
  ]
}
```

### Get custom field configurations
`GET /rest/api/3/app/field/:fieldIdOrKey/context/configuration`
> Returns a [paginated](#pagination) list of configurations for a custom field of a [type](https://developer.atlassian.com/platform/forge/manifest-reference/modules/jira-custom-field-type/) created by a

### Update custom field configurations
`PUT /rest/api/3/app/field/:fieldIdOrKey/context/configuration`
> Update the configuration for contexts of a custom field of a [type](https://developer.atlassian.com/platform/forge/manifest-reference/modules/jira-custom-field-type/) created by a [Forge app](https://
Body example:
```json
{
  "configurations": [
    {
      "id": "10000"
    },
    {
      "configuration": {
        "maxValue": 10000,
        "minValue": 0
      },
      "id": "10001",
      "schema": {
        "properties": {
          "amount": {
            "type": "number"
          },
          "currency": {
            "type": "string"
          }
        },
        "required": [
          "amount",
          "currency"
        ]
      }
    }
  ]
}
```

## Issue custom field contexts (13 endpoints)

### Get custom field contexts
`GET /rest/api/3/field/:fieldId/context`
> Returns a [paginated](#pagination) list of [ contexts](https://confluence.atlassian.com/adminjiracloud/what-are-custom-field-contexts-991923859.html) for a custom field. Contexts can be returned as fo

### Create custom field context
`POST /rest/api/3/field/:fieldId/context`
> Creates a custom field context.
Body example:
```json
{
  "description": "A context used to define the custom field options for bugs.",
  "issueTypeIds": [
    "10010"
  ],
  "name": "Bug fields context",
  "projectIds": []
}
```

### Get custom field contexts default values
`GET /rest/api/3/field/:fieldId/context/defaultValue`
> Returns a [paginated](#pagination) list of defaults for a custom field. The results can be filtered by `contextId`, otherwise all values are returned. If no defaults are set for a context, nothing is 

### Set custom field contexts default values
`PUT /rest/api/3/field/:fieldId/context/defaultValue`
> Sets default for contexts of a custom field. Default are defined using these objects:
Body example:
```json
{
  "defaultValues": [
    {
      "contextId": "10100",
      "optionId": "10001",
      "type": "option.single"
    },
    {
      "contextId": "10101",
      "optionId": "10003",
      "type": "option.single"
    },
    {
      "contextId": "10103",
      "optionId": "10005",
      "type": "option.single"
    }
  ]
}
```

### Get issue types for custom field context
`GET /rest/api/3/field/:fieldId/context/issuetypemapping`
> Returns a [paginated](#pagination) list of context to issue type mappings for a custom field. Mappings are returned for all contexts or a list of contexts. Mappings are ordered first by context ID and

### Get custom field contexts for projects and issue types
`POST /rest/api/3/field/:fieldId/context/mapping`
> Returns a [paginated](#pagination) list of project and issue type mappings and, for each mapping, the ID of a [custom field context](https://confluence.atlassian.com/x/k44fOw) that applies to the proj
Body example:
```json
{
  "mappings": [
    {
      "issueTypeId": "10000",
      "projectId": "10000"
    },
    {
      "issueTypeId": "10001",
      "projectId": "10000"
    },
    {
      "issueTypeId": "10002",
      "projectId": "10001"
    }
  ]
}
```

### Get project mappings for custom field context
`GET /rest/api/3/field/:fieldId/context/projectmapping`
> Returns a [paginated](#pagination) list of context to project mappings for a custom field. The result can be filtered by `contextId`. Otherwise, all mappings are returned. Invalid IDs are ignored.

### Update custom field context
`PUT /rest/api/3/field/:fieldId/context/:contextId`
> Updates a [ custom field context](https://confluence.atlassian.com/adminjiracloud/what-are-custom-field-contexts-991923859.html).
Body example:
```json
{
  "description": "A context used to define the custom field options for bugs.",
  "name": "Bug fields context"
}
```

### Delete custom field context
`DELETE /rest/api/3/field/:fieldId/context/:contextId`
> Deletes a [ custom field context](https://confluence.atlassian.com/adminjiracloud/what-are-custom-field-contexts-991923859.html).

### Add issue types to context
`PUT /rest/api/3/field/:fieldId/context/:contextId/issuetype`
> Adds issue types to a custom field context, appending the issue types to the issue types list.
Body example:
```json
{
  "issueTypeIds": [
    "10001",
    "10005",
    "10006"
  ]
}
```

### Remove issue types from context
`POST /rest/api/3/field/:fieldId/context/:contextId/issuetype/remove`
> Removes issue types from a custom field context.
Body example:
```json
{
  "issueTypeIds": [
    "10001",
    "10005",
    "10006"
  ]
}
```

### Assign custom field context to projects
`PUT /rest/api/3/field/:fieldId/context/:contextId/project`
> Assigns a custom field context to projects.
Body example:
```json
{
  "projectIds": [
    "10001",
    "10005",
    "10006"
  ]
}
```

### Remove custom field context from projects
`POST /rest/api/3/field/:fieldId/context/:contextId/project/remove`
> Removes a custom field context from projects.
Body example:
```json
{
  "projectIds": [
    "10001",
    "10005",
    "10006"
  ]
}
```

## Issue custom field options (7 endpoints)

### Get custom field option
`GET /rest/api/3/customFieldOption/:id`
> Returns a custom field option. For example, an option in a select list.

### Get custom field options (context)
`GET /rest/api/3/field/:fieldId/context/:contextId/option`
> Returns a [paginated](#pagination) list of all custom field option for a context. Options are returned first then cascading options, in the order they display in Jira.

### Update custom field options (context)
`PUT /rest/api/3/field/:fieldId/context/:contextId/option`
> Updates the options of a custom field.
Body example:
```json
{
  "options": [
    {
      "disabled": false,
      "id": "10001",
      "value": "Scranton"
    },
    {
      "disabled": true,
      "id": "10002",
      "value": "Manhattan"
    },
    {
      "disabled": false,
      "id": "10003",
      "value": "The Electric City"
    }
  ]
}
```

### Create custom field options (context)
`POST /rest/api/3/field/:fieldId/context/:contextId/option`
> Creates options and, where the custom select field is of the type Select List (cascading), cascading options for a custom select field. The options are added to a context of the field.
Body example:
```json
{
  "options": [
    {
      "disabled": false,
      "value": "Scranton"
    },
    {
      "disabled": true,
      "optionId": "10000",
      "value": "Manhattan"
    },
    {
      "disabled": false,
      "value": "The Electric City"
    }
  ]
}
```

### Reorder custom field options (context)
`PUT /rest/api/3/field/:fieldId/context/:contextId/option/move`
> Changes the order of custom field options or cascading options in a context.
Body example:
```json
{
  "customFieldOptionIds": [
    "10001",
    "10002"
  ],
  "position": "First"
}
```

### Delete custom field options (context)
`DELETE /rest/api/3/field/:fieldId/context/:contextId/option/:optionId`
> Deletes a custom field option.

### Replace custom field options
`DELETE /rest/api/3/field/:fieldId/context/:contextId/option/:optionId/issue`
> Replaces the options of a custom field.

## Issue custom field options (apps) (8 endpoints)

### Get all issue field options
`GET /rest/api/3/field/:fieldKey/option`
> Returns a [paginated](#pagination) list of all the options of a select list issue field. A select list issue field is a type of [issue field](https://developer.atlassian.com/cloud/jira/platform/module

### Create issue field option
`POST /rest/api/3/field/:fieldKey/option`
> Creates an option for a select list issue field.

### Get selectable issue field options
`GET /rest/api/3/field/:fieldKey/option/suggestions/edit`
> Returns a [paginated](#pagination) list of options for a select list issue field that can be viewed and selected by the user.

### Get visible issue field options
`GET /rest/api/3/field/:fieldKey/option/suggestions/search`
> Returns a [paginated](#pagination) list of options for a select list issue field that can be viewed by the user.

### Get issue field option
`GET /rest/api/3/field/:fieldKey/option/:optionId`
> Returns an option from a select list issue field.

### Update issue field option
`PUT /rest/api/3/field/:fieldKey/option/:optionId`
> Updates or creates an option for a select list issue field. This operation requires that the option ID is provided when creating an option, therefore, the option ID needs to be specified as a path and

### Delete issue field option
`DELETE /rest/api/3/field/:fieldKey/option/:optionId`
> Deletes an option from a select list issue field.

### Replace issue field option
`DELETE /rest/api/3/field/:fieldKey/option/:optionId/issue`
> Deselects an issue-field select-list option from all issues where it is selected. A different option can be selected to replace the deselected option. The update can also be limited to a smaller set o

## Issue custom field values (apps) (2 endpoints)

### Update custom fields
`POST /rest/api/3/app/field/value`
> Updates the value of one or more custom fields on one or more issues. Combinations of custom field and issue should be unique within the request.
Body example:
```json
{
  "updates": [
    {
      "customField": "customfield_10010",
      "issueIds": [
        10010,
        10011
      ],
      "value": "new value"
    },
    {
      "customField": "customfield_10011",
      "issueIds": [
        10010
      ],
      "value": 1000
    }
  ]
}
```

### Update custom field value
`PUT /rest/api/3/app/field/:fieldIdOrKey/value`
> Updates the value of a custom field on one or more issues.
Body example:
```json
{
  "updates": [
    {
      "issueIds": [
        10010
      ],
      "value": "new value"
    }
  ]
}
```

## Issue field configurations (15 endpoints)

### Get all field configurations
`GET /rest/api/3/fieldconfiguration`
> Deprecated, use [ Field schemes](https://developer.atlassian.com/cloud/jira/platform/rest/v3/api-group-field-schemes/#api-group-field-schemes) which supports field association schemes.

### Create field configuration
`POST /rest/api/3/fieldconfiguration`
> Deprecated, use [ Field schemes](https://developer.atlassian.com/cloud/jira/platform/rest/v3/api-group-field-schemes/#api-group-field-schemes) which supports field association schemes.
Body example:
```json
{
  "description": "My field configuration description",
  "name": "My Field Configuration"
}
```

### Update field configuration
`PUT /rest/api/3/fieldconfiguration/:id`
> Deprecated, use [ Field schemes](https://developer.atlassian.com/cloud/jira/platform/rest/v3/api-group-field-schemes/#api-group-field-schemes) which supports field association schemes.
Body example:
```json
{
  "description": "A brand new description",
  "name": "My Modified Field Configuration"
}
```

### Delete field configuration
`DELETE /rest/api/3/fieldconfiguration/:id`
> Deprecated, use [ Field schemes](https://developer.atlassian.com/cloud/jira/platform/rest/v3/api-group-field-schemes/#api-group-field-schemes) which supports field association schemes.

### Get field configuration items
`GET /rest/api/3/fieldconfiguration/:id/fields`
> Deprecated, use [ Field schemes](https://developer.atlassian.com/cloud/jira/platform/rest/v3/api-group-field-schemes/#api-group-field-schemes) which supports field association schemes.

### Update field configuration items
`PUT /rest/api/3/fieldconfiguration/:id/fields`
> Deprecated, use [ Field schemes](https://developer.atlassian.com/cloud/jira/platform/rest/v3/api-group-field-schemes/#api-group-field-schemes) which supports field association schemes.
Body example:
```json
{
  "fieldConfigurationItems": [
    {
      "description": "The new description of this item.",
      "id": "customfield_10012",
      "isHidden": false
    },
    {
      "id": "customfield_10011",
      "isRequired": true
    },
    {
      "description": "Another new description.",
      "id": "customfield_10010",
      "isHidden": false,
      "isRequired": false,
      "renderer": "wiki-renderer"
    }
  ]
}
```

### Get all field configuration schemes
`GET /rest/api/3/fieldconfigurationscheme`
> Deprecated, use [ Field schemes](https://developer.atlassian.com/cloud/jira/platform/rest/v3/api-group-field-schemes/#api-group-field-schemes) which supports field association schemes.

### Create field configuration scheme
`POST /rest/api/3/fieldconfigurationscheme`
> Deprecated, use [ Field schemes](https://developer.atlassian.com/cloud/jira/platform/rest/v3/api-group-field-schemes/#api-group-field-schemes) which supports field association schemes.
Body example:
```json
{
  "description": "We can use this one for software projects.",
  "name": "Field Configuration Scheme for software related projects"
}
```

### Get field configuration issue type items
`GET /rest/api/3/fieldconfigurationscheme/mapping`
> Deprecated, use [ Field schemes](https://developer.atlassian.com/cloud/jira/platform/rest/v3/api-group-field-schemes/#api-group-field-schemes) which supports field association schemes.

### Get field configuration schemes for projects
`GET /rest/api/3/fieldconfigurationscheme/project`
> Deprecated, use [ Field schemes](https://developer.atlassian.com/cloud/jira/platform/rest/v3/api-group-field-schemes/#api-group-field-schemes) which supports field association schemes.

### Assign field configuration scheme to project
`PUT /rest/api/3/fieldconfigurationscheme/project`
> Deprecated, use [ Field schemes](https://developer.atlassian.com/cloud/jira/platform/rest/v3/api-group-field-schemes/#api-group-field-schemes) which supports field association schemes.
Body example:
```json
{
  "fieldConfigurationSchemeId": "10000",
  "projectId": "10000"
}
```

### Update field configuration scheme
`PUT /rest/api/3/fieldconfigurationscheme/:id`
> Deprecated, use [ Field schemes](https://developer.atlassian.com/cloud/jira/platform/rest/v3/api-group-field-schemes/#api-group-field-schemes) which supports field association schemes.
Body example:
```json
{
  "description": "We can use this one for software projects.",
  "name": "Field Configuration Scheme for software related projects"
}
```

### Delete field configuration scheme
`DELETE /rest/api/3/fieldconfigurationscheme/:id`
> Deprecated, use [ Field schemes](https://developer.atlassian.com/cloud/jira/platform/rest/v3/api-group-field-schemes/#api-group-field-schemes) which supports field association schemes.

### Assign issue types to field configurations
`PUT /rest/api/3/fieldconfigurationscheme/:id/mapping`
> Deprecated, use [ Field schemes](https://developer.atlassian.com/cloud/jira/platform/rest/v3/api-group-field-schemes/#api-group-field-schemes) which supports field association schemes.
Body example:
```json
{
  "mappings": [
    {
      "fieldConfigurationId": "10000",
      "issueTypeId": "default"
    },
    {
      "fieldConfigurationId": "10002",
      "issueTypeId": "10001"
    },
    {
      "fieldConfigurationId": "10001",
      "issueTypeId": "10002"
    }
  ]
}
```

### Remove issue types from field configuration scheme
`POST /rest/api/3/fieldconfigurationscheme/:id/mapping/delete`
> Deprecated, use [ Field schemes](https://developer.atlassian.com/cloud/jira/platform/rest/v3/api-group-field-schemes/#api-group-field-schemes) which supports field association schemes.
Body example:
```json
{
  "issueTypeIds": [
    "10000",
    "10001",
    "10002"
  ]
}
```

## Issue fields (10 endpoints)

### Get fields
`GET /rest/api/3/field`
> Returns system and custom issue fields according to the following rules:

### Create custom field
`POST /rest/api/3/field`
> Creates a custom field.
Body example:
```json
{
  "description": "Custom field for picking groups",
  "name": "New custom field",
  "searcherKey": "com.atlassian.jira.plugin.system.customfieldtypes:grouppickersearcher",
  "type": "com.atlassian.jira.plugin.system.customfieldtypes:grouppicker"
}
```

### Get fields paginated
`GET /rest/api/3/field/search`
> Returns a [paginated](#pagination) list of fields for Classic Jira projects. The list can include:

### Get fields in trash paginated
`GET /rest/api/3/field/search/trashed`
> Returns a [paginated](#pagination) list of fields in the trash. The list may be restricted to fields whose field name or description partially match a string.

### Update custom field
`PUT /rest/api/3/field/:fieldId`
> Updates a custom field.
Body example:
```json
{
  "description": "Select the manager and the corresponding employee.",
  "name": "Managers and employees list",
  "searcherKey": "com.atlassian.jira.plugin.system.customfieldtypes:cascadingselectsearcher"
}
```

### Get contexts for a field
`GET /rest/api/3/field/:fieldId/contexts`
> Returns a [paginated](#pagination) list of the contexts a field is used in. Deprecated, use [ Get custom field contexts](#api-rest-api-3-field-fieldId-context-get).

### Delete custom field
`DELETE /rest/api/3/field/:id`
> Deletes a custom field. The custom field is deleted whether it is in the trash or not. See [Edit or delete a custom field](https://confluence.atlassian.com/x/Z44fOw) for more information on trashing a

### Restore custom field from trash
`POST /rest/api/3/field/:id/restore`
> Restores a custom field from trash. See [Edit or delete a custom field](https://confluence.atlassian.com/x/Z44fOw) for more information on trashing and deleting custom fields.

### Move custom field to trash
`POST /rest/api/3/field/:id/trash`
> Moves a custom field to trash. See [Edit or delete a custom field](https://confluence.atlassian.com/x/Z44fOw) for more information on trashing and deleting custom fields.

### Get fields for projects
`GET /rest/api/3/projects/fields`
> Returns a [paginated](#pagination) list of fields for the requested projects and work types.

## Issue link types (5 endpoints)

### Get issue link types
`GET /rest/api/3/issueLinkType`
> Returns a list of all issue link types.

### Create issue link type
`POST /rest/api/3/issueLinkType`
> Creates an issue link type. Use this operation to create descriptions of the reasons why issues are linked. The issue link type consists of a name and descriptions for a link's inward and outward rela
Body example:
```json
{
  "inward": "Duplicated by",
  "name": "Duplicate",
  "outward": "Duplicates"
}
```

### Get issue link type
`GET /rest/api/3/issueLinkType/:issueLinkTypeId`
> Returns an issue link type.

### Update issue link type
`PUT /rest/api/3/issueLinkType/:issueLinkTypeId`
> Updates an issue link type.
Body example:
```json
{
  "inward": "Duplicated by",
  "name": "Duplicate",
  "outward": "Duplicates"
}
```

### Delete issue link type
`DELETE /rest/api/3/issueLinkType/:issueLinkTypeId`
> Deletes an issue link type.

## Issue links (3 endpoints)

### Create issue link
`POST /rest/api/3/issueLink`
> Creates a link between two issues. Use this operation to indicate a relationship between two issues and optionally add a comment to the from (outward) issue. To use this resource the site must have [I

### Get issue link
`GET /rest/api/3/issueLink/:linkId`
> Returns an issue link.

### Delete issue link
`DELETE /rest/api/3/issueLink/:linkId`
> Deletes an issue link.

## Issue navigator settings (2 endpoints)

### Get issue navigator default columns
`GET /rest/api/3/settings/columns`
> Returns the default issue navigator columns.

### Set issue navigator default columns
`PUT /rest/api/3/settings/columns`
> Sets the default issue navigator columns.

## Issue notification schemes (8 endpoints)

### Get notification schemes paginated
`GET /rest/api/3/notificationscheme`
> Returns a [paginated](#pagination) list of [notification schemes](https://confluence.atlassian.com/x/8YdKLg) ordered by the display name.

### Create notification scheme
`POST /rest/api/3/notificationscheme`
> Creates a notification scheme with notifications. You can create up to 1000 notifications per request.
Body example:
```json
{
  "description": "My new scheme description",
  "name": "My new notification scheme",
  "notificationSchemeEvents": [
    {
      "event": {
        "id": "1"
      },
      "notifications": [
        {
          "notificationType": "Group",
          "parameter": "jira-administrators"
        }
      ]
    }
  ]
}
```

### Get projects using notification schemes paginated
`GET /rest/api/3/notificationscheme/project`
> Returns a [paginated](#pagination) mapping of project that have notification scheme assigned. You can provide either one or multiple notification scheme IDs or project IDs to filter by. If you don't p

### Get notification scheme
`GET /rest/api/3/notificationscheme/:id`
> Returns a [notification scheme](https://confluence.atlassian.com/x/8YdKLg), including the list of events and the recipients who will receive notifications for those events.

### Update notification scheme
`PUT /rest/api/3/notificationscheme/:id`
> Updates a notification scheme.
Body example:
```json
{
  "description": "My updated notification scheme description",
  "name": "My updated notification scheme"
}
```

### Add notifications to notification scheme
`PUT /rest/api/3/notificationscheme/:id/notification`
> Adds notifications to a notification scheme. You can add up to 1000 notifications per request.
Body example:
```json
{
  "notificationSchemeEvents": [
    {
      "event": {
        "id": "1"
      },
      "notifications": [
        {
          "notificationType": "Group",
          "parameter": "jira-administrators"
        }
      ]
    }
  ]
}
```

### Delete notification scheme
`DELETE /rest/api/3/notificationscheme/:notificationSchemeId`
> Deletes a notification scheme.

### Remove notification from notification scheme
`DELETE /rest/api/3/notificationscheme/:notificationSchemeId/notification/:notificationId`
> Removes a notification from a notification scheme.

## Issue panels (1 endpoints)

### Bulk pin or unpin issue panel to projects
`POST /rest/api/3/forge/panel/action/bulk/async`
> Bulk pin or unpin an issue panel (added by a Forge app) to or from multiple projects.

## Issue priorities (8 endpoints)

### Get priorities
`GET /rest/api/3/priority`
> Returns the list of all issue priorities.

### Create priority
`POST /rest/api/3/priority`
> Creates an issue priority.
Body example:
```json
{
  "description": "My priority description",
  "iconUrl": "/images/icons/priorities/major.png",
  "name": "My new priority",
  "statusColor": "#ABCDEF"
}
```

### Set default priority
`PUT /rest/api/3/priority/default`
> Sets default issue priority.
Body example:
```json
{
  "id": "3"
}
```

### Move priorities
`PUT /rest/api/3/priority/move`
> Changes the order of issue priorities.
Body example:
```json
{
  "after": "10003",
  "ids": [
    "10004",
    "10005"
  ]
}
```

### Search priorities
`GET /rest/api/3/priority/search`
> Returns a [paginated](#pagination) list of priorities. The list can contain all priorities or a subset determined by any combination of these criteria:

### Get priority
`GET /rest/api/3/priority/:id`
> Returns an issue priority.

### Update priority
`PUT /rest/api/3/priority/:id`
> Updates an issue priority.
Body example:
```json
{
  "description": "My updated priority description",
  "iconUrl": "/images/icons/priorities/minor.png",
  "name": "My updated priority",
  "statusColor": "#123456"
}
```

### Delete priority
`DELETE /rest/api/3/priority/:id`
> Deletes an issue priority.

## Issue properties (8 endpoints)

### Bulk set issues properties by list
`POST /rest/api/3/issue/properties`
> Sets or updates a list of entity property values on issues. A list of up to 10 entity properties can be specified along with up to 10,000 issues on which to set or update that list of entity propertie

### Bulk set issue properties by issue
`POST /rest/api/3/issue/properties/multi`
> Sets or updates entity property values on issues. Up to 10 entity properties can be specified for each issue and up to 100 issues included in the request.
Body example:
```json
{
  "issues": [
    {
      "issueID": 1000,
      "properties": {
        "myProperty": {
          "owner": "admin",
          "weight": 100
        }
      }
    },
    {
      "issueID": 1001,
      "properties": {
        "myOtherProperty": {
          "cost": 150,
          "transportation": "car"
        }
      }
    }
  ]
}
```

### Bulk set issue property
`PUT /rest/api/3/issue/properties/:propertyKey`
> Sets a property value on multiple issues.
Body example:
```json
{
  "filter": {
    "currentValue": {
      "owner": "admin",
      "weight": 50
    },
    "entityIds": [
      10100,
      100010
    ],
    "hasProperty": true
  },
  "value": {
    "owner": "admin",
    "weight": 100
  }
}
```

### Bulk delete issue property
`DELETE /rest/api/3/issue/properties/:propertyKey`
> Deletes a property value from multiple issues. The issues to be updated can be specified by filter criteria.
Body example:
```json
{
  "currentValue": "deprecated value",
  "entityIds": [
    10100,
    100010
  ]
}
```

### Get issue property keys
`GET /rest/api/3/issue/:issueIdOrKey/properties`
> Returns the URLs and keys of an issue's properties.

### Get issue property
`GET /rest/api/3/issue/:issueIdOrKey/properties/:propertyKey`
> Returns the key and value of an issue's property.

### Set issue property
`PUT /rest/api/3/issue/:issueIdOrKey/properties/:propertyKey`
> Sets the value of an issue's property. Use this resource to store custom data against an issue.

### Delete issue property
`DELETE /rest/api/3/issue/:issueIdOrKey/properties/:propertyKey`
> Deletes an issue's property.

## Issue redaction (2 endpoints)

### Redact
`POST /rest/api/3/redact`
> Submit a job to redact issue field data. This will trigger the redaction of the data in the specified fields asynchronously.

### Get redaction status
`GET /rest/api/3/redact/status/:jobId`
> Retrieves the current status of a redaction job ID.

## Issue remote links (6 endpoints)

### Get remote issue links
`GET /rest/api/3/issue/:issueIdOrKey/remotelink`
> Returns the remote issue links for an issue. When a remote issue link global ID is provided the record with that global ID is returned, otherwise all remote issue links are returned. Where a global ID

### Create or update remote issue link
`POST /rest/api/3/issue/:issueIdOrKey/remotelink`
> Creates or updates a remote issue link for an issue.

### Delete remote issue link by global ID
`DELETE /rest/api/3/issue/:issueIdOrKey/remotelink`
> Deletes the remote issue link from the issue using the link's global ID. Where the global ID includes reserved URL characters these must be escaped in the request. For example, pass `system=http://www

### Get remote issue link by ID
`GET /rest/api/3/issue/:issueIdOrKey/remotelink/:linkId`
> Returns a remote issue link for an issue.

### Update remote issue link by ID
`PUT /rest/api/3/issue/:issueIdOrKey/remotelink/:linkId`
> Updates a remote issue link for an issue.

### Delete remote issue link by ID
`DELETE /rest/api/3/issue/:issueIdOrKey/remotelink/:linkId`
> Deletes a remote issue link from an issue.

## Issue resolutions (8 endpoints)

### Get resolutions
`GET /rest/api/3/resolution`
> Returns a list of all issue resolution values.

### Create resolution
`POST /rest/api/3/resolution`
> Creates an issue resolution.
Body example:
```json
{
  "description": "My resolution description",
  "name": "My new resolution"
}
```

### Set default resolution
`PUT /rest/api/3/resolution/default`
> Sets default issue resolution.
Body example:
```json
{
  "id": "3"
}
```

### Move resolutions
`PUT /rest/api/3/resolution/move`
> Changes the order of issue resolutions.
Body example:
```json
{
  "after": "10002",
  "ids": [
    "10000",
    "10001"
  ]
}
```

### Search resolutions
`GET /rest/api/3/resolution/search`
> Returns a [paginated](#pagination) list of resolutions. The list can contain all resolutions or a subset determined by any combination of these criteria:

### Get resolution
`GET /rest/api/3/resolution/:id`
> Returns an issue resolution value.

### Update resolution
`PUT /rest/api/3/resolution/:id`
> Updates an issue resolution.
Body example:
```json
{
  "description": "My updated resolution description",
  "name": "My updated resolution"
}
```

### Delete resolution
`DELETE /rest/api/3/resolution/:id`
> Deletes an issue resolution.

## Issue search (7 endpoints)

### Get issue picker suggestions
`GET /rest/api/3/issue/picker`
> Returns lists of issues matching a query string. Use this resource to provide auto-completion suggestions when the user is looking for an issue using a word or string.

### Check issues against JQL
`POST /rest/api/3/jql/match`
> Checks whether one or more issues would be returned by one or more JQL queries.
Body example:
```json
{
  "issueIds": [
    10001,
    1000,
    10042
  ],
  "jqls": [
    "project = FOO",
    "issuetype = Bug",
    "summary ~ \"some text\" AND project in (FOO, BAR)"
  ]
}
```

### Currently being removed. Search for issues using JQL (GET)
`GET /rest/api/3/search`
> Endpoint is currently being removed. [More details](https://developer.atlassian.com/changelog/#CHANGE-2046)

### Currently being removed. Search for issues using JQL (POST)
`POST /rest/api/3/search`
> Endpoint is currently being removed. [More details](https://developer.atlassian.com/changelog/#CHANGE-2046)
Body example:
```json
{
  "expand": [
    "names",
    "schema",
    "operations"
  ],
  "fields": [
    "summary",
    "status",
    "assignee"
  ],
  "fieldsByKeys": false,
  "jql": "project = HSP",
  "maxResults": 15,
  "startAt": 0
}
```

### Count issues using JQL
`POST /rest/api/3/search/approximate-count`
> Provide an estimated count of the issues that match the [JQL](https://confluence.atlassian.com/x/egORLQ). Recent updates might not be immediately visible in the returned output. This endpoint requires
Body example:
```json
{
  "jql": "project = HSP"
}
```

### Search for issues using JQL enhanced search (GET)
`GET /rest/api/3/search/jql`
> Searches for issues using [JQL](https://confluence.atlassian.com/x/egORLQ). Recent updates might not be immediately visible in the returned search results. If you need [read-after-write](https://devel

### Search for issues using JQL enhanced search (POST)
`POST /rest/api/3/search/jql`
> Searches for issues using [JQL](https://confluence.atlassian.com/x/egORLQ). Recent updates might not be immediately visible in the returned search results. If you need [read-after-write](https://devel

## Issue security level (2 endpoints)

### Get issue security level members by issue security scheme
`GET /rest/api/3/issuesecurityschemes/:issueSecuritySchemeId/members`
> Returns issue security level members.

### Get issue security level
`GET /rest/api/3/securitylevel/:id`
> Returns details of an issue security level.

## Issue security schemes (16 endpoints)

### Get issue security schemes
`GET /rest/api/3/issuesecurityschemes`
> Returns all [issue security schemes](https://confluence.atlassian.com/x/J4lKLg).

### Create issue security scheme
`POST /rest/api/3/issuesecurityschemes`
> Creates a security scheme with security scheme levels and levels' members. You can create up to 100 security scheme levels and security scheme levels' members per request.
Body example:
```json
{
  "description": "Newly created issue security scheme",
  "levels": [
    {
      "description": "Newly created level",
      "isDefault": true,
      "members": [
        {
          "parameter": "administrators",
          "type": "group"
        }
      ],
      "name": "New level"
    }
  ],
  "name": "New security scheme"
}
```

### Get issue security levels
`GET /rest/api/3/issuesecurityschemes/level`
> Returns a [paginated](#pagination) list of issue security levels.

### Set default issue security levels
`PUT /rest/api/3/issuesecurityschemes/level/default`
> Sets default issue security levels for schemes.
Body example:
```json
{
  "defaultValues": [
    {
      "defaultLevelId": "20000",
      "issueSecuritySchemeId": "10000"
    },
    {
      "defaultLevelId": "30000",
      "issueSecuritySchemeId": "12000"
    }
  ]
}
```

### Get issue security level members
`GET /rest/api/3/issuesecurityschemes/level/member`
> Returns a [paginated](#pagination) list of issue security level members.

### Get projects using issue security schemes
`GET /rest/api/3/issuesecurityschemes/project`
> Returns a [paginated](#pagination) mapping of projects that are using security schemes. You can provide either one or multiple security scheme IDs or project IDs to filter by. If you don't provide any

### Associate security scheme to project
`PUT /rest/api/3/issuesecurityschemes/project`
> Associates an issue security scheme with a project and remaps security levels of issues to the new levels, if provided.
Body example:
```json
{
  "oldToNewSecurityLevelMappings": [
    {
      "newLevelId": "30001",
      "oldLevelId": "30000"
    }
  ],
  "projectId": "10000",
  "schemeId": "20000"
}
```

### Search issue security schemes
`GET /rest/api/3/issuesecurityschemes/search`
> Returns a [paginated](#pagination) list of issue security schemes.  

### Get issue security scheme
`GET /rest/api/3/issuesecurityschemes/:id`
> Returns an issue security scheme along with its security levels.

### Update issue security scheme
`PUT /rest/api/3/issuesecurityschemes/:id`
> Updates the issue security scheme.
Body example:
```json
{
  "description": "My issue security scheme description",
  "name": "My issue security scheme name"
}
```

### Delete issue security scheme
`DELETE /rest/api/3/issuesecurityschemes/:schemeId`
> Deletes an issue security scheme.

### Add issue security levels
`PUT /rest/api/3/issuesecurityschemes/:schemeId/level`
> Adds levels and levels' members to the issue security scheme. You can add up to 100 levels per request.
Body example:
```json
{
  "levels": [
    {
      "description": "First Level Description",
      "isDefault": true,
      "members": [
        {
          "type": "reporter"
        },
        {
          "parameter": "jira-administrators",
          "type": "group"
        }
      ],
      "name": "First Level"
    }
  ]
}
```

### Update issue security level
`PUT /rest/api/3/issuesecurityschemes/:schemeId/level/:levelId`
> Updates the issue security level.
Body example:
```json
{
  "description": "New level description",
  "name": "New level name"
}
```

### Remove issue security level
`DELETE /rest/api/3/issuesecurityschemes/:schemeId/level/:levelId`
> Deletes an issue security level.

### Add issue security level members
`PUT /rest/api/3/issuesecurityschemes/:schemeId/level/:levelId/member`
> Adds members to the issue security level. You can add up to 100 members per request.
Body example:
```json
{
  "members": [
    {
      "type": "reporter"
    },
    {
      "parameter": "jira-administrators",
      "type": "group"
    }
  ]
}
```

### Remove member from issue security level
`DELETE /rest/api/3/issuesecurityschemes/:schemeId/level/:levelId/member/:memberId`
> Removes an issue security level member from an issue security scheme.

## Issue type properties (4 endpoints)

### Get issue type property keys
`GET /rest/api/3/issuetype/:issueTypeId/properties`
> Returns all the [issue type property](https://developer.atlassian.com/cloud/jira/platform/storing-data-without-a-database/#a-id-jira-entity-properties-a-jira-entity-properties) keys of the issue type.

### Get issue type property
`GET /rest/api/3/issuetype/:issueTypeId/properties/:propertyKey`
> Returns the key and value of the [issue type property](https://developer.atlassian.com/cloud/jira/platform/storing-data-without-a-database/#a-id-jira-entity-properties-a-jira-entity-properties).

### Set issue type property
`PUT /rest/api/3/issuetype/:issueTypeId/properties/:propertyKey`
> Creates or updates the value of the [issue type property](https://developer.atlassian.com/cloud/jira/platform/storing-data-without-a-database/#a-id-jira-entity-properties-a-jira-entity-properties). Us
Body example:
```json
{
  "number": 5,
  "string": "string-value"
}
```

### Delete issue type property
`DELETE /rest/api/3/issuetype/:issueTypeId/properties/:propertyKey`
> Deletes the [issue type property](https://developer.atlassian.com/cloud/jira/platform/storing-data-without-a-database/#a-id-jira-entity-properties-a-jira-entity-properties).

## Issue type schemes (10 endpoints)

### Get all issue type schemes
`GET /rest/api/3/issuetypescheme`
> Returns a [paginated](#pagination) list of issue type schemes.

### Create issue type scheme
`POST /rest/api/3/issuetypescheme`
> Creates an issue type scheme.
Body example:
```json
{
  "defaultIssueTypeId": "10002",
  "description": "A collection of issue types suited to use in a kanban style project.",
  "issueTypeIds": [
    "10001",
    "10002",
    "10003"
  ],
  "name": "Kanban Issue Type Scheme"
}
```

### Get issue type scheme items
`GET /rest/api/3/issuetypescheme/mapping`
> Returns a [paginated](#pagination) list of issue type scheme items.

### Get issue type schemes for projects
`GET /rest/api/3/issuetypescheme/project`
> Returns a [paginated](#pagination) list of issue type schemes and, for each issue type scheme, a list of the projects that use it.

### Assign issue type scheme to project
`PUT /rest/api/3/issuetypescheme/project`
> Assigns an issue type scheme to a project.
Body example:
```json
{
  "issueTypeSchemeId": "10000",
  "projectId": "10000"
}
```

### Update issue type scheme
`PUT /rest/api/3/issuetypescheme/:issueTypeSchemeId`
> Updates an issue type scheme.
Body example:
```json
{
  "defaultIssueTypeId": "10002",
  "description": "A collection of issue types suited to use in a kanban style project.",
  "name": "Kanban Issue Type Scheme"
}
```

### Delete issue type scheme
`DELETE /rest/api/3/issuetypescheme/:issueTypeSchemeId`
> Deletes an issue type scheme.

### Add issue types to issue type scheme
`PUT /rest/api/3/issuetypescheme/:issueTypeSchemeId/issuetype`
> Adds issue types to an issue type scheme.
Body example:
```json
{
  "issueTypeIds": [
    "10000",
    "10002",
    "10003"
  ]
}
```

### Change order of issue types
`PUT /rest/api/3/issuetypescheme/:issueTypeSchemeId/issuetype/move`
> Changes the order of issue types in an issue type scheme.
Body example:
```json
{
  "after": "10008",
  "issueTypeIds": [
    "10001",
    "10004",
    "10002"
  ]
}
```

### Remove issue type from issue type scheme
`DELETE /rest/api/3/issuetypescheme/:issueTypeSchemeId/issuetype/:issueTypeId`
> Removes an issue type from an issue type scheme.

## Issue type screen schemes (11 endpoints)

### Get issue type screen schemes
`GET /rest/api/3/issuetypescreenscheme`
> Returns a [paginated](#pagination) list of issue type screen schemes.

### Create issue type screen scheme
`POST /rest/api/3/issuetypescreenscheme`
> Creates an issue type screen scheme.
Body example:
```json
{
  "issueTypeMappings": [
    {
      "issueTypeId": "default",
      "screenSchemeId": "10001"
    },
    {
      "issueTypeId": "10001",
      "screenSchemeId": "10002"
    },
    {
      "issueTypeId": "10002",
      "screenSchemeId": "10002"
    }
  ],
  "name": "Scrum issue type screen scheme"
}
```

### Get issue type screen scheme items
`GET /rest/api/3/issuetypescreenscheme/mapping`
> Returns a [paginated](#pagination) list of issue type screen scheme items.

### Get issue type screen schemes for projects
`GET /rest/api/3/issuetypescreenscheme/project`
> Returns a [paginated](#pagination) list of issue type screen schemes and, for each issue type screen scheme, a list of the projects that use it.

### Assign issue type screen scheme to project
`PUT /rest/api/3/issuetypescreenscheme/project`
> Assigns an issue type screen scheme to a project.
Body example:
```json
{
  "issueTypeScreenSchemeId": "10001",
  "projectId": "10002"
}
```

### Update issue type screen scheme
`PUT /rest/api/3/issuetypescreenscheme/:issueTypeScreenSchemeId`
> Updates an issue type screen scheme.
Body example:
```json
{
  "description": "Screens for scrum issue types.",
  "name": "Scrum scheme"
}
```

### Delete issue type screen scheme
`DELETE /rest/api/3/issuetypescreenscheme/:issueTypeScreenSchemeId`
> Deletes an issue type screen scheme.

### Append mappings to issue type screen scheme
`PUT /rest/api/3/issuetypescreenscheme/:issueTypeScreenSchemeId/mapping`
> Appends issue type to screen scheme mappings to an issue type screen scheme.
Body example:
```json
{
  "issueTypeMappings": [
    {
      "issueTypeId": "10000",
      "screenSchemeId": "10001"
    },
    {
      "issueTypeId": "10001",
      "screenSchemeId": "10002"
    },
    {
      "issueTypeId": "10002",
      "screenSchemeId": "10002"
    }
  ]
}
```

### Update issue type screen scheme default screen scheme
`PUT /rest/api/3/issuetypescreenscheme/:issueTypeScreenSchemeId/mapping/default`
> Updates the default screen scheme of an issue type screen scheme. The default screen scheme is used for all unmapped issue types.
Body example:
```json
{
  "screenSchemeId": "10010"
}
```

### Remove mappings from issue type screen scheme
`POST /rest/api/3/issuetypescreenscheme/:issueTypeScreenSchemeId/mapping/remove`
> Removes issue type to screen scheme mappings from an issue type screen scheme.
Body example:
```json
{
  "issueTypeIds": [
    "10000",
    "10001",
    "10004"
  ]
}
```

### Get issue type screen scheme projects
`GET /rest/api/3/issuetypescreenscheme/:issueTypeScreenSchemeId/project`
> Returns a [paginated](#pagination) list of projects associated with an issue type screen scheme.

## Issue types (8 endpoints)

### Get all issue types for user
`GET /rest/api/3/issuetype`
> Returns all issue types.

### Create issue type
`POST /rest/api/3/issuetype`
> Creates an issue type.
Body example:
```json
{
  "description": "description",
  "name": "name",
  "type": "standard"
}
```

### Get issue types for project
`GET /rest/api/3/issuetype/project`
> Returns issue types for a project.

### Get issue type
`GET /rest/api/3/issuetype/:id`
> Returns an issue type.

### Update issue type
`PUT /rest/api/3/issuetype/:id`
> Updates the issue type.
Body example:
```json
{
  "avatarId": 1,
  "description": "description",
  "name": "name"
}
```

### Delete issue type
`DELETE /rest/api/3/issuetype/:id`
> Deletes the issue type. If the issue type is in use, all uses are updated with the alternative issue type (`alternativeIssueTypeId`). A list of alternative issue types are obtained from the [Get alter

### Get alternative issue types
`GET /rest/api/3/issuetype/:id/alternatives`
> Returns a list of issue types that can be used to replace the issue type. The alternative issue types are those assigned to the same workflow scheme, field configuration scheme, and screen scheme.

### Load issue type avatar
`POST /rest/api/3/issuetype/:id/avatar2`
> Loads an avatar for the issue type.

## Issue votes (3 endpoints)

### Get votes
`GET /rest/api/3/issue/:issueIdOrKey/votes`
> Returns details about the votes on an issue.

### Add vote
`POST /rest/api/3/issue/:issueIdOrKey/votes`
> Adds the user's vote to an issue. This is the equivalent of the user clicking *Vote* on an issue in Jira.

### Delete vote
`DELETE /rest/api/3/issue/:issueIdOrKey/votes`
> Deletes a user's vote from an issue. This is the equivalent of the user clicking *Unvote* on an issue in Jira.

## Issue watchers (4 endpoints)

### Get is watching issue bulk
`POST /rest/api/3/issue/watching`
> Returns, for the user, details of the watched status of issues from a list. If an issue ID is invalid, the returned watched status is `false`.
Body example:
```json
{
  "issueIds": [
    "10001",
    "10002",
    "10005"
  ]
}
```

### Get issue watchers
`GET /rest/api/3/issue/:issueIdOrKey/watchers`
> Returns the watchers for an issue.

### Add watcher
`POST /rest/api/3/issue/:issueIdOrKey/watchers`
> Adds a user as a watcher of an issue by passing the account ID of the user. For example, `"5b10ac8d82e05b22cc7d4ef5"`. If no user is specified the calling user is added.

### Delete watcher
`DELETE /rest/api/3/issue/:issueIdOrKey/watchers`
> Deletes a user as a watcher of an issue.

## Issue worklog properties (4 endpoints)

### Get worklog property keys
`GET /rest/api/3/issue/:issueIdOrKey/worklog/:worklogId/properties`
> Returns the keys of all properties for a worklog.

### Get worklog property
`GET /rest/api/3/issue/:issueIdOrKey/worklog/:worklogId/properties/:propertyKey`
> Returns the value of a worklog property.

### Set worklog property
`PUT /rest/api/3/issue/:issueIdOrKey/worklog/:worklogId/properties/:propertyKey`
> Sets the value of a worklog property. Use this operation to store custom data against the worklog.

### Delete worklog property
`DELETE /rest/api/3/issue/:issueIdOrKey/worklog/:worklogId/properties/:propertyKey`
> Deletes a worklog property.

## Issue worklogs (10 endpoints)

### Get issue worklogs
`GET /rest/api/3/issue/:issueIdOrKey/worklog`
> Returns worklogs for an issue (ordered by created time), starting from the oldest worklog or from the worklog started on or after a date and time.

### Add worklog
`POST /rest/api/3/issue/:issueIdOrKey/worklog`
> Adds a worklog to an issue.
Body example:
```json
{
  "comment": {
    "content": [
      {
        "content": [
          {
            "text": "I did some work here.",
            "type": "text"
          }
        ],
        "type": "paragraph"
      }
    ],
    "type": "doc",
    "version": 1
  },
  "started": "2021-01-17T12:34:00.000+0000",
  "timeSpentSeconds": 12000,
  "visibility": {
    "identifier": "276f955c-63d7-42c8-9520-92d01dca0625",
    "type": "group"
  }
}
```

### Bulk delete worklogs
`DELETE /rest/api/3/issue/:issueIdOrKey/worklog`
> Deletes a list of worklogs from an issue. This is an experimental API with limitations:
Body example:
```json
{
  "ids": [
    1,
    2,
    5,
    10
  ]
}
```

### Bulk move worklogs
`POST /rest/api/3/issue/:issueIdOrKey/worklog/move`
> Moves a list of worklogs from one issue to another. This is an experimental API with several limitations:
Body example:
```json
{
  "ids": [
    1,
    2,
    5,
    10
  ],
  "issueIdOrKey": "ABC-1234"
}
```

### Get worklog
`GET /rest/api/3/issue/:issueIdOrKey/worklog/:id`
> Returns a worklog.

### Update worklog
`PUT /rest/api/3/issue/:issueIdOrKey/worklog/:id`
> Updates a worklog.
Body example:
```json
{
  "comment": {
    "content": [
      {
        "content": [
          {
            "text": "I did some work here.",
            "type": "text"
          }
        ],
        "type": "paragraph"
      }
    ],
    "type": "doc",
    "version": 1
  },
  "started": "2021-01-17T12:34:00.000+0000",
  "timeSpentSeconds": 12000,
  "visibility": {
    "identifier": "276f955c-63d7-42c8-9520-92d01dca0625",
    "type": "group"
  }
}
```

### Delete worklog
`DELETE /rest/api/3/issue/:issueIdOrKey/worklog/:id`
> Deletes a worklog from an issue.

### Get IDs of deleted worklogs
`GET /rest/api/3/worklog/deleted`
> Returns a list of IDs and delete timestamps for worklogs deleted after a date and time.

### Get worklogs
`POST /rest/api/3/worklog/list`
> Returns worklog details for a list of worklog IDs.
Body example:
```json
{
  "ids": [
    1,
    2,
    5,
    10
  ]
}
```

### Get IDs of updated worklogs
`GET /rest/api/3/worklog/updated`
> Returns a list of IDs and update timestamps for worklogs updated after a date and time.

## Issues (23 endpoints)

### Bulk fetch changelogs
`POST /rest/api/3/changelog/bulkfetch`
> Bulk fetch changelogs for multiple issues and filter by fields

### Get events
`GET /rest/api/3/events`
> Returns all issue events.

### Create issue
`POST /rest/api/3/issue`
> Creates an issue or, where the option to create subtasks is enabled in Jira, a subtask. A transition may be applied, to move the issue or subtask to a workflow step other than the default start step, 

### Archive issue(s) by issue ID/key
`PUT /rest/api/3/issue/archive`
> Enables admins to archive up to 1000 issues in a single request using issue ID/key, returning details of the issue(s) archived in the process and the errors encountered, if any.
Body example:
```json
{
  "issueIdsOrKeys": [
    "PR-1",
    "1001",
    "PROJECT-2"
  ]
}
```

### Archive issue(s) by JQL
`POST /rest/api/3/issue/archive`
> Enables admins to archive up to 100,000 issues in a single request using JQL, returning the URL to check the status of the submitted request.
Body example:
```json
{
  "jql": "project = FOO AND updated < -2y"
}
```

### Bulk create issue
`POST /rest/api/3/issue/bulk`
> Creates upto **50** issues and, where the option to create subtasks is enabled in Jira, subtasks. Transitions may be applied, to move the issues or subtasks to a workflow step other than the default s

### Bulk fetch issues
`POST /rest/api/3/issue/bulkfetch`
> Returns the details for a set of requested issues. You can request up to 100 issues.
Body example:
```json
{
  "expand": [
    "names"
  ],
  "fields": [
    "summary",
    "project",
    "assignee"
  ],
  "fieldsByKeys": false,
  "issueIdsOrKeys": [
    "EX-1",
    "EX-2",
    "10005"
  ],
  "properties": []
}
```

### Get create issue metadata
`GET /rest/api/3/issue/createmeta`
> Returns details of projects, issue types within projects, and, when requested, the create screen fields for each issue type for the user. Use the information to populate the requests in [ Create issue

### Get create metadata issue types for a project
`GET /rest/api/3/issue/createmeta/:projectIdOrKey/issuetypes`
> Returns a page of issue type metadata for a specified project. Use the information to populate the requests in [ Create issue](#api-rest-api-3-issue-post) and [Create issues](#api-rest-api-3-issue-bul

### Get create field metadata for a project and issue type id
`GET /rest/api/3/issue/createmeta/:projectIdOrKey/issuetypes/:issueTypeId`
> Returns a page of field metadata for a specified project and issuetype id. Use the information to populate the requests in [ Create issue](#api-rest-api-3-issue-post) and [Create issues](#api-rest-api

### Get issue limit report
`GET /rest/api/3/issue/limit/report`
> Returns all issues breaching and approaching per-issue limits.

### Unarchive issue(s) by issue keys/ID
`PUT /rest/api/3/issue/unarchive`
> Enables admins to unarchive up to 1000 issues in a single request using issue ID/key, returning details of the issue(s) unarchived in the process and the errors encountered, if any.
Body example:
```json
{
  "issueIdsOrKeys": [
    "PR-1",
    "1001",
    "PROJECT-2"
  ]
}
```

### Get issue
`GET /rest/api/3/issue/:issueIdOrKey`
> Returns the details for an issue.

### Edit issue
`PUT /rest/api/3/issue/:issueIdOrKey`
> Edits an issue. Issue properties may be updated as part of the edit. Please note that issue transition is not supported and is ignored here. To transition an issue, please use [Transition issue](#api-

### Delete issue
`DELETE /rest/api/3/issue/:issueIdOrKey`
> Deletes an issue.

### Assign issue
`PUT /rest/api/3/issue/:issueIdOrKey/assignee`
> Assigns an issue to a user. Use this operation when the calling user does not have the *Edit Issues* permission but has the *Assign issue* permission for the project that the issue is in.
Body example:
```json
{
  "accountId": "5b10ac8d82e05b22cc7d4ef5"
}
```

### Get changelogs
`GET /rest/api/3/issue/:issueIdOrKey/changelog`
> Returns a [paginated](#pagination) list of all changelogs for an issue sorted by date, starting from the oldest.

### Get changelogs by IDs
`POST /rest/api/3/issue/:issueIdOrKey/changelog/list`
> Returns changelogs for an issue specified by a list of changelog IDs.
Body example:
```json
{
  "changelogIds": [
    10001,
    10002
  ]
}
```

### Get edit issue metadata
`GET /rest/api/3/issue/:issueIdOrKey/editmeta`
> Returns the edit screen fields for an issue that are visible to and editable by the user. Use the information to populate the requests in [Edit issue](#api-rest-api-3-issue-issueIdOrKey-put).

### Send notification for issue
`POST /rest/api/3/issue/:issueIdOrKey/notify`
> Creates an email notification for an issue and adds it to the mail queue.

### Get transitions
`GET /rest/api/3/issue/:issueIdOrKey/transitions`
> Returns either all transitions or a transition that can be performed by the user on an issue, based on the issue's status.

### Transition issue
`POST /rest/api/3/issue/:issueIdOrKey/transitions`
> Performs an issue transition and, if the transition has a screen, updates the fields from the transition screen.

### Export archived issue(s)
`PUT /rest/api/3/issues/archive/export`
> Enables admins to retrieve details of all archived issues. Upon a successful request, the admin who submitted it will receive an email with a link to download a CSV file with the issue details.
Body example:
```json
{
  "archivedBy": [
    "uuid-rep-001",
    "uuid-rep-002"
  ],
  "archivedDate": {
    "dateAfter": "2023-01-01",
    "dateBefore": "2023-01-12"
  },
  "archivedDateRange": {
    "dateAfter": "2023-01-01",
    "dateBefore": "2023-01-12"
  },
  "issueTypes": [
    "10001",
    "10002"
  ],
  "projects": [
    "FOO",
    "BAR"
  ],
  "reporters": [
    "uuid-rep-001",
    "uuid-rep-002"
  ]
}
```

## JQL (6 endpoints)

### Get field reference data (GET)
`GET /rest/api/3/jql/autocompletedata`
> Returns reference data for JQL searches. This is a downloadable version of the documentation provided in [Advanced searching - fields reference](https://confluence.atlassian.com/x/gwORLQ) and [Advance

### Get field reference data (POST)
`POST /rest/api/3/jql/autocompletedata`
> Returns reference data for JQL searches. This is a downloadable version of the documentation provided in [Advanced searching - fields reference](https://confluence.atlassian.com/x/gwORLQ) and [Advance
Body example:
```json
{
  "includeCollapsedFields": true,
  "projectIds": [
    10000,
    10001,
    10002
  ]
}
```

### Get field auto complete suggestions
`GET /rest/api/3/jql/autocompletedata/suggestions`
> Returns the JQL search auto complete suggestions for a field.

### Parse JQL query
`POST /rest/api/3/jql/parse`
> Parses and validates JQL queries.
Body example:
```json
{
  "queries": [
    "summary ~ test AND (labels in (urgent, blocker) OR lastCommentedBy = currentUser()) AND status CHANGED AFTER startOfMonth(-1M) ORDER BY updated DESC",
    "issue.property[\"spaces here\"].value in (\"Service requests\", Incidents)",
    "invalid query",
    "summary = test",
    "summary in test",
    "project = INVALID",
    "universe = 42"
  ]
}
```

### Convert user identifiers to account IDs in JQL queries
`POST /rest/api/3/jql/pdcleaner`
> Converts one or more JQL queries with user identifiers (username or user key) to equivalent JQL queries with account IDs.
Body example:
```json
{
  "queryStrings": [
    "assignee = mia",
    "issuetype = Bug AND assignee in (mia) AND reporter in (alana) order by lastViewed DESC"
  ]
}
```

### Sanitize JQL queries
`POST /rest/api/3/jql/sanitize`
> Sanitizes one or more JQL queries by converting readable details into IDs where a user doesn't have permission to view the entity.
Body example:
```json
{
  "queries": [
    {
      "query": "project = 'Sample project'"
    },
    {
      "accountId": "5b10ac8d82e05b22cc7d4ef5",
      "query": "project = 'Sample project'"
    },
    {
      "accountId": "cda2aa1395ac195d951b3387",
      "query": "project = 'Sample project'"
    },
    {
      "accountId": "5b10ac8d82e05b22cc7d4ef5",
      "query": "invalid query"
    }
  ]
}
```

## JQL functions (apps) (3 endpoints)

### Get precomputations (apps)
`GET /rest/api/3/jql/function/computation`
> Returns the list of a function's precomputations along with information about when they were created, updated, and last used. Each precomputation has a `value` \- the JQL fragment to replace the custo

### Update precomputations (apps)
`POST /rest/api/3/jql/function/computation`
> Update the precomputation value of a function created by a Forge/Connect app.
Body example:
```json
{
  "values": [
    {
      "id": "f2ef228b-367f-4c6b-bd9d-0d0e96b5bd7b",
      "value": "issue in (TEST-1, TEST-2, TEST-3)"
    },
    {
      "error": "Error message to be displayed to the user",
      "id": "2a854f11-d0e1-4260-aea8-64a562a7062a"
    }
  ]
}
```

### Get precomputations by ID (apps)
`POST /rest/api/3/jql/function/computation/search`
> Returns function precomputations by IDs, along with information about when they were created, updated, and last used. Each precomputation has a `value` \- the JQL fragment to replace the custom functi
Body example:
```json
{
  "precomputationIDs": [
    "f2ef228b-367f-4c6b-bd9d-0d0e96b5bd7b",
    "2a854f11-d0e1-4260-aea8-64a562a7062a"
  ]
}
```

## Jira expressions (3 endpoints)

### Analyse Jira expression
`POST /rest/api/3/expression/analyse`
> Analyses and validates Jira expressions.
Body example:
```json
{
  "contextVariables": {
    "listOfStrings": "List<String>",
    "record": "{ a: Number, b: String }",
    "value": "User"
  },
  "expressions": [
    "issues.map(issue => issue.properties['property_key'])"
  ]
}
```

### Currently being removed. Evaluate Jira expression
`POST /rest/api/3/expression/eval`
> Endpoint is currently being removed. [More details](https://developer.atlassian.com/changelog/#CHANGE-2046)

### Evaluate Jira expression using enhanced search API
`POST /rest/api/3/expression/evaluate`
> Evaluates a Jira expression and returns its value. The difference between this and `eval` is that this endpoint uses the enhanced search API when evaluating JQL queries. This API is eventually consist

## Jira settings (4 endpoints)

### Get application property
`GET /rest/api/3/application-properties`
> Returns all application properties or an application property.

### Get advanced settings
`GET /rest/api/3/application-properties/advanced-settings`
> Returns the application properties that are accessible on the *Advanced Settings* page. To navigate to the *Advanced Settings* page in Jira, choose the Jira icon > **Jira settings** > **System**, **Ge

### Set application property
`PUT /rest/api/3/application-properties/:id`
> Changes the value of an application property. For example, you can change the value of the `jira.clone.prefix` from its default value of *CLONE -* to *Clone -* if you prefer sentence case capitalizati
Body example:
```json
{
  "id": "jira.home",
  "value": "/var/jira/jira-home"
}
```

### Get global settings
`GET /rest/api/3/configuration`
> Returns the [global settings](https://confluence.atlassian.com/x/qYXKM) in Jira. These settings determine whether optional features (for example, subtasks, time tracking, and others) are enabled. If t

## Labels (1 endpoints)

### Get all labels
`GET /rest/api/3/label`
> Returns a [paginated](#pagination) list of labels.

## License metrics (3 endpoints)

### Get license
`GET /rest/api/3/instance/license`
> Returns licensing information about the Jira instance.

### Get approximate license count
`GET /rest/api/3/license/approximateLicenseCount`
> Returns the approximate number of user accounts across all Jira licenses. Note that this information is cached with a 7-day lifecycle and could be stale at the time of call.

### Get approximate application license count
`GET /rest/api/3/license/approximateLicenseCount/product/:applicationKey`
> Returns the total approximate number of user accounts for a single Jira license. Note that this information is cached with a 7-day lifecycle and could be stale at the time of call.

## Migration of Connect modules to Forge (2 endpoints)

### Get Connect issue field migration task
`GET /rest/atlassian-connect/1/migration/:connectKey/:jiraIssueFieldsKey/task`
> Returns the details of a Connect issue field's migration to Forge.

### Submit Connect issue field migration task
`POST /rest/atlassian-connect/1/migration/:connectKey/:jiraIssueFieldsKey/task`
> Submits a request to trigger migration of connect issue field to its Forge custom field counterpart.

## Myself (6 endpoints)

### Get preference
`GET /rest/api/3/mypreferences`
> Returns the value of a preference of the current user.

### Set preference
`PUT /rest/api/3/mypreferences`
> Creates a preference for the user or updates a preference's value by sending a plain text string. For example, `false`. An arbitrary preference can be created with the value containing up to 255 chara

### Delete preference
`DELETE /rest/api/3/mypreferences`
> Deletes a preference of the user, which restores the default value of system defined settings.

### Get locale
`GET /rest/api/3/mypreferences/locale`
> Returns the locale for the user.

### Set locale
`PUT /rest/api/3/mypreferences/locale`
> Deprecated, use [ Update a user profile](https://developer.atlassian.com/cloud/admin/user-management/rest/#api-users-account-id-manage-profile-patch) from the user management REST API instead.
Body example:
```json
{
  "locale": "en_US"
}
```

### Get current user
`GET /rest/api/3/myself`
> Returns details for the current user.

## Permission schemes (9 endpoints)

### Get all permission schemes
`GET /rest/api/3/permissionscheme`
> Returns all permission schemes.

### Create permission scheme
`POST /rest/api/3/permissionscheme`
> Creates a new permission scheme. You can create a permission scheme with or without defining a set of permission grants.
Body example:
```json
{
  "description": "description",
  "name": "Example permission scheme",
  "permissions": [
    {
      "holder": {
        "parameter": "jira-core-users",
        "type": "group",
        "value": "ca85fac0-d974-40ca-a615-7af99c48d24f"
      },
      "permission": "ADMINISTER_PROJECTS"
    }
  ]
}
```

### Get permission scheme
`GET /rest/api/3/permissionscheme/:schemeId`
> Returns a permission scheme.

### Update permission scheme
`PUT /rest/api/3/permissionscheme/:schemeId`
> Updates a permission scheme. Below are some important things to note when using this resource:
Body example:
```json
{
  "description": "description",
  "name": "Example permission scheme",
  "permissions": [
    {
      "holder": {
        "parameter": "jira-core-users",
        "type": "group",
        "value": "ca85fac0-d974-40ca-a615-7af99c48d24f"
      },
      "permission": "ADMINISTER_PROJECTS"
    }
  ]
}
```

### Delete permission scheme
`DELETE /rest/api/3/permissionscheme/:schemeId`
> Deletes a permission scheme.

### Get permission scheme grants
`GET /rest/api/3/permissionscheme/:schemeId/permission`
> Returns all permission grants for a permission scheme.

### Create permission grant
`POST /rest/api/3/permissionscheme/:schemeId/permission`
> Creates a permission grant in a permission scheme.
Body example:
```json
{
  "holder": {
    "parameter": "jira-core-users",
    "type": "group",
    "value": "ca85fac0-d974-40ca-a615-7af99c48d24f"
  },
  "permission": "ADMINISTER_PROJECTS"
}
```

### Get permission scheme grant
`GET /rest/api/3/permissionscheme/:schemeId/permission/:permissionId`
> Returns a permission grant.

### Delete permission scheme grant
`DELETE /rest/api/3/permissionscheme/:schemeId/permission/:permissionId`
> Deletes a permission grant from a permission scheme. See [About permission schemes and grants](../api-group-permission-schemes/#about-permission-schemes-and-grants) for more details.

## Permissions (4 endpoints)

### Get my permissions
`GET /rest/api/3/mypermissions`
> Returns a list of permissions indicating which permissions the user has. Details of the user's permissions can be obtained in a global, project, issue or comment context.

### Get all permissions
`GET /rest/api/3/permissions`
> Returns all permissions, including:

### Get bulk permissions
`POST /rest/api/3/permissions/check`
> Returns:
Body example:
```json
{
  "accountId": "5b10a2844c20165700ede21g",
  "globalPermissions": [
    "ADMINISTER"
  ],
  "projectPermissions": [
    {
      "issues": [
        10010,
        10011,
        10012,
        10013,
        10014
      ],
      "permissions": [
        "EDIT_ISSUES"
      ],
      "projects": [
        10001
      ]
    }
  ]
}
```

### Get permitted projects
`POST /rest/api/3/permissions/project`
> Returns all the projects where the user is granted a list of project permissions.

## Plans (7 endpoints)

### Get plans paginated
`GET /rest/api/3/plans/plan`
> Returns a [paginated](#pagination) list of plans.

### Create plan
`POST /rest/api/3/plans/plan`
> Creates a plan.

### Get plan
`GET /rest/api/3/plans/plan/:planId`
> Returns a plan.

### Update plan
`PUT /rest/api/3/plans/plan/:planId`
> Updates any of the following details of a plan using [JSON Patch](https://datatracker.ietf.org/doc/html/rfc6902).
Body example:
```json
[{"op": "replace", "path": "/scheduling/estimation", "value": "Days"}]

```

### Archive plan
`PUT /rest/api/3/plans/plan/:planId/archive`
> Archives a plan.

### Duplicate plan
`POST /rest/api/3/plans/plan/:planId/duplicate`
> Duplicates a plan.
Body example:
```json
{
  "name": "Copied Plan"
}
```

### Trash plan
`PUT /rest/api/3/plans/plan/:planId/trash`
> Moves a plan to trash.

## Priority schemes (8 endpoints)

### Get priority schemes
`GET /rest/api/3/priorityscheme`
> Returns a [paginated](#pagination) list of priority schemes.

### Create priority scheme
`POST /rest/api/3/priorityscheme`
> Creates a new priority scheme.
Body example:
```json
{
  "defaultPriorityId": 10001,
  "description": "My priority scheme description",
  "mappings": {
    "in": {
      "10002": 10000,
      "10005": 10001,
      "10006": 10001,
      "10008": 10003
    },
    "out": {}
  },
  "name": "My new priority scheme",
  "priorityIds": [
    10000,
    10001,
    10003
  ],
  "projectIds": [
    10005,
    10006,
    10007
  ]
}
```

### Suggested priorities for mappings
`POST /rest/api/3/priorityscheme/mappings`
> Returns a [paginated](#pagination) list of priorities that would require mapping, given a change in priorities or projects associated with a priority scheme.
Body example:
```json
{
  "maxResults": 50,
  "priorities": {
    "add": [
      10001,
      10002
    ],
    "remove": [
      10003
    ]
  },
  "projects": {
    "add": [
      10021
    ]
  },
  "schemeId": 10005,
  "startAt": 0
}
```

### Get available priorities by priority scheme
`GET /rest/api/3/priorityscheme/priorities/available`
> Returns a [paginated](#pagination) list of priorities available for adding to a priority scheme.

### Update priority scheme
`PUT /rest/api/3/priorityscheme/:schemeId`
> Updates a priority scheme. This includes its details, the lists of priorities and projects in it

### Delete priority scheme
`DELETE /rest/api/3/priorityscheme/:schemeId`
> Deletes a priority scheme.

### Get priorities by priority scheme
`GET /rest/api/3/priorityscheme/:schemeId/priorities`
> Returns a [paginated](#pagination) list of priorities by scheme.

### Get projects by priority scheme
`GET /rest/api/3/priorityscheme/:schemeId/projects`
> Returns a [paginated](#pagination) list of projects by scheme.

## Project avatars (4 endpoints)

### Set project avatar
`PUT /rest/api/3/project/:projectIdOrKey/avatar`
> Sets the avatar displayed for a project.
Body example:
```json
{
  "id": "10010"
}
```

### Delete project avatar
`DELETE /rest/api/3/project/:projectIdOrKey/avatar/:id`
> Deletes a custom avatar from a project. Note that system avatars cannot be deleted.

### Load project avatar
`POST /rest/api/3/project/:projectIdOrKey/avatar2`
> Loads an avatar for a project.

### Get all project avatars
`GET /rest/api/3/project/:projectIdOrKey/avatars`
> Returns all project avatars, grouped by system and custom avatars.

## Project categories (5 endpoints)

### Get all project categories
`GET /rest/api/3/projectCategory`
> Returns all project categories.

### Create project category
`POST /rest/api/3/projectCategory`
> Creates a project category.
Body example:
```json
{
  "description": "Created Project Category",
  "name": "CREATED"
}
```

### Get project category by ID
`GET /rest/api/3/projectCategory/:id`
> Returns a project category.

### Update project category
`PUT /rest/api/3/projectCategory/:id`
> Updates a project category.
Body example:
```json
{
  "description": "Updated Project Category",
  "name": "UPDATED"
}
```

### Delete project category
`DELETE /rest/api/3/projectCategory/:id`
> Deletes a project category.

## Project classification levels (4 endpoints)

### Get the classification configuration for a project
`GET /rest/api/3/project/:projectIdOrKey/classification-config`
> Returns the consolidated classification configuration for a project's admin settings page.

### Get the default data classification level of a project
`GET /rest/api/3/project/:projectIdOrKey/classification-level/default`
> Returns the default data classification for a project.

### Update the default data classification level of a project
`PUT /rest/api/3/project/:projectIdOrKey/classification-level/default`
> Updates the default data classification level for a project.
Body example:
```json
{
  "id": "ari:cloud:platform::classification-tag/dec24c48-5073-4c25-8fef-9d81a992c30c"
}
```

### Remove the default data classification level from a project
`DELETE /rest/api/3/project/:projectIdOrKey/classification-level/default`
> Remove the default data classification level for a project.

## Project components (8 endpoints)

### Find components for projects
`GET /rest/api/3/component`
> Returns a [paginated](#pagination) list of all components in a project, including global (Compass) components when applicable.

### Create component
`POST /rest/api/3/component`
> Creates a component. Use components to provide containers for issues within a project. Use components to provide containers for issues within a project.
Body example:
```json
{
  "assigneeType": "PROJECT_LEAD",
  "description": "This is a Jira component",
  "isAssigneeTypeValid": false,
  "leadAccountId": "5b10a2844c20165700ede21g",
  "name": "Component 1",
  "project": "HSP"
}
```

### Get component
`GET /rest/api/3/component/:id`
> Returns a component.

### Update component
`PUT /rest/api/3/component/:id`
> Updates a component. Any fields included in the request are overwritten. If `leadAccountId` is an empty string ("") the component lead is removed.
Body example:
```json
{
  "assigneeType": "PROJECT_LEAD",
  "description": "This is a Jira component",
  "isAssigneeTypeValid": false,
  "leadAccountId": "5b10a2844c20165700ede21g",
  "name": "Component 1"
}
```

### Delete component
`DELETE /rest/api/3/component/:id`
> Deletes a component.

### Get component issues count
`GET /rest/api/3/component/:id/relatedIssueCounts`
> Returns the counts of issues assigned to the component.

### Get project components paginated
`GET /rest/api/3/project/:projectIdOrKey/component`
> Returns a [paginated](#pagination) list of all components in a project. See the [Get project components](#api-rest-api-3-project-projectIdOrKey-components-get) resource if you want to get a full list 

### Get project components
`GET /rest/api/3/project/:projectIdOrKey/components`
> Returns all components in a project. See the [Get project components paginated](#api-rest-api-3-project-projectIdOrKey-component-get) resource if you want to get a full list of components with paginat

## Project email (2 endpoints)

### Get project's sender email
`GET /rest/api/3/project/:projectId/email`
> Returns the [project's sender email address](https://confluence.atlassian.com/x/dolKLg).

### Set project's sender email
`PUT /rest/api/3/project/:projectId/email`
> Sets the [project's sender email address](https://confluence.atlassian.com/x/dolKLg).
Body example:
```json
{
  "emailAddress": "jira@example.atlassian.net"
}
```

## Project features (2 endpoints)

### Get project features
`GET /rest/api/3/project/:projectIdOrKey/features`
> Returns the list of features for a project.

### Set project feature state
`PUT /rest/api/3/project/:projectIdOrKey/features/:featureKey`
> Sets the state of a project feature.
Body example:
```json
{
  "state": "ENABLED"
}
```

## Project key and name validation (3 endpoints)

### Validate project key
`GET /rest/api/3/projectvalidate/key`
> Validates a project key by confirming the key is a valid string and not in use.

### Get valid project key
`GET /rest/api/3/projectvalidate/validProjectKey`
> Validates a project key and, if the key is invalid or in use, generates a valid random string for the project key.

### Get valid project name
`GET /rest/api/3/projectvalidate/validProjectName`
> Checks that a project name isn't in use. If the name isn't in use, the passed string is returned. If the name is in use, this operation attempts to generate a valid project name based on the one suppl

## Project permission schemes (4 endpoints)

### Get project issue security scheme
`GET /rest/api/3/project/:projectKeyOrId/issuesecuritylevelscheme`
> Returns the [issue security scheme](https://confluence.atlassian.com/x/J4lKLg) associated with the project.

### Get assigned permission scheme
`GET /rest/api/3/project/:projectKeyOrId/permissionscheme`
> Gets the [permission scheme](https://confluence.atlassian.com/x/yodKLg) associated with the project.

### Assign permission scheme
`PUT /rest/api/3/project/:projectKeyOrId/permissionscheme`
> Assigns a permission scheme with a project. See [Managing project permissions](https://confluence.atlassian.com/x/yodKLg) for more information about permission schemes.
Body example:
```json
{
  "id": 10000
}
```

### Get project issue security levels
`GET /rest/api/3/project/:projectKeyOrId/securitylevel`
> Returns all [issue security](https://confluence.atlassian.com/x/J4lKLg) levels for the project that the user has access to.

## Project properties (4 endpoints)

### Get project property keys
`GET /rest/api/3/project/:projectIdOrKey/properties`
> Returns all [project property](https://developer.atlassian.com/cloud/jira/platform/storing-data-without-a-database/#a-id-jira-entity-properties-a-jira-entity-properties) keys for the project.

### Get project property
`GET /rest/api/3/project/:projectIdOrKey/properties/:propertyKey`
> Returns the value of a [project property](https://developer.atlassian.com/cloud/jira/platform/storing-data-without-a-database/#a-id-jira-entity-properties-a-jira-entity-properties).

### Set project property
`PUT /rest/api/3/project/:projectIdOrKey/properties/:propertyKey`
> Sets the value of the [project property](https://developer.atlassian.com/cloud/jira/platform/storing-data-without-a-database/#a-id-jira-entity-properties-a-jira-entity-properties). You can use project
Body example:
```json
{
  "number": 5,
  "string": "string-value"
}
```

### Delete project property
`DELETE /rest/api/3/project/:projectIdOrKey/properties/:propertyKey`
> Deletes the [property](https://developer.atlassian.com/cloud/jira/platform/storing-data-without-a-database/#a-id-jira-entity-properties-a-jira-entity-properties) from a project.

## Project role actors (6 endpoints)

### Set actors for project role
`PUT /rest/api/3/project/:projectIdOrKey/role/:id`
> Sets the actors for a project role for a project, replacing all existing actors.
Body example:
```json
{
  "categorisedActors": {
    "atlassian-group-role-actor-id": [
      "952d12c3-5b5b-4d04-bb32-44d383afc4b2"
    ],
    "atlassian-user-role-actor": [
      "12345678-9abc-def1-2345-6789abcdef12"
    ]
  }
}
```

### Add actors to project role
`POST /rest/api/3/project/:projectIdOrKey/role/:id`
> Adds actors to a project role for the project.
Body example:
```json
{
  "groupId": [
    "952d12c3-5b5b-4d04-bb32-44d383afc4b2"
  ]
}
```

### Delete actors from project role
`DELETE /rest/api/3/project/:projectIdOrKey/role/:id`
> Deletes actors from a project role for the project.

### Get default actors for project role
`GET /rest/api/3/role/:id/actors`
> Returns the [default actors](#api-rest-api-3-resolution-get) for the project role.

### Add default actors to project role
`POST /rest/api/3/role/:id/actors`
> Adds [default actors](#api-rest-api-3-resolution-get) to a role. You may add groups or users, but you cannot add groups and users in the same request.
Body example:
```json
{
  "user": [
    "admin"
  ]
}
```

### Delete default actors from project role
`DELETE /rest/api/3/role/:id/actors`
> Deletes the [default actors](#api-rest-api-3-resolution-get) from a project role. You may delete a group or user, but you cannot delete a group and a user in the same request.

## Project roles (9 endpoints)

### Get project roles for project
`GET /rest/api/3/project/:projectIdOrKey/role`
> Returns a list of [project roles](https://support.atlassian.com/jira-cloud-administration/docs/manage-project-roles/) for the project returning the name and self URL for each role.

### Get project role for project
`GET /rest/api/3/project/:projectIdOrKey/role/:id`
> Returns a project role's details and actors associated with the project. The list of actors is sorted by display name.

### Get project role details
`GET /rest/api/3/project/:projectIdOrKey/roledetails`
> Returns all [project roles](https://support.atlassian.com/jira-cloud-administration/docs/manage-project-roles/) and the details for each role. Note that the list of project roles is common to all proj

### Get all project roles
`GET /rest/api/3/role`
> Gets a list of all project roles, complete with project role details and default actors.

### Create project role
`POST /rest/api/3/role`
> Creates a new project role with no [default actors](#api-rest-api-3-resolution-get). You can use the [Add default actors to project role](#api-rest-api-3-role-id-actors-post) operation to add default 
Body example:
```json
{
  "description": "A project role that represents developers in a project",
  "name": "Developers"
}
```

### Get project role by ID
`GET /rest/api/3/role/:id`
> Gets the project role details and the default actors associated with the role. The list of default actors is sorted by display name.

### Fully update project role
`PUT /rest/api/3/role/:id`
> Updates the project role's name and description. You must include both a name and a description in the request.
Body example:
```json
{
  "description": "A project role that represents developers in a project",
  "name": "Developers"
}
```

### Partial update project role
`POST /rest/api/3/role/:id`
> Updates either the project role's name or its description.
Body example:
```json
{
  "description": "A project role that represents developers in a project",
  "name": "Developers"
}
```

### Delete project role
`DELETE /rest/api/3/role/:id`
> Deletes a project role. You must specify a replacement project role if you wish to delete a project role that is in use.

## Project templates (5 endpoints)

### Create custom project
`POST /rest/api/3/project-template`
> Creates a project based on a custom template provided in the request.

### Edit a custom project template
`PUT /rest/api/3/project-template/edit-template`
> Edit custom template

### Gets a custom project template
`GET /rest/api/3/project-template/live-template`
> Get custom template

### Deletes a custom project template
`DELETE /rest/api/3/project-template/remove-template`
> Remove custom template

### Save a custom project template
`POST /rest/api/3/project-template/save-template`
> Save custom template

## Project types (4 endpoints)

### Get all project types
`GET /rest/api/3/project/type`
> Returns all [project types](https://confluence.atlassian.com/x/Var1Nw), whether or not the instance has a valid license for each type.

### Get licensed project types
`GET /rest/api/3/project/type/accessible`
> Returns all [project types](https://confluence.atlassian.com/x/Var1Nw) with a valid license.

### Get project type by key
`GET /rest/api/3/project/type/:projectTypeKey`
> Returns a [project type](https://confluence.atlassian.com/x/Var1Nw).

### Get accessible project type by key
`GET /rest/api/3/project/type/:projectTypeKey/accessible`
> Returns a [project type](https://confluence.atlassian.com/x/Var1Nw) if it is accessible to the user.

## Project versions (15 endpoints)

### Get project versions paginated
`GET /rest/api/3/project/:projectIdOrKey/version`
> Returns a [paginated](#pagination) list of all versions in a project. See the [Get project versions](#api-rest-api-3-project-projectIdOrKey-versions-get) resource if you want to get a full list of ver

### Get project versions
`GET /rest/api/3/project/:projectIdOrKey/versions`
> Returns all versions in a project. The response is not paginated. Use [Get project versions paginated](#api-rest-api-3-project-projectIdOrKey-version-get) if you want to get the versions in a project 

### Create version
`POST /rest/api/3/version`
> Creates a project version.
Body example:
```json
{
  "archived": false,
  "description": "An excellent version",
  "name": "New Version 1",
  "projectId": 10000,
  "releaseDate": "2010-07-06",
  "released": true
}
```

### Get version
`GET /rest/api/3/version/:id`
> Returns a project version.

### Update version
`PUT /rest/api/3/version/:id`
> Updates a project version.
Body example:
```json
{
  "archived": false,
  "description": "An excellent version",
  "id": "10000",
  "name": "New Version 1",
  "overdue": true,
  "projectId": 10000,
  "releaseDate": "2010-07-06",
  "released": true,
  "self": "https://your-domain.atlassian.net/rest/api/~ver~/version/10000",
  "userReleaseDate": "6/Jul/2010"
}
```

### Delete version
`DELETE /rest/api/3/version/:id`
> Deletes a project version.

### Merge versions
`PUT /rest/api/3/version/:id/mergeto/:moveIssuesTo`
> Merges two project versions. The merge is completed by deleting the version specified in `id` and replacing any occurrences of its ID in `fixVersion` with the version ID specified in `moveIssuesTo`.

### Move version
`POST /rest/api/3/version/:id/move`
> Modifies the version's sequence within the project, which affects the display order of the versions in Jira.
Body example:
```json
{
  "after": "https://your-domain.atlassian.net/rest/api/~ver~/version/10000"
}
```

### Get version's related issues count
`GET /rest/api/3/version/:id/relatedIssueCounts`
> Returns the following counts for a version:

### Get related work
`GET /rest/api/3/version/:id/relatedwork`
> Returns related work items for the given version id.

### Update related work
`PUT /rest/api/3/version/:id/relatedwork`
> Updates the given related work. You can only update generic link related works via Rest APIs. Any archived version related works can't be edited.
Body example:
```json
{
  "category": "Design",
  "relatedWorkId": "fabcdef6-7878-1234-beaf-43211234abcd",
  "title": "Design link",
  "url": "https://www.atlassian.com"
}
```

### Create related work
`POST /rest/api/3/version/:id/relatedwork`
> Creates a related work for the given version. You can only create a generic link type of related works via this API. relatedWorkId will be auto-generated UUID, that does not need to be provided.
Body example:
```json
{
  "category": "Design",
  "title": "Design link",
  "url": "https://www.atlassian.com"
}
```

### Delete and replace version
`POST /rest/api/3/version/:id/removeAndSwap`
> Deletes a project version.

### Get version's unresolved issues count
`GET /rest/api/3/version/:id/unresolvedIssueCount`
> Returns counts of the issues and unresolved issues for the project version.

### Delete related work
`DELETE /rest/api/3/version/:versionId/relatedwork/:relatedWorkId`
> Deletes the given related work for the given version.

## Projects (13 endpoints)

### Get all projects
`GET /rest/api/3/project`
> Returns all projects visible to the user. Deprecated, use [ Get projects paginated](#api-rest-api-3-project-search-get) that supports search and pagination.

### Create project
`POST /rest/api/3/project`
> Creates a project based on a project type template, as shown in the following table:
Body example:
```json
{
  "assigneeType": "PROJECT_LEAD",
  "avatarId": 10200,
  "categoryId": 10120,
  "description": "Cloud migration initiative",
  "issueSecurityScheme": 10001,
  "key": "EX",
  "leadAccountId": "5b10a0effa615349cb016cd8",
  "name": "Example",
  "notificationScheme": 10021,
  "permissionScheme": 10011,
  "projectTemplateKey": "com.atlassian.jira-core-project-templates:jira-core-simplified-process-control",
  "projectTypeKey": "business",
  "url": "http://atlassian.com"
}
```

### Get recent projects
`GET /rest/api/3/project/recent`
> Returns a list of up to 20 projects recently viewed by the user that are still visible to the user.

### Get projects paginated
`GET /rest/api/3/project/search`
> Returns a [paginated](#pagination) list of projects visible to the user.

### Get project
`GET /rest/api/3/project/:projectIdOrKey`
> Returns the [project details](https://confluence.atlassian.com/x/ahLpNw) for a project.

### Update project
`PUT /rest/api/3/project/:projectIdOrKey`
> Updates the [project details](https://confluence.atlassian.com/x/ahLpNw) of a project.
Body example:
```json
{
  "assigneeType": "PROJECT_LEAD",
  "avatarId": 10200,
  "categoryId": 10120,
  "description": "Cloud migration initiative",
  "issueSecurityScheme": 10001,
  "key": "EX",
  "leadAccountId": "5b10a0effa615349cb016cd8",
  "name": "Example",
  "notificationScheme": 10021,
  "permissionScheme": 10011,
  "url": "http://atlassian.com"
}
```

### Delete project
`DELETE /rest/api/3/project/:projectIdOrKey`
> Deletes a project.

### Archive project
`POST /rest/api/3/project/:projectIdOrKey/archive`
> Archives a project. You can't delete a project if it's archived. To delete an archived project, restore the project and then delete it. To restore a project, use the Jira UI.

### Delete project asynchronously
`POST /rest/api/3/project/:projectIdOrKey/delete`
> Deletes a project asynchronously.

### Restore deleted or archived project
`POST /rest/api/3/project/:projectIdOrKey/restore`
> Restores a project that has been archived or placed in the Jira recycle bin.

### Get all statuses for project
`GET /rest/api/3/project/:projectIdOrKey/statuses`
> Returns the valid statuses for a project. The statuses are grouped by issue type, as each project has a set of valid issue types and each issue type has a set of valid statuses.

### Get project issue type hierarchy
`GET /rest/api/3/project/:projectId/hierarchy`
> Get the issue type hierarchy for a next-gen project.

### Get project notification scheme
`GET /rest/api/3/project/:projectKeyOrId/notificationscheme`
> Gets a [notification scheme](https://confluence.atlassian.com/x/8YdKLg) associated with the project.

## Screen schemes (4 endpoints)

### Get screen schemes
`GET /rest/api/3/screenscheme`
> Returns a [paginated](#pagination) list of screen schemes.

### Create screen scheme
`POST /rest/api/3/screenscheme`
> Creates a screen scheme.
Body example:
```json
{
  "description": "Manage employee data",
  "name": "Employee screen scheme",
  "screens": {
    "default": 10017,
    "edit": 10019,
    "view": 10020
  }
}
```

### Update screen scheme
`PUT /rest/api/3/screenscheme/:screenSchemeId`
> Updates a screen scheme. Only screen schemes used in classic projects can be updated.
Body example:
```json
{
  "name": "Employee screen scheme v2",
  "screens": {
    "create": "10019",
    "default": "10018"
  }
}
```

### Delete screen scheme
`DELETE /rest/api/3/screenscheme/:screenSchemeId`
> Deletes a screen scheme. A screen scheme cannot be deleted if it is used in an issue type screen scheme.

## Screen tab fields (4 endpoints)

### Get all screen tab fields
`GET /rest/api/3/screens/:screenId/tabs/:tabId/fields`
> Returns all fields for a screen tab.

### Add screen tab field
`POST /rest/api/3/screens/:screenId/tabs/:tabId/fields`
> Adds a field to a screen tab.
Body example:
```json
{
  "fieldId": "summary"
}
```

### Remove screen tab field
`DELETE /rest/api/3/screens/:screenId/tabs/:tabId/fields/:id`
> Removes a field from a screen tab.

### Move screen tab field
`POST /rest/api/3/screens/:screenId/tabs/:tabId/fields/:id/move`
> Moves a screen tab field.

## Screen tabs (6 endpoints)

### Get bulk screen tabs
`GET /rest/api/3/screens/tabs`
> Returns the list of tabs for a bulk of screens.

### Get all screen tabs
`GET /rest/api/3/screens/:screenId/tabs`
> Returns the list of tabs for a screen.

### Create screen tab
`POST /rest/api/3/screens/:screenId/tabs`
> Creates a tab for a screen.
Body example:
```json
{
  "name": "Fields Tab"
}
```

### Update screen tab
`PUT /rest/api/3/screens/:screenId/tabs/:tabId`
> Updates the name of a screen tab.

### Delete screen tab
`DELETE /rest/api/3/screens/:screenId/tabs/:tabId`
> Deletes a screen tab.

### Move screen tab
`POST /rest/api/3/screens/:screenId/tabs/:tabId/move/:pos`
> Moves a screen tab.

## Screens (7 endpoints)

### Get screens for a field
`GET /rest/api/3/field/:fieldId/screens`
> Returns a [paginated](#pagination) list of the screens a field is used in.

### Get screens
`GET /rest/api/3/screens`
> Returns a [paginated](#pagination) list of all screens or those specified by one or more screen IDs.

### Create screen
`POST /rest/api/3/screens`
> Creates a screen with a default field tab.
Body example:
```json
{
  "description": "Enables changes to resolution and linked issues.",
  "name": "Resolve Security Issue Screen"
}
```

### Add field to default screen
`POST /rest/api/3/screens/addToDefault/:fieldId`
> Adds a field to the default tab of the default screen.

### Update screen
`PUT /rest/api/3/screens/:screenId`
> Updates a screen. Only screens used in classic projects can be updated.
Body example:
```json
{
  "description": "Enables changes to resolution and linked issues for accessibility related issues.",
  "name": "Resolve Accessibility Issue Screen"
}
```

### Delete screen
`DELETE /rest/api/3/screens/:screenId`
> Deletes a screen. A screen cannot be deleted if it is used in a screen scheme, workflow, or workflow draft.

### Get available screen fields
`GET /rest/api/3/screens/:screenId/availableFields`
> Returns the fields that can be added to a tab on a screen.

## Server info (1 endpoints)

### Get Jira instance info
`GET /rest/api/3/serverInfo`
> Returns information about the Jira instance.

## Service Registry (1 endpoints)

### Retrieve the attributes of service registries
`GET /rest/atlassian-connect/1/service-registry`
> Retrieve the attributes of given service registries.

## Status (9 endpoints)

### Bulk get statuses
`GET /rest/api/3/statuses`
> Returns a list of the statuses specified by one or more status IDs.

### Bulk update statuses
`PUT /rest/api/3/statuses`
> Updates statuses by ID.
Body example:
```json
{
  "statuses": [
    {
      "description": "The issue is resolved",
      "id": "1000",
      "name": "Finished",
      "statusCategory": "DONE"
    }
  ]
}
```

### Bulk create statuses
`POST /rest/api/3/statuses`
> Creates statuses for a global or project scope.
Body example:
```json
{
  "scope": {
    "project": {
      "id": "1"
    },
    "type": "PROJECT"
  },
  "statuses": [
    {
      "description": "The issue is resolved",
      "name": "Finished",
      "statusCategory": "DONE"
    }
  ]
}
```

### Bulk delete Statuses
`DELETE /rest/api/3/statuses`
> Deletes statuses by ID.

### Bulk get statuses by name
`GET /rest/api/3/statuses/byNames`
> Returns a list of the statuses specified by one or more status names.

### Search statuses paginated
`GET /rest/api/3/statuses/search`
> Returns a [paginated](https://developer.atlassian.com/cloud/jira/platform/rest/v3/intro/#pagination) list of statuses that match a search on name or project.

### Get issue type usages by status and project
`GET /rest/api/3/statuses/:statusId/project/:projectId/issueTypeUsages`
> Returns a page of issue types in a project using a given status.

### Get project usages by status
`GET /rest/api/3/statuses/:statusId/projectUsages`
> Returns a page of projects using a given status.

### Get workflow usages by status
`GET /rest/api/3/statuses/:statusId/workflowUsages`
> Returns a page of workflows using a given status.

## Tasks (2 endpoints)

### Get task
`GET /rest/api/3/task/:taskId`
> Returns the status of a [long-running asynchronous task](#async).

### Cancel task
`POST /rest/api/3/task/:taskId/cancel`
> Cancels a task.

## Teams in plan (9 endpoints)

### Get teams in plan paginated
`GET /rest/api/3/plans/plan/:planId/team`
> Returns a [paginated](#pagination) list of plan-only and Atlassian teams in a plan.

### Add Atlassian team to plan
`POST /rest/api/3/plans/plan/:planId/team/atlassian`
> Adds an existing Atlassian team to a plan and configures their plannning settings.
Body example:
```json
{
  "capacity": 200,
  "id": "AtlassianTeamId",
  "issueSourceId": 0,
  "planningStyle": "Scrum",
  "sprintLength": 2
}
```

### Get Atlassian team in plan
`GET /rest/api/3/plans/plan/:planId/team/atlassian/:atlassianTeamId`
> Returns planning settings for an Atlassian team in a plan.

### Update Atlassian team in plan
`PUT /rest/api/3/plans/plan/:planId/team/atlassian/:atlassianTeamId`
> Updates any of the following planning settings of an Atlassian team in a plan using [JSON Patch](https://datatracker.ietf.org/doc/html/rfc6902).
Body example:
```json
[{"op": "replace", "path": "/planningStyle", "value": "Kanban"}]

```

### Remove Atlassian team from plan
`DELETE /rest/api/3/plans/plan/:planId/team/atlassian/:atlassianTeamId`
> Removes an Atlassian team from a plan and deletes their planning settings.

### Create plan-only team
`POST /rest/api/3/plans/plan/:planId/team/planonly`
> Creates a plan-only team and configures their planning settings.
Body example:
```json
{
  "capacity": 200,
  "issueSourceId": 0,
  "memberAccountIds": [
    "member1AccountId",
    "member2AccountId"
  ],
  "name": "Team1",
  "planningStyle": "Scrum",
  "sprintLength": 2
}
```

### Get plan-only team
`GET /rest/api/3/plans/plan/:planId/team/planonly/:planOnlyTeamId`
> Returns planning settings for a plan-only team.

### Update plan-only team
`PUT /rest/api/3/plans/plan/:planId/team/planonly/:planOnlyTeamId`
> Updates any of the following planning settings of a plan-only team using [JSON Patch](https://datatracker.ietf.org/doc/html/rfc6902).
Body example:
```json
[{"op": "replace", "path": "/planningStyle", "value": "Kanban"}]

```

### Delete plan-only team
`DELETE /rest/api/3/plans/plan/:planId/team/planonly/:planOnlyTeamId`
> Deletes a plan-only team and their planning settings.

## Time tracking (5 endpoints)

### Get selected time tracking provider
`GET /rest/api/3/configuration/timetracking`
> Returns the time tracking provider that is currently selected. Note that if time tracking is disabled, then a successful but empty response is returned.

### Select time tracking provider
`PUT /rest/api/3/configuration/timetracking`
> Selects a time tracking provider.
Body example:
```json
{
  "key": "Jira"
}
```

### Get all time tracking providers
`GET /rest/api/3/configuration/timetracking/list`
> Returns all time tracking providers. By default, Jira only has one time tracking provider: *JIRA provided time tracking*. However, you can install other time tracking providers via apps from the Atlas

### Get time tracking settings
`GET /rest/api/3/configuration/timetracking/options`
> Returns the time tracking settings. This includes settings such as the time format, default time unit, and others. For more information, see [Configuring time tracking](https://confluence.atlassian.co

### Set time tracking settings
`PUT /rest/api/3/configuration/timetracking/options`
> Sets the time tracking settings.
Body example:
```json
{
  "defaultUnit": "hour",
  "timeFormat": "pretty",
  "workingDaysPerWeek": 5.5,
  "workingHoursPerDay": 7.6
}
```

## UI modifications (apps) (4 endpoints)

### Get UI modifications
`GET /rest/api/3/uiModifications`
> Gets UI modifications. UI modifications can only be retrieved by Forge apps.

### Create UI modification
`POST /rest/api/3/uiModifications`
> Creates a UI modification. UI modification can only be created by Forge apps.

### Update UI modification
`PUT /rest/api/3/uiModifications/:uiModificationId`
> Updates a UI modification. UI modification can only be updated by Forge apps.

### Delete UI modification
`DELETE /rest/api/3/uiModifications/:uiModificationId`
> Deletes a UI modification. All the contexts that belong to the UI modification are deleted too. UI modification can only be deleted by Forge apps.

## User properties (4 endpoints)

### Get user property keys
`GET /rest/api/3/user/properties`
> Returns the keys of all properties for a user.

### Get user property
`GET /rest/api/3/user/properties/:propertyKey`
> Returns the value of a user's property. If no property key is provided [Get user property keys](#api-rest-api-3-user-properties-get) is called.

### Set user property
`PUT /rest/api/3/user/properties/:propertyKey`
> Sets the value of a user's property. Use this resource to store custom data against a user.

### Delete user property
`DELETE /rest/api/3/user/properties/:propertyKey`
> Deletes a property from a user.

## User search (8 endpoints)

### Find users assignable to projects
`GET /rest/api/3/user/assignable/multiProjectSearch`
> Returns a list of users who can be assigned issues in one or more projects. The list may be restricted to users whose attributes match a string.

### Find users assignable to issues
`GET /rest/api/3/user/assignable/search`
> Returns a list of users that can be assigned to an issue. Use this operation to find the list of users who can be assigned to:

### Find users with permissions
`GET /rest/api/3/user/permission/search`
> Returns a list of users who fulfill these criteria:

### Find users for picker
`GET /rest/api/3/user/picker`
> Returns a list of users whose attributes match the query term. The returned object includes the `html` field where the matched query term is highlighted with the HTML strong tag. A list of account IDs

### Find users
`GET /rest/api/3/user/search`
> Returns a list of active users that match the search string and property.

### Find users by query
`GET /rest/api/3/user/search/query`
> Finds users with a structured query and returns a [paginated](#pagination) list of user details.

### Find user keys by query
`GET /rest/api/3/user/search/query/key`
> Finds users with a structured query and returns a [paginated](#pagination) list of user keys.

### Find users with browse permission
`GET /rest/api/3/user/viewissue/search`
> Returns a list of users who fulfill these criteria:

## Users (13 endpoints)

### Get user
`GET /rest/api/3/user`
> Returns a user.

### Create user
`POST /rest/api/3/user`
> Creates a user. This resource is retained for legacy compatibility. As soon as a more suitable alternative is available this resource will be deprecated.
Body example:
```json
{
  "emailAddress": "mia@atlassian.com",
  "products": [
    "jira-software"
  ]
}
```

### Delete user
`DELETE /rest/api/3/user`
> Deletes a user. If the operation completes successfully then the user is removed from Jira's user base. This operation does not delete the user's Atlassian account.

### Bulk get users
`GET /rest/api/3/user/bulk`
> Returns a [paginated](#pagination) list of the users specified by one or more account IDs.

### Get account IDs for users
`GET /rest/api/3/user/bulk/migration`
> Returns the account IDs for the users specified in the `key` or `username` parameters. Note that multiple `key` or `username` parameters can be specified.

### Get user default columns
`GET /rest/api/3/user/columns`
> Returns the default [issue table columns](https://confluence.atlassian.com/x/XYdKLg) for the user. If `accountId` is not passed in the request, the calling user's details are returned.

### Set user default columns
`PUT /rest/api/3/user/columns`
> Sets the default [ issue table columns](https://confluence.atlassian.com/x/XYdKLg) for the user. If an account ID is not passed, the calling user's default columns are set. If no column details are se

### Reset user default columns
`DELETE /rest/api/3/user/columns`
> Resets the default [ issue table columns](https://confluence.atlassian.com/x/XYdKLg) for the user to the system default. If `accountId` is not passed, the calling user's default columns are reset.

### Get user email
`GET /rest/api/3/user/email`
> Returns a user's email address regardless of the user's profile visibility settings. For Connect apps, this API is only available to apps approved by Atlassian, according to these [guidelines](https:/

### Get user email bulk
`GET /rest/api/3/user/email/bulk`
> Returns a user's email address regardless of the user's profile visibility settings. For Connect apps, this API is only available to apps approved by Atlassian, according to these [guidelines](https:/

### Get user groups
`GET /rest/api/3/user/groups`
> Returns the groups to which a user belongs.

### Get all users default
`GET /rest/api/3/users`
> Returns a list of all users, including active users, inactive users and previously deleted users that have an Atlassian account.

### Get all users
`GET /rest/api/3/users/search`
> Returns a list of all users, including active users, inactive users and previously deleted users that have an Atlassian account.

## Webhooks (5 endpoints)

### Get dynamic webhooks for app
`GET /rest/api/3/webhook`
> Returns a [paginated](#pagination) list of the webhooks registered by the calling app.

### Register dynamic webhooks
`POST /rest/api/3/webhook`
> Registers webhooks.

### Delete webhooks by ID
`DELETE /rest/api/3/webhook`
> Removes webhooks by ID. Only webhooks registered by the calling app are removed. If webhooks created by other apps are specified, they are ignored.
Body example:
```json
{
  "webhookIds": [
    10000,
    10001,
    10042
  ]
}
```

### Get failed webhooks
`GET /rest/api/3/webhook/failed`
> Returns webhooks that have recently failed to be delivered to the requesting app after the maximum number of retries.

### Extend webhook life
`PUT /rest/api/3/webhook/refresh`
> Extends the life of webhook. Webhooks registered through the REST API expire after 30 days. Call this operation to keep them alive.
Body example:
```json
{
  "webhookIds": [
    10000,
    10001,
    10042
  ]
}
```

## Workflow scheme drafts (14 endpoints)

### Create draft workflow scheme
`POST /rest/api/3/workflowscheme/:id/createdraft`
> Create a draft workflow scheme from an active workflow scheme, by copying the active workflow scheme. Note that an active workflow scheme can only have one draft workflow scheme.

### Get draft workflow scheme
`GET /rest/api/3/workflowscheme/:id/draft`
> Returns the draft workflow scheme for an active workflow scheme. Draft workflow schemes allow changes to be made to the active workflow schemes: When an active workflow scheme is updated, a draft copy

### Update draft workflow scheme
`PUT /rest/api/3/workflowscheme/:id/draft`
> Updates a draft workflow scheme. If a draft workflow scheme does not exist for the active workflow scheme, then a draft is created. Note that an active workflow scheme can only have one draft workflow
Body example:
```json
{
  "defaultWorkflow": "jira",
  "description": "The description of the example workflow scheme.",
  "issueTypeMappings": {
    "10000": "scrum workflow"
  },
  "name": "Example workflow scheme",
  "updateDraftIfNeeded": false
}
```

### Delete draft workflow scheme
`DELETE /rest/api/3/workflowscheme/:id/draft`
> Deletes a draft workflow scheme.

### Get draft default workflow
`GET /rest/api/3/workflowscheme/:id/draft/default`
> Returns the default workflow for a workflow scheme's draft. The default workflow is the workflow that is assigned any issue types that have not been mapped to any other workflow. The default workflow 

### Update draft default workflow
`PUT /rest/api/3/workflowscheme/:id/draft/default`
> Sets the default workflow for a workflow scheme's draft.
Body example:
```json
{
  "updateDraftIfNeeded": false,
  "workflow": "jira"
}
```

### Delete draft default workflow
`DELETE /rest/api/3/workflowscheme/:id/draft/default`
> Resets the default workflow for a workflow scheme's draft. That is, the default workflow is set to Jira's system workflow (the *jira* workflow).

### Get workflow for issue type in draft workflow scheme
`GET /rest/api/3/workflowscheme/:id/draft/issuetype/:issueType`
> Returns the issue type-workflow mapping for an issue type in a workflow scheme's draft.

### Set workflow for issue type in draft workflow scheme
`PUT /rest/api/3/workflowscheme/:id/draft/issuetype/:issueType`
> Sets the workflow for an issue type in a workflow scheme's draft.
Body example:
```json
{
  "issueType": "10000",
  "updateDraftIfNeeded": false,
  "workflow": "jira"
}
```

### Delete workflow for issue type in draft workflow scheme
`DELETE /rest/api/3/workflowscheme/:id/draft/issuetype/:issueType`
> Deletes the issue type-workflow mapping for an issue type in a workflow scheme's draft.

### Publish draft workflow scheme
`POST /rest/api/3/workflowscheme/:id/draft/publish`
> Publishes a draft workflow scheme.
Body example:
```json
{
  "statusMappings": [
    {
      "issueTypeId": "10001",
      "newStatusId": "1",
      "statusId": "3"
    },
    {
      "issueTypeId": "10001",
      "newStatusId": "2",
      "statusId": "2"
    },
    {
      "issueTypeId": "10002",
      "newStatusId": "10003",
      "statusId": "10005"
    },
    {
      "issueTypeId": "10003",
      "newStatusId": "1",
      "statusId": "4"
    }
  ]
}
```

### Get issue types for workflows in draft workflow scheme
`GET /rest/api/3/workflowscheme/:id/draft/workflow`
> Returns the workflow-issue type mappings for a workflow scheme's draft.

### Set issue types for workflow in workflow scheme
`PUT /rest/api/3/workflowscheme/:id/draft/workflow`
> Sets the issue types for a workflow in a workflow scheme's draft. The workflow can also be set as the default workflow for the draft workflow scheme. Unmapped issues types are mapped to the default wo
Body example:
```json
{
  "issueTypes": [
    "10000"
  ],
  "updateDraftIfNeeded": true,
  "workflow": "jira"
}
```

### Delete issue types for workflow in draft workflow scheme
`DELETE /rest/api/3/workflowscheme/:id/draft/workflow`
> Deletes the workflow-issue type mapping for a workflow in a workflow scheme's draft.

## Workflow scheme project associations (2 endpoints)

### Get workflow scheme project associations
`GET /rest/api/3/workflowscheme/project`
> Returns a list of the workflow schemes associated with a list of projects. Each returned workflow scheme includes a list of the requested projects associated with it. Any team-managed or non-existent 

### Assign workflow scheme to project
`PUT /rest/api/3/workflowscheme/project`
> Assigns a workflow scheme to a project. This operation is performed only when there are no issues in the project.
Body example:
```json
{
  "projectId": "10001",
  "workflowSchemeId": "10032"
}
```

## Workflow schemes (19 endpoints)

### Get all workflow schemes
`GET /rest/api/3/workflowscheme`
> Returns a [paginated](#pagination) list of all workflow schemes, not including draft workflow schemes.

### Create workflow scheme
`POST /rest/api/3/workflowscheme`
> Creates a workflow scheme.
Body example:
```json
{
  "defaultWorkflow": "jira",
  "description": "The description of the example workflow scheme.",
  "issueTypeMappings": {
    "10000": "scrum workflow",
    "10001": "builds workflow"
  },
  "name": "Example workflow scheme"
}
```

### Switch workflow scheme for project
`POST /rest/api/3/workflowscheme/project/switch`
> Switches a workflow scheme for a project.

### Bulk get workflow schemes
`POST /rest/api/3/workflowscheme/read`
> Returns a list of workflow schemes by providing workflow scheme IDs or project IDs.
Body example:
```json
{
  "projectIds": [
    "10047",
    "10048"
  ],
  "workflowSchemeIds": [
    "3e59db0f-ed6c-47ce-8d50-80c0c4572677"
  ]
}
```

### Update workflow scheme
`POST /rest/api/3/workflowscheme/update`
> Updates company-managed and team-managed project workflow schemes. This API doesn't have a concept of draft, so any changes made to a workflow scheme are immediately available. When changing the avail

### Get required status mappings for workflow scheme update
`POST /rest/api/3/workflowscheme/update/mappings`
> Gets the required status mappings for the desired changes to a workflow scheme. The results are provided per issue type and workflow. When updating a workflow scheme, status mappings can be provided p
Body example:
```json
{
  "defaultWorkflowId": "10010",
  "id": "10001",
  "workflowsForIssueTypes": [
    {
      "issueTypeIds": [
        "10010",
        "10011"
      ],
      "workflowId": "10001"
    }
  ]
}
```

### Get workflow scheme
`GET /rest/api/3/workflowscheme/:id`
> Returns a workflow scheme.

### Classic update workflow scheme
`PUT /rest/api/3/workflowscheme/:id`
> Updates a company-manged project workflow scheme, including the name, default workflow, issue type to project mappings, and more. If the workflow scheme is active (that is, being used by at least one 
Body example:
```json
{
  "defaultWorkflow": "jira",
  "description": "The description of the example workflow scheme.",
  "issueTypeMappings": {
    "10000": "scrum workflow"
  },
  "name": "Example workflow scheme",
  "updateDraftIfNeeded": false
}
```

### Delete workflow scheme
`DELETE /rest/api/3/workflowscheme/:id`
> Deletes a workflow scheme. Note that a workflow scheme cannot be deleted if it is active (that is, being used by at least one project).

### Get default workflow
`GET /rest/api/3/workflowscheme/:id/default`
> Returns the default workflow for a workflow scheme. The default workflow is the workflow that is assigned any issue types that have not been mapped to any other workflow. The default workflow has *All

### Update default workflow
`PUT /rest/api/3/workflowscheme/:id/default`
> Sets the default workflow for a workflow scheme.
Body example:
```json
{
  "updateDraftIfNeeded": false,
  "workflow": "jira"
}
```

### Delete default workflow
`DELETE /rest/api/3/workflowscheme/:id/default`
> Resets the default workflow for a workflow scheme. That is, the default workflow is set to Jira's system workflow (the *jira* workflow).

### Get workflow for issue type in workflow scheme
`GET /rest/api/3/workflowscheme/:id/issuetype/:issueType`
> Returns the issue type-workflow mapping for an issue type in a workflow scheme.

### Set workflow for issue type in workflow scheme
`PUT /rest/api/3/workflowscheme/:id/issuetype/:issueType`
> Sets the workflow for an issue type in a workflow scheme.
Body example:
```json
{
  "issueType": "10000",
  "updateDraftIfNeeded": false,
  "workflow": "jira"
}
```

### Delete workflow for issue type in workflow scheme
`DELETE /rest/api/3/workflowscheme/:id/issuetype/:issueType`
> Deletes the issue type-workflow mapping for an issue type in a workflow scheme.

### Get issue types for workflows in workflow scheme
`GET /rest/api/3/workflowscheme/:id/workflow`
> Returns the workflow-issue type mappings for a workflow scheme.

### Set issue types for workflow in workflow scheme
`PUT /rest/api/3/workflowscheme/:id/workflow`
> Sets the issue types for a workflow in a workflow scheme. The workflow can also be set as the default workflow for the workflow scheme. Unmapped issues types are mapped to the default workflow.
Body example:
```json
{
  "issueTypes": [
    "10000"
  ],
  "updateDraftIfNeeded": true,
  "workflow": "jira"
}
```

### Delete issue types for workflow in workflow scheme
`DELETE /rest/api/3/workflowscheme/:id/workflow`
> Deletes the workflow-issue type mapping for a workflow in a workflow scheme.

### Get projects which are using a given workflow scheme
`GET /rest/api/3/workflowscheme/:workflowSchemeId/projectUsages`
> Returns a page of projects using a given workflow scheme.

## Workflow status categories (2 endpoints)

### Get all status categories
`GET /rest/api/3/statuscategory`
> Returns a list of all status categories.

### Get status category
`GET /rest/api/3/statuscategory/:idOrKey`
> Returns a status category. Status categories provided a mechanism for categorizing [statuses](#api-rest-api-3-status-idOrName-get).

## Workflow statuses (2 endpoints)

### Get all statuses
`GET /rest/api/3/status`
> Returns a list of all statuses associated with active workflows.

### Get status
`GET /rest/api/3/status/:idOrName`
> Returns a status. The status must be associated with an active workflow to be returned.

## Workflow transition properties (4 endpoints)

### Get workflow transition properties
`GET /rest/api/3/workflow/transitions/:transitionId/properties`
> This will be removed on [June 1, 2026](https://developer.atlassian.com/cloud/jira/platform/changelog/#CHANGE-2570); fetch transition properties from [Bulk get workflows](https://developer.atlassian.co

### Update workflow transition property
`PUT /rest/api/3/workflow/transitions/:transitionId/properties`
> This will be removed on [June 1, 2026](https://developer.atlassian.com/cloud/jira/platform/changelog/#CHANGE-2570); update transition properties using [Bulk update workflows](https://developer.atlassi
Body example:
```json
{
  "value": "createissue"
}
```

### Create workflow transition property
`POST /rest/api/3/workflow/transitions/:transitionId/properties`
> This will be removed on [June 1, 2026](https://developer.atlassian.com/cloud/jira/platform/changelog/#CHANGE-2570); add transition properties using [Bulk update workflows](https://developer.atlassian.
Body example:
```json
{
  "value": "createissue"
}
```

### Delete workflow transition property
`DELETE /rest/api/3/workflow/transitions/:transitionId/properties`
> This will be removed on [June 1, 2026](https://developer.atlassian.com/cloud/jira/platform/changelog/#CHANGE-2570); delete transition properties using [Bulk update workflows](https://developer.atlassi

## Workflow transition rules (3 endpoints)

### Get workflow transition rule configurations
`GET /rest/api/3/workflow/rule/config`
> Returns a [paginated](#pagination) list of workflows with transition rules. The workflows can be filtered to return only those containing workflow transition rules:

### Update workflow transition rule configurations
`PUT /rest/api/3/workflow/rule/config`
> Updates configuration of workflow transition rules. The following rule types are supported:

### Delete workflow transition rule configurations
`PUT /rest/api/3/workflow/rule/config/delete`
> Deletes workflow transition rules from one or more workflows. These rule types are supported:
Body example:
```json
{
  "workflows": [
    {
      "workflowId": {
        "draft": false,
        "name": "Internal support workflow"
      },
      "workflowRuleIds": [
        "b4d6cbdc-59f5-11e9-8647-d663bd873d93",
        "d663bd873d93-59f5-11e9-8647-b4d6cbdc",
        "11e9-59f5-b4d6cbdc-8647-d663bd873d93"
      ]
    }
  ]
}
```

## Workflows (18 endpoints)

### Get all workflows
`GET /rest/api/3/workflow`
> This will be removed on [February 1, 2026](https://developer.atlassian.com/cloud/jira/platform/changelog/#CHANGE-2567); use [Search workflows](#api-rest-api-3-workflows-search-get) instead.

### Create workflow
`POST /rest/api/3/workflow`
> This will be removed on [February 1, 2026](https://developer.atlassian.com/cloud/jira/platform/changelog/#CHANGE-2568); use [Bulk create workflows](#api-rest-api-3-workflows-create-post) to create bot

### Read workflow version from history
`POST /rest/api/3/workflow/history`
> Returns a workflow and related statuses for a specified workflow id and version number.
Body example:
```json
{
  "version": 4,
  "workflowId": "c5ef565c-1b1e-427e-bc3b-e677b0dc027c"
}
```

### List workflow history entries
`POST /rest/api/3/workflow/history/list`
> Returns a list of workflow history entries for a specified workflow id.
Body example:
```json
{
  "workflowId": "c5ef565c-1b1e-427e-bc3b-e677b0dc027c"
}
```

### Get workflows paginated
`GET /rest/api/3/workflow/search`
> This will be removed on [June 1, 2026](https://developer.atlassian.com/cloud/jira/platform/changelog/#CHANGE-2569); use [Search workflows](#api-rest-api-3-workflows-search-get) instead.

### Delete inactive workflow
`DELETE /rest/api/3/workflow/:entityId`
> Deletes a workflow.

### Get issue types in a project that are using a given workflow
`GET /rest/api/3/workflow/:workflowId/project/:projectId/issueTypeUsages`
> Returns a page of issue types using a given workflow within a project.

### Get projects using a given workflow
`GET /rest/api/3/workflow/:workflowId/projectUsages`
> Returns a page of projects using a given workflow.

### Get workflow schemes which are using a given workflow
`GET /rest/api/3/workflow/:workflowId/workflowSchemes`
> Returns a page of workflow schemes using a given workflow.

### Bulk get workflows
`POST /rest/api/3/workflows`
> Returns a list of workflows and related statuses by providing workflow names, workflow IDs, or project and issue types.
Body example:
```json
{
  "projectAndIssueTypes": [],
  "workflowIds": [],
  "workflowNames": [
    "Workflow 1",
    "Workflow 2"
  ]
}
```

### Get available workflow capabilities
`GET /rest/api/3/workflows/capabilities`
> Get the list of workflow capabilities for a specific workflow using either the workflow ID, or the project and issue type ID pair. The response includes the scope of the workflow, defined as global/pr

### Bulk create workflows
`POST /rest/api/3/workflows/create`
> Create workflows and related statuses.

### Validate create workflows
`POST /rest/api/3/workflows/create/validation`
> Validate the payload for bulk create workflows.

### Get the user's default workflow editor
`GET /rest/api/3/workflows/defaultEditor`
> Get the user's default workflow editor. This can be either the new editor or the legacy editor.

### Preview workflow
`POST /rest/api/3/workflows/preview`
> Returns a requested workflow within a given project. The response provides a read-only preview of the workflow, omitting full configuration details.
Body example:
```json
{
  "issueTypeIds": [],
  "projectId": "10011",
  "workflowIds": [
    "3215e5cd-f09f-4c8a-921b-dca92bd1e9aa",
    "5f485405-a237-40e5-aeea-ad2c206cff95"
  ],
  "workflowNames": []
}
```

### Search workflows
`GET /rest/api/3/workflows/search`
> Returns a [paginated](#pagination) list of global and project workflows. If workflow names are specified in the query string, details of those workflows are returned. Otherwise, all workflows are retu

### Bulk update workflows
`POST /rest/api/3/workflows/update`
> Update workflows and related statuses.

### Validate update workflows
`POST /rest/api/3/workflows/update/validation`
> Validate the payload for bulk update workflows.

## Other operations (1 endpoints)

### Get worklogs by issue id and worklog id
`POST /rest/internal/api/latest/worklog/bulk`
> Returns worklog details for a list of issue ID and worklog ID pairs.
