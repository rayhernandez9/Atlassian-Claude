# Organizations & API Access REST API — Endpoint Reference

Covers the Atlassian Organizations API and API Access (token/key management).

# Organizations REST API

## Orgs (2 endpoints)

### Get organizations
`GET /v1/orgs`
> Returns a list of your organizations (based on your API key).

### Get an organization by ID
`GET /v1/orgs/:orgId`
> Returns information about a single organization by ID

## Directory (1 endpoints)

### Get directories in an organization
`GET /v2/orgs/:orgId/directories`
> Returns a page of directories in an organization that match the supplied parameters.

## Users (20 endpoints)

### Get users in an organization
`GET /v2/orgs/:orgId/directories/:directoryId/users`
> Return a page of users in your organization that match the supplied parameters. By default, users in all your directories and all your managed accounts are returned (including managed accounts that ar

### Get details of a user in a directory
`GET /v2/orgs/:orgId/directories/:directoryId/users/:userId`
> Returns detailed information about a specific user in a directory within an organization.

### Get managed accounts in an organization
`GET /v1/orgs/:orgId/users`
> Returns a list of managed accounts in an organization.

### Invite users to an organization
`POST /v2/orgs/:orgId/users/invite`

### Get user role assignments
`GET /v2/orgs/:orgId/directories/:directoryId/users/:accountId/role-assignments`
> Returns a page of role assignments for a user that match the supplied parameters.

### Grant user access
`POST /v1/orgs/:orgId/users/:userId/roles/assign`
> **The API is available for customers using the [new user management experience only](https://community.atlassian.com/t5/Atlassian-Access-articles/User-management-for-cloud-admins-just-got-easier/ba-p/

### Revoke user access
`POST /v1/orgs/:orgId/users/:userId/roles/revoke`
> **The API is available for customers using the [new user management experience only](https://community.atlassian.com/t5/Atlassian-Access-articles/User-management-for-cloud-admins-just-got-easier/ba-p/

### Suspend user access in directory
`POST /v2/orgs/:orgId/directories/:directoryId/users/:accountId/suspend`
> Suspend a user’s access in a directory to remove their access to apps temporarily. You’re not billed for a user when their access is suspended. They regain their roles and group memberships when you r

### Restore user access in directory
`POST /v2/orgs/:orgId/directories/:directoryId/users/:accountId/restore`
> Restore a user’s access in a directory to let them access apps again. They regain their roles and group memberships from before their access was suspended. We resume billing you for this user.

### Remove user from directory
`DELETE /v2/orgs/:orgId/directories/:directoryId/users/:accountId`
> Remove a user from a directory if you don’t want them to appear in your directory or have access to your apps anymore. You’re not billed for a user once they’re removed.

### Assign organization-level role
`POST /v1/orgs/:orgId/users/:userId/role-assignments/assign`
> Assign an organization-level role to a user. These are roles that have organization-wide privileges, like organization admin.

### Remove organization-level role
`POST /v1/orgs/:orgId/users/:userId/role-assignments/revoke`
> Remove an organization-level role from a user. These are roles that have organization-wide privileges, like organization admin.

### Get count of users in an organization
`GET /v2/orgs/:orgId/directories/:directoryId/users/count`
> Returns a count of users in an organization that match the supplied parameters. By default, users in all your directories and all your managed accounts are counted (including managed accounts that are

### Get user stats in an organization
`GET /v2/orgs/:orgId/directories/:directoryId/users/stats`
> Return user stats for the organization.

### User’s last active dates
`GET /v1/orgs/:orgId/directory/users/:accountId/last-active-dates`
> **Additional response parameters of the API (for e.g., `added_to_org`) are available only to customers using the new user management experience.** Learn more about the [new user management experience]

### Search for users in an organization
`POST /v1/orgs/:orgId/users/search`
> **This API is deprecated and will no longer work after June 30, 2026.** Use the [Get users in an organization endpoint](https://developer.atlassian.com/cloud/admin/organization/rest/api-group-users/#a
Body example:
```json
{
  "limit": 20
}
```

### Invite user to org
`POST /v1/orgs/:orgId/users/invite`
> **The API is presently accessible exclusively to customers who hold a paid subscription.** 

### Suspend user access
`POST /v1/orgs/:orgId/directory/users/:accountId/suspend-access`
> **This API is deprecated and will no longer work after June 30, 2026.** Use the [Suspend user access in directory endpoint](https://developer.atlassian.com/cloud/admin/organization/rest/api-group-user

### Restore user access
`POST /v1/orgs/:orgId/directory/users/:accountId/restore-access`
> **This API is deprecated and will no longer work after June 30, 2026.** Use the [Restore user access in directory endpoint](https://developer.atlassian.com/cloud/admin/organization/rest/api-group-user

### Remove user access
`DELETE /v1/orgs/:orgId/directory/users/:accountId`
> **This API is deprecated and will no longer work after June 30, 2026.** Use the [Remove user from directory endpoint](https://developer.atlassian.com/cloud/admin/organization/rest/api-group-users/#api

## Groups (18 endpoints)

### Get groups in an organization
`GET /v2/orgs/:orgId/directories/:directoryId/groups`
> Returns a page of groups in an organization that match the supplied parameters.

### Create group
`POST /v2/orgs/:orgId/directories/:directoryId/groups`
> Create a group in a directory to manage app access and permissions for multiple users together.

### Get group role assignments
`GET /v2/orgs/:orgId/directories/:directoryId/groups/:groupId/role-assignments`
> Returns a page of role assignments for a group that match the supplied parameters.

### Grant access to group
`POST /v2/orgs/:orgId/directories/:directoryId/groups/:groupId/role-assignments/assign`
> Assign a role to a group to assign all members the same role.

### Remove access from group
`POST /v2/orgs/:orgId/directories/:directoryId/groups/:groupId/role-assignments/revoke'`
> Revoke a role from a group to remove access to an app from all members. A member can still access the app if they’re in another group that grants access to the same app.

### Add user to group
`POST /v2/orgs/:orgId/directories/:directoryId/groups/:groupId/memberships`
> Add a user to a group. This gives the user the same app access and permissions as the group. The user must be in the same directory as the group.

### Remove user from group
`DELETE /v2/orgs/:orgId/directories/:directoryId/groups/:groupId/memberships/:accountId"`
> Remove a user from a group. This removes any app access and permissions granted by this group, but the user may still be in other groups that grant the same app access and permissions.

### Get group details
`GET /v2/orgs/:orgId/directories/:directoryId/groups/:groupId`
> Returns the details of a group.

### Delete group
`DELETE /v2/orgs/:orgId/directories/:directoryId/groups/:groupId`
> Delete a group from a directory if you don’t need this group anymore. This removes any app access and permissions granted by this group from all members. A member can still access an app if they’re in

### Get the count of groups in an organization
`GET /v2/orgs/:orgId/directories/:directoryId/groups/count`
> Returns the count of groups in an organization that match the supplied parameters.

### Get group stats
`GET /v2/orgs/:orgId/directories/:directoryId/groups/stats`
> Returns group stats for the organization.

### Search for groups within an organization
`POST /v1/orgs/:orgId/groups/search`
> **This API is deprecated and will no longer work after June 30, 2026.** Use the [Get groups in an organization endpoint](https://developer.atlassian.com/cloud/admin/organization/rest/api-group-groups/
Body example:
```json
{
  "limit": 20
}
```

### Create group
`POST /v1/orgs/:orgId/directory/groups`
> **This API is deprecated and will no longer work after June 30, 2026.** Use the [new Create group endpoint](https://developer.atlassian.com/cloud/admin/organization/rest/api-group-groups/#api-v2-orgs-

### Delete group
`DELETE /v1/orgs/:orgId/directory/groups/:groupId`
> **This API is deprecated and will no longer work after June 30, 2026.** Use the [new Delete group endpoint](https://developer.atlassian.com/cloud/admin/organization/rest/api-group-groups/#api-v2-orgs-

### Assign roles to a group
`POST /v1/orgs/:orgId/directory/groups/:groupId/roles/assign`
> **This API is deprecated and will no longer work after June 30, 2026.** Use the [Grant access to group endpoint](https://developer.atlassian.com/cloud/admin/organization/rest/api-group-groups/#api-v2-

### Revoke roles from a group
`POST /v1/orgs/:orgId/directory/groups/:groupId/roles/revoke`
> **This API is deprecated and will no longer work after June 30, 2026.** Use the [Remove access from group endpoint](https://developer.atlassian.com/cloud/admin/organization/rest/api-group-groups/#api-

### Add user to group
`POST /v1/orgs/:orgId/directory/groups/:groupId/memberships`
> **This API is deprecated and will no longer work after June 30, 2026.** Use the [new Add user to group endpoint](https://developer.atlassian.com/cloud/admin/organization/rest/api-group-groups/#api-v2-

### Remove user from group
`DELETE /v1/orgs/:orgId/directory/groups/:groupId/memberships/:accountId`
> **This API is deprecated and will no longer work after June 30, 2026.** Use the [new Remove user from group endpoint](https://developer.atlassian.com/cloud/admin/organization/rest/api-group-groups/#ap

## Domains (2 endpoints)

### Get domains in an organization
`GET /v1/orgs/:orgId/domains`
> Returns a list of domains in an organization one page at a time.

### Get domain by ID
`GET /v1/orgs/:orgId/domains/:domainId`
> Returns information about a single verified domain by ID.

## Events (4 endpoints)

### Query audit log events
`GET /v1/orgs/:orgId/events`
> Returns a filtered list of audit log events for an organization.

### Poll audit log events
`GET /v1/orgs/:orgId/events-stream`
> Returns a paginated list of audit logs events for an organization. Use this endpoint if you want to retrieve events in a simple, paginated manner with time-based filtering.

### Get an event by ID
`GET /v1/orgs/:orgId/events/:eventId`
> Returns information about a single event by ID.

### Get list of event actions
`GET /v1/orgs/:orgId/event-actions`
> Returns information localized event actions

## Policies (9 endpoints)

### Get list of policies
`GET /v1/orgs/:orgId/policies`
> Returns information about org policies

### Create a policy
`POST /v1/orgs/:orgId/policies`
> Create a policy for an org

### Get a policy by ID
`GET /v1/orgs/:orgId/policies/:policyId`
> Returns information about a single policy by ID

### Update a policy
`PUT /v1/orgs/:orgId/policies/:policyId`
> Update a policy for an org

### Delete a policy
`DELETE /v1/orgs/:orgId/policies/:policyId`
> Delete a policy for an org

### Add Resource to Policy
`POST /v1/orgs/:orgId/policies/:policyId/resources`
> Adds a resource to an existing Policy

### Update Policy Resource
`PUT /v1/orgs/:orgId/policies/:policyId/resources/:resourceId`
> Update an existing Policy Resource

### Delete Policy Resource
`DELETE /v1/orgs/:orgId/policies/:policyId/resources/:resourceId`
> Delete an existing Policy Resource

### Validate Policy
`GET /v1/orgs/:orgId/policies/:policyId/validate`
> Validate a policy based on specific requirements. For example, Trigger CDEN validation by pushing a task into the SQS dns-validation queue

## Workspaces (1 endpoints)

### Get list of workspaces
`POST /v2/orgs/:orgId/workspaces`
> A workspace refers to a specific instance of an Atlassian product that is accessed through a unique URL. Whenever a user initiates or adds a new product instance, it results in the creation of a disti
Body example:
```json
{
  "cursor": "c29tZS1iYXNlLTY0LWVuY29kZWQtY3Vyc29y"
}
```

# API Access

## API Token (6 endpoints)

### Get all API tokens in an org
`GET /orgs/:orgId/api-tokens`
> Gets all [user API tokens](/cloud/admin/api-access/rest/intro/#API%20Tokens) in an organization.

### Bulk revoke API tokens in an organization
`DELETE /orgs/:orgId/api-tokens`
> Revokes all managed user API tokens in an organization by orgID.

### Get API token count in an org
`GET /orgs/:orgId/api-tokens/count`
> Gets count of [user API tokens](/cloud/admin/api-access/rest/intro/#API%20Tokens) in an organization.

### Get service account API token count in an org
`POST /orgs/:orgId/service-accounts/count`
> Gets count of API tokens for specified service accounts within an organization.

### Get all service account API tokens in an org
`GET /orgs/:orgId/service-accounts/:accountId/api-tokens`
> Retrieves API tokens for a specific service account within an organization.

### Revoke all API tokens for a service account
`DELETE /orgs/:orgId/service-accounts/:accountId/api-tokens`
> Revokes all API tokens for a specific service account within an organization.

## API Key (3 endpoints)

### Get API key count in an org
`GET /orgs/:orgId/api-keys/count`
> Gets count of user API keys in an organization.

### Get all API keys in an org
`GET /orgs/:orgId/api-keys`
> Gets all user API keys in an organization.

### Revoke an API key for an org
`PATCH /orgs/:orgId/api-keys/revoke/:apiKeyId`
> Revokes an existing API key
