# Confluence Cloud REST API v2 — Endpoint Reference

Extracted from the official Atlassian Postman collection. All endpoints use Basic Auth (email + API token).

Base path: `{base_url}/wiki/api/v2/`

## Admin Key (3 endpoints)

### Get Admin Key
`GET /admin-key`
> Returns information about the admin key if one is currently enabled for the calling user within the site.

### Enable Admin Key
`POST /admin-key`
> Enables admin key access for the calling user within the site. If an admin key already exists for the user, a new one will be issued with an updated expiration time.

### Disable Admin Key
`DELETE /admin-key`
> Disables admin key access for the calling user within the site.

## Attachment (7 endpoints)

### Get attachments
`GET /attachments`
> Returns all attachments. The number of results is limited by the `limit` parameter and additional results (if available)

### Get attachment by id
`GET /attachments/:id`
> Returns a specific attachment.

### Delete attachment
`DELETE /attachments/:id`
> Delete an attachment by id.

### Get attachments for blog post
`GET /blogposts/:id/attachments`
> Returns the attachments of specific blog post. The number of results is limited by the `limit` parameter and additional results (if available)

### Get attachments for custom content
`GET /custom-content/:id/attachments`
> Returns the attachments of specific custom content. The number of results is limited by the `limit` parameter and additional results (if available)

### Get attachments for label
`GET /labels/:id/attachments`
> Returns the attachments of specified label. The number of results is limited by the `limit` parameter and additional results (if available)

### Get attachments for page
`GET /pages/:id/attachments`
> Returns the attachments of specific page. The number of results is limited by the `limit` parameter and additional results (if available)

## App Properties (4 endpoints)

### Get Forge app properties.
`GET /app/properties`
> Gets Forge app properties. This API can only be accessed using **[asApp()](https://developer.atlassian.com/platform/forge/apis-reference/fetch-api-product.requestconfluence/#method-signature)** reques

### Get a Forge app property by key.
`GET /app/properties/:propertyKey`
> Gets a Forge app property by property key. This API can only be accessed using **[asApp()](https://developer.atlassian.com/platform/forge/apis-reference/fetch-api-product.requestconfluence/#method-sig

### Create or update a Forge app property.
`PUT /app/properties/:propertyKey`
> Creates or updates a Forge app property. This API can only be accessed using **[asApp()](https://developer.atlassian.com/platform/forge/apis-reference/fetch-api-product.requestconfluence/#method-signa

### Deletes a Forge app property.
`DELETE /app/properties/:propertyKey`
> Deletes a Forge app property. This API can only be accessed using **[asApp()](https://developer.atlassian.com/platform/forge/apis-reference/fetch-api-product.requestconfluence/#method-signature)** req

## Ancestors (5 endpoints)

### Get all ancestors of whiteboard
`GET /whiteboards/:id/ancestors`
> Returns all ancestors for a given whiteboard by ID in top-to-bottom order (that is, the highest ancestor is the first

### Get all ancestors of database
`GET /databases/:id/ancestors`
> Returns all ancestors for a given database by ID in top-to-bottom order (that is, the highest ancestor is the first

### Get all ancestors of Smart Link in content tree
`GET /embeds/:id/ancestors`
> Returns all ancestors for a given Smart Link in the content tree by ID in top-to-bottom order (that is, the highest ancestor is

### Get all ancestors of folder
`GET /folders/:id/ancestors`
> Returns all ancestors for a given folder by ID in top-to-bottom order (that is, the highest ancestor is

### Get all ancestors of page
`GET /pages/:id/ancestors`
> Returns all ancestors for a given page by ID in top-to-bottom order (that is, the highest ancestor is the first

## Blog Post (7 endpoints)

### Get blog posts
`GET /blogposts`
> Returns all blog posts. The number of results is limited by the `limit` parameter and additional results (if available)

### Create blog post
`POST /blogposts`
> Creates a new blog post in the space specified by the spaceId.

### Get blog post by id
`GET /blogposts/:id`
> Returns a specific blog post.

### Update blog post
`PUT /blogposts/:id`
> Update a blog post by id.

### Delete blog post
`DELETE /blogposts/:id`
> Delete a blog post by id.

### Get blog posts for label
`GET /labels/:id/blogposts`
> Returns the blogposts of specified label. The number of results is limited by the `limit` parameter and additional results (if available)

### Get blog posts in space
`GET /spaces/:id/blogposts`
> Returns all blog posts in a space. The number of results is limited by the `limit` parameter and additional results (if available)

## Children (7 endpoints)

### Get direct children of a whiteboard
`GET /whiteboards/:id/direct-children`
> Returns all children for given whiteboard id in the content tree. The number of results is limited by the `limit` parameter and additional results (if available)

### Get direct children of a database
`GET /databases/:id/direct-children`
> Returns all children for given database id in the content tree. The number of results is limited by the `limit` parameter and additional results (if available)

### Get direct children of a Smart Link
`GET /embeds/:id/direct-children`
> Returns all children for given smart link id in the content tree. The number of results is limited by the `limit` parameter and additional results (if available)

### Get direct children of a folder
`GET /folders/:id/direct-children`
> Returns all children for given folder id in the content tree. The number of results is limited by the `limit` parameter and additional results (if available)

### Get child pages
`GET /pages/:id/children`
> Returns all child pages for given page id. The number of results is limited by the `limit` parameter and additional results (if available)

### Get child custom content
`GET /custom-content/:id/children`
> Returns all child custom content for given custom content id. The number of results is limited by the `limit` parameter and additional results (if available)

### Get direct children of a page
`GET /pages/:id/direct-children`
> Returns all children for given page id in the content tree. The number of results is limited by the `limit` parameter and additional results (if available)

## Classification Level (16 endpoints)

### Get list of classification levels
`GET /classification-levels`
> Returns a list of [classification levels](https://developer.atlassian.com/cloud/admin/dlp/rest/intro/#Classification%20level) 

### Get space default classification level
`GET /spaces/:id/classification-level/default`
> Returns the [default classification level](https://support.atlassian.com/security-and-access-policies/docs/what-is-a-default-classification-level/) 

### Update space default classification level
`PUT /spaces/:id/classification-level/default`
> Update the [default classification level](https://support.atlassian.com/security-and-access-policies/docs/what-is-a-default-classification-level/) 

### Delete space default classification level
`DELETE /spaces/:id/classification-level/default`
> Returns the [default classification level](https://support.atlassian.com/security-and-access-policies/docs/what-is-a-default-classification-level/) 

### Get page classification level
`GET /pages/:id/classification-level`
> Returns the [classification level](https://developer.atlassian.com/cloud/admin/dlp/rest/intro/#Classification%20level)

### Update page classification level
`PUT /pages/:id/classification-level`
> Updates the [classification level](https://developer.atlassian.com/cloud/admin/dlp/rest/intro/#Classification%20level)

### Reset page classification level
`POST /pages/:id/classification-level/reset`
> Resets the [classification level](https://developer.atlassian.com/cloud/admin/dlp/rest/intro/#Classification%20level)

### Get blog post classification level
`GET /blogposts/:id/classification-level`
> Returns the [classification level](https://developer.atlassian.com/cloud/admin/dlp/rest/intro/#Classification%20level)

### Update blog post classification level
`PUT /blogposts/:id/classification-level`
> Updates the [classification level](https://developer.atlassian.com/cloud/admin/dlp/rest/intro/#Classification%20level)

### Reset blog post classification level
`POST /blogposts/:id/classification-level/reset`
> Resets the [classification level](https://developer.atlassian.com/cloud/admin/dlp/rest/intro/#Classification%20level)

### Get whiteboard classification level
`GET /whiteboards/:id/classification-level`
> Returns the [classification level](https://developer.atlassian.com/cloud/admin/dlp/rest/intro/#Classification%20level)

### Update whiteboard classification level
`PUT /whiteboards/:id/classification-level`
> Updates the [classification level](https://developer.atlassian.com/cloud/admin/dlp/rest/intro/#Classification%20level)

### Reset whiteboard classification level
`POST /whiteboards/:id/classification-level/reset`
> Resets the [classification level](https://developer.atlassian.com/cloud/admin/dlp/rest/intro/#Classification%20level)

### Get database classification level
`GET /databases/:id/classification-level`
> Returns the [classification level](https://developer.atlassian.com/cloud/admin/dlp/rest/intro/#Classification%20level)

### Update database classification level
`PUT /databases/:id/classification-level`
> Updates the [classification level](https://developer.atlassian.com/cloud/admin/dlp/rest/intro/#Classification%20level)

### Reset database classification level
`POST /databases/:id/classification-level/reset`
> Resets the [classification level](https://developer.atlassian.com/cloud/admin/dlp/rest/intro/#Classification%20level)

## Comment (18 endpoints)

### Get attachment comments
`GET /attachments/:id/footer-comments`
> Returns the comments of the specific attachment.

### Get custom content comments
`GET /custom-content/:id/footer-comments`
> Returns the comments of the specific custom content.

### Get footer comments for page
`GET /pages/:id/footer-comments`
> Returns the root footer comments of specific page. The number of results is limited by the `limit` parameter and additional results (if available)

### Get inline comments for page
`GET /pages/:id/inline-comments`
> Returns the root inline comments of specific page. The number of results is limited by the `limit` parameter and additional results (if available)

### Get footer comments for blog post
`GET /blogposts/:id/footer-comments`
> Returns the root footer comments of specific blog post. The number of results is limited by the `limit` parameter and additional results (if available)

### Get inline comments for blog post
`GET /blogposts/:id/inline-comments`
> Returns the root inline comments of specific blog post. The number of results is limited by the `limit` parameter and additional results (if available)

### Get footer comments
`GET /footer-comments`
> Returns all footer comments. The number of results is limited by the `limit` parameter and additional results (if available)

### Create footer comment
`POST /footer-comments`
> Create a footer comment.

### Get footer comment by id
`GET /footer-comments/:comment-id`
> Retrieves a footer comment by id

### Update footer comment
`PUT /footer-comments/:comment-id`
> Update a footer comment. This can be used to update the body text of a comment.

### Delete footer comment
`DELETE /footer-comments/:comment-id`
> Deletes a footer comment. This is a permanent deletion and cannot be reverted.

### Get children footer comments
`GET /footer-comments/:id/children`
> Returns the children footer comments of specific comment. The number of results is limited by the `limit` parameter and additional results (if available)

### Get inline comments
`GET /inline-comments`
> Returns all inline comments. The number of results is limited by the `limit` parameter and additional results (if available)

### Create inline comment
`POST /inline-comments`
> Create an inline comment. This can be at the top level (specifying pageId or blogPostId in the request body)

### Get inline comment by id
`GET /inline-comments/:comment-id`
> Retrieves an inline comment by id

### Update inline comment
`PUT /inline-comments/:comment-id`
> Update an inline comment. This can be used to update the body text of a comment and/or to resolve the comment

### Delete inline comment
`DELETE /inline-comments/:comment-id`
> Deletes an inline comment. This is a permanent deletion and cannot be reverted.

### Get children inline comments
`GET /inline-comments/:id/children`
> Returns the children inline comments of specific comment. The number of results is limited by the `limit` parameter and additional results (if available)

## Content (1 endpoints)

### Convert content ids to content types
`POST /content/convert-ids-to-types`
> Converts a list of content ids into their associated content types. This is useful for users migrating from v1 to v2

## Content Properties (45 endpoints)

### Get content properties for attachment
`GET /attachments/:attachment-id/properties`
> Retrieves all Content Properties tied to a specified attachment.

### Create content property for attachment
`POST /attachments/:attachment-id/properties`
> Creates a new content property for an attachment.

### Get content property for attachment by id
`GET /attachments/:attachment-id/properties/:property-id`
> Retrieves a specific Content Property by ID that is attached to a specified attachment.

### Update content property for attachment by id
`PUT /attachments/:attachment-id/properties/:property-id`
> Update a content property for attachment by its id. 

### Delete content property for attachment by id
`DELETE /attachments/:attachment-id/properties/:property-id`
> Deletes a content property for an attachment by its id. 

### Get content properties for blog post
`GET /blogposts/:blogpost-id/properties`
> Retrieves all Content Properties tied to a specified blog post.

### Create content property for blog post
`POST /blogposts/:blogpost-id/properties`
> Creates a new property for a blogpost.

### Get content property for blog post by id
`GET /blogposts/:blogpost-id/properties/:property-id`
> Retrieves a specific Content Property by ID that is attached to a specified blog post.

### Update content property for blog post by id
`PUT /blogposts/:blogpost-id/properties/:property-id`
> Update a content property for blog post by its id. 

### Delete content property for blogpost by id
`DELETE /blogposts/:blogpost-id/properties/:property-id`
> Deletes a content property for a blogpost by its id. 

### Get content properties for custom content
`GET /custom-content/:custom-content-id/properties`
> Retrieves Content Properties tied to a specified custom content.

### Create content property for custom content
`POST /custom-content/:custom-content-id/properties`
> Creates a new content property for a piece of custom content.

### Get content property for custom content by id
`GET /custom-content/:custom-content-id/properties/:property-id`
> Retrieves a specific Content Property by ID that is attached to a specified custom content.

### Update content property for custom content by id
`PUT /custom-content/:custom-content-id/properties/:property-id`
> Update a content property for a piece of custom content by its id. 

### Delete content property for custom content by id
`DELETE /custom-content/:custom-content-id/properties/:property-id`
> Deletes a content property for a piece of custom content by its id. 

### Get content properties for page
`GET /pages/:page-id/properties`
> Retrieves Content Properties tied to a specified page.

### Create content property for page
`POST /pages/:page-id/properties`
> Creates a new content property for a page.

### Get content property for page by id
`GET /pages/:page-id/properties/:property-id`
> Retrieves a specific Content Property by ID that is attached to a specified page.

### Update content property for page by id
`PUT /pages/:page-id/properties/:property-id`
> Update a content property for a page by its id. 

### Delete content property for page by id
`DELETE /pages/:page-id/properties/:property-id`
> Deletes a content property for a page by its id. 

### Get content properties for whiteboard
`GET /whiteboards/:id/properties`
> Retrieves Content Properties tied to a specified whiteboard.

### Create content property for whiteboard
`POST /whiteboards/:id/properties`
> Creates a new content property for a whiteboard.

### Get content property for whiteboard by id
`GET /whiteboards/:whiteboard-id/properties/:property-id`
> Retrieves a specific Content Property by ID that is attached to a specified whiteboard.

### Update content property for whiteboard by id
`PUT /whiteboards/:whiteboard-id/properties/:property-id`
> Update a content property for a whiteboard by its id. 

### Delete content property for whiteboard by id
`DELETE /whiteboards/:whiteboard-id/properties/:property-id`
> Deletes a content property for a whiteboard by its id. 

### Get content properties for database
`GET /databases/:id/properties`
> Retrieves Content Properties tied to a specified database.

### Create content property for database
`POST /databases/:id/properties`
> Creates a new content property for a database.

### Get content property for database by id
`GET /databases/:database-id/properties/:property-id`
> Retrieves a specific Content Property by ID that is attached to a specified database.

### Update content property for database by id
`PUT /databases/:database-id/properties/:property-id`
> Update a content property for a database by its id. 

### Delete content property for database by id
`DELETE /databases/:database-id/properties/:property-id`
> Deletes a content property for a database by its id. 

### Get content properties for Smart Link in the content tree
`GET /embeds/:id/properties`
> Retrieves Content Properties tied to a specified Smart Link in the content tree.

### Create content property for Smart Link in the content tree
`POST /embeds/:id/properties`
> Creates a new content property for a Smart Link in the content tree.

### Get content property for Smart Link in the content tree by id
`GET /embeds/:embed-id/properties/:property-id`
> Retrieves a specific Content Property by ID that is attached to a specified Smart Link in the content tree.

### Update content property for Smart Link in the content tree by id
`PUT /embeds/:embed-id/properties/:property-id`
> Update a content property for a Smart Link in the content tree by its id. 

### Delete content property for Smart Link in the content tree by id
`DELETE /embeds/:embed-id/properties/:property-id`
> Deletes a content property for a Smart Link in the content tree by its id. 

### Get content properties for folder
`GET /folders/:id/properties`
> Retrieves Content Properties tied to a specified folder.

### Create content property for folder
`POST /folders/:id/properties`
> Creates a new content property for a folder.

### Get content property for folder by id
`GET /folders/:folder-id/properties/:property-id`
> Retrieves a specific Content Property by ID that is attached to a specified folder.

### Update content property for folder by id
`PUT /folders/:folder-id/properties/:property-id`
> Update a content property for a folder by its id. 

### Delete content property for folder by id
`DELETE /folders/:folder-id/properties/:property-id`
> Deletes a content property for a folder by its id. 

### Get content properties for comment
`GET /comments/:comment-id/properties`
> Retrieves Content Properties attached to a specified comment.

### Create content property for comment
`POST /comments/:comment-id/properties`
> Creates a new content property for a comment.

### Get content property for comment by id
`GET /comments/:comment-id/properties/:property-id`
> Retrieves a specific Content Property by ID that is attached to a specified comment.

### Update content property for comment by id
`PUT /comments/:comment-id/properties/:property-id`
> Update a content property for a comment by its id. 

### Delete content property for comment by id
`DELETE /comments/:comment-id/properties/:property-id`
> Deletes a content property for a comment by its id. 

## Custom Content (8 endpoints)

### Get custom content by type in blog post
`GET /blogposts/:id/custom-content`
> Returns all custom content for a given type within a given blogpost. The number of results is limited by the `limit` parameter and additional results (if available)

### Get custom content by type
`GET /custom-content`
> Returns all custom content for a given type. The number of results is limited by the `limit` parameter and additional results (if available)

### Create custom content
`POST /custom-content`
> Creates a new custom content in the given space, page, blogpost or other custom content.

### Get custom content by id
`GET /custom-content/:id`
> Returns a specific piece of custom content. 

### Update custom content
`PUT /custom-content/:id`
> Update a custom content by id.

### Delete custom content
`DELETE /custom-content/:id`
> Delete a custom content by id.

### Get custom content by type in page
`GET /pages/:id/custom-content`
> Returns all custom content for a given type within a given page. The number of results is limited by the `limit` parameter and additional results (if available)

### Get custom content by type in space
`GET /spaces/:id/custom-content`
> Returns all custom content for a given type within a given space. The number of results is limited by the `limit` parameter and additional results (if available)

## Database (3 endpoints)

### Create database
`POST /databases`
> Creates a database in the space.

### Get database by id
`GET /databases/:id`
> Returns a specific database.

### Delete database
`DELETE /databases/:id`
> Delete a database by id.

## Data Policies (2 endpoints)

### Get data policy metadata for the workspace
`GET /data-policies/metadata`
> Returns data policy metadata for the workspace.

### Get spaces with data policies
`GET /data-policies/spaces`
> Returns all spaces. The results will be sorted by id ascending. The number of results is limited by the `limit` parameter and

## Descendants (5 endpoints)

### Get descendants of a whiteboard
`GET /whiteboards/:id/descendants`
> Returns descendants in the content tree for a given whiteboard by ID in top-to-bottom order (that is, the highest descendant is the first

### Get descendants of a database
`GET /databases/:id/descendants`
> Returns descendants in the content tree for a given database by ID in top-to-bottom order (that is, the highest descendant is the first

### Get descendants of a smart link
`GET /embeds/:id/descendants`
> Returns descendants in the content tree for a given smart link by ID in top-to-bottom order (that is, the highest descendant is the first

### Get descendants of folder
`GET /folders/:id/descendants`
> Returns descendants in the content tree for a given folder by ID in top-to-bottom order (that is, the highest descendant is the first

### Get descendants of page
`GET /pages/:id/descendants`
> Returns descendants in the content tree for a given page by ID in top-to-bottom order (that is, the highest descendant is the first

## Folder (3 endpoints)

### Create folder
`POST /folders`
> Creates a folder in the space.

### Get folder by id
`GET /folders/:id`
> Returns a specific folder.

### Delete folder
`DELETE /folders/:id`
> Delete a folder by id.

## Label (7 endpoints)

### Get labels for attachment
`GET /attachments/:id/labels`
> Returns the labels of specific attachment. The number of results is limited by the `limit` parameter and additional results (if available)

### Get labels for blog post
`GET /blogposts/:id/labels`
> Returns the labels of specific blog post. The number of results is limited by the `limit` parameter and additional results (if available)

### Get labels for custom content
`GET /custom-content/:id/labels`
> Returns the labels for a specific piece of custom content. The number of results is limited by the `limit` parameter and additional results (if available)

### Get labels
`GET /labels`
> Returns all labels. The number of results is limited by the `limit` parameter and additional results (if available)

### Get labels for page
`GET /pages/:id/labels`
> Returns the labels of specific page. The number of results is limited by the `limit` parameter and additional results (if available)

### Get labels for space
`GET /spaces/:id/labels`
> Returns the labels of specific space. The number of results is limited by the `limit` parameter and additional results (if available)

### Get labels for space content
`GET /spaces/:id/content/labels`
> Returns the labels of space content (pages, blogposts etc). The number of results is limited by the `limit` parameter and additional results (if available)

## Like (8 endpoints)

### Get like count for blog post
`GET /blogposts/:id/likes/count`
> Returns the count of likes of specific blog post.

### Get account IDs of likes for blog post
`GET /blogposts/:id/likes/users`
> Returns the account IDs of likes of specific blog post.

### Get like count for page
`GET /pages/:id/likes/count`
> Returns the count of likes of specific page.

### Get account IDs of likes for page
`GET /pages/:id/likes/users`
> Returns the account IDs of likes of specific page.

### Get like count for footer comment
`GET /footer-comments/:id/likes/count`
> Returns the count of likes of specific footer comment.

### Get account IDs of likes for footer comment
`GET /footer-comments/:id/likes/users`
> Returns the account IDs of likes of specific footer comment.

### Get like count for inline comment
`GET /inline-comments/:id/likes/count`
> Returns the count of likes of specific inline comment.

### Get account IDs of likes for inline comment
`GET /inline-comments/:id/likes/users`
> Returns the account IDs of likes of specific inline comment.

## Operation (11 endpoints)

### Get permitted operations for attachment
`GET /attachments/:id/operations`
> Returns the permitted operations on specific attachment.

### Get permitted operations for blog post
`GET /blogposts/:id/operations`
> Returns the permitted operations on specific blog post.

### Get permitted operations for custom content
`GET /custom-content/:id/operations`
> Returns the permitted operations on specific custom content.

### Get permitted operations for page
`GET /pages/:id/operations`
> Returns the permitted operations on specific page.

### Get permitted operations for a whiteboard
`GET /whiteboards/:id/operations`
> Returns the permitted operations on specific whiteboard.

### Get permitted operations for a database
`GET /databases/:id/operations`
> Returns the permitted operations on specific database.

### Get permitted operations for a Smart Link in the content tree
`GET /embeds/:id/operations`
> Returns the permitted operations on specific Smart Link in the content tree.

### Get permitted operations for a folder
`GET /folders/:id/operations`
> Returns the permitted operations on specific folder.

### Get permitted operations for space
`GET /spaces/:id/operations`
> Returns the permitted operations on specific space.

### Get permitted operations for footer comment
`GET /footer-comments/:id/operations`
> Returns the permitted operations on specific footer comment.

### Get permitted operations for inline comment
`GET /inline-comments/:id/operations`
> Returns the permitted operations on specific inline comment.

## Page (8 endpoints)

### Get pages for label
`GET /labels/:id/pages`
> Returns the pages of specified label. The number of results is limited by the `limit` parameter and additional results (if available)

### Get pages
`GET /pages`
> Returns all pages. The number of results is limited by the `limit` parameter and additional results (if available)

### Create page
`POST /pages`
> Creates a page in the space.

### Get page by id
`GET /pages/:id`
> Returns a specific page.

### Update page
`PUT /pages/:id`
> Update a page by id.

### Delete page
`DELETE /pages/:id`
> Delete a page by id.

### Update page title
`PUT /pages/:id/title`
> Updates the title of a specified page.

### Get pages in space
`GET /spaces/:id/pages`
> Returns all pages in a space. The number of results is limited by the `limit` parameter and additional results (if available)

## Redactions (2 endpoints)

### Redact Content in a Confluence Page
`POST /pages/:id/redact`
> Redacts sensitive content in a Confluence page by replacing specified text ranges with redaction markers. 

### Redact Content in a Confluence Blog Post
`POST /blogposts/:id/redact`
> Redacts sensitive content in a Confluence blog post by replacing specified text ranges with redaction markers. 

## Smart Link (3 endpoints)

### Create Smart Link in the content tree
`POST /embeds`
> Creates a Smart Link in the content tree in the space.

### Get Smart Link in the content tree by id
`GET /embeds/:id`
> Returns a specific Smart Link in the content tree.

### Delete Smart Link in the content tree
`DELETE /embeds/:id`
> Delete a Smart Link in the content tree by id.

## Space (3 endpoints)

### Get spaces
`GET /spaces`
> Returns all spaces. The results will be sorted by id ascending. The number of results is limited by the `limit` parameter and

### Create space
`POST /spaces`
> Creates a Space as specified in the payload.

### Get space by id
`GET /spaces/:id`
> Returns a specific space.

## Space Permissions (2 endpoints)

### Get space permissions assignments
`GET /spaces/:id/permissions`
> Returns space permission assignments for a specific space.

### Get available space permissions
`GET /space-permissions`
> Retrieves the available space permissions.

## Space Properties (5 endpoints)

### Get space properties in space
`GET /spaces/:space-id/properties`
> Returns all properties for the given space. Space properties are a key-value storage associated with a space.

### Create space property in space
`POST /spaces/:space-id/properties`
> Creates a new space property.

### Get space property by id
`GET /spaces/:space-id/properties/:property-id`
> Retrieve a space property by its id. 

### Update space property by id
`PUT /spaces/:space-id/properties/:property-id`
> Update a space property by its id. 

### Delete space property by id
`DELETE /spaces/:space-id/properties/:property-id`
> Deletes a space property by its id. 

## Space Roles (8 endpoints)

### Get available space roles
`GET /space-roles`
> Retrieves the available space roles.

### Create a space role
`POST /space-roles`
> Create a space role.

### Get space role by ID
`GET /space-roles/:id`
> Retrieves the space role by ID.

### Update a space role
`PUT /space-roles/:id`
> Update a space role.

### Delete a space role
`DELETE /space-roles/:id`
> Delete a space role

### Get space role mode
`GET /space-role-mode`
> Retrieves the space role mode.

### Get space role assignments
`GET /spaces/:id/role-assignments`
> Retrieves the space role assignments.

### Set space role assignments
`POST /spaces/:id/role-assignments`
> Sets space role assignments as specified in the payload.

## Task (3 endpoints)

### Get tasks
`GET /tasks`
> Returns all tasks. The number of results is limited by the `limit` parameter and additional results (if available)

### Get task by id
`GET /tasks/:id`
> Returns a specific task. 

### Update task
`PUT /tasks/:id`
> Update a task by id. This endpoint currently only supports updating task status.

## User (3 endpoints)

### Create bulk user lookup using ids
`POST /users-bulk`
> Returns user details for the ids provided in the request body.

### Check site access for a list of emails
`POST /user/access/check-access-by-email`
> Returns the list of emails from the input list that do not have access to site.

### Invite a list of emails to the site
`POST /user/access/invite-by-email`
> Invite a list of emails to the site.

## Version (12 endpoints)

### Get attachment versions
`GET /attachments/:id/versions`
> Returns the versions of specific attachment.

### Get version details for attachment version
`GET /attachments/:attachment-id/versions/:version-number`
> Retrieves version details for the specified attachment and version number.

### Get blog post versions
`GET /blogposts/:id/versions`
> Returns the versions of specific blog post. 

### Get version details for blog post version
`GET /blogposts/:blogpost-id/versions/:version-number`
> Retrieves version details for the specified blog post and version number.

### Get page versions
`GET /pages/:id/versions`
> Returns the versions of specific page.

### Get version details for page version
`GET /pages/:page-id/versions/:version-number`
> Retrieves version details for the specified page and version number.

### Get custom content versions
`GET /custom-content/:custom-content-id/versions`
> Returns the versions of specific custom content.

### Get version details for custom content version
`GET /custom-content/:custom-content-id/versions/:version-number`
> Retrieves version details for the specified custom content and version number.

### Get footer comment versions
`GET /footer-comments/:id/versions`
> Retrieves the versions of the specified footer comment.

### Get version details for footer comment version
`GET /footer-comments/:id/versions/:version-number`
> Retrieves version details for the specified footer comment version.

### Get inline comment versions
`GET /inline-comments/:id/versions`
> Retrieves the versions of the specified inline comment.

### Get version details for inline comment version
`GET /inline-comments/:id/versions/:version-number`
> Retrieves version details for the specified inline comment version.

## Whiteboard (3 endpoints)

### Create whiteboard
`POST /whiteboards`
> Creates a whiteboard in the space.

### Get whiteboard by id
`GET /whiteboards/:id`
> Returns a specific whiteboard.

### Delete whiteboard
`DELETE /whiteboards/:id`
> Delete a whiteboard by id.
