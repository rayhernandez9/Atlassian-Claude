# Atlassian API Gotchas & Hard-Won Learnings

Battle-tested findings from real-world Atlassian Cloud automation. Every item here was discovered through production debugging — so you don't have to.

## Table of Contents

1. [Jira Search & Pagination](#jira-search--pagination)
2. [Jira Issue Counts](#jira-issue-counts)
3. [User & Account Type Handling](#user--account-type-handling)
4. [Rate Limiting](#rate-limiting)
5. [Confluence Permissions & Roles](#confluence-permissions--roles)
6. [Atlassian Analytics SQL](#atlassian-analytics-sql)
7. [Identity API](#identity-api)
8. [General Patterns](#general-patterns)

## Jira Search & Pagination

### Silent maxResults Cap
**Problem**: Jira REST API v3 silently caps `maxResults` at 50 regardless of what you request.  
**Fix**: Use `isLast` from the response for pagination termination, not the requested `maxResults` value.

### Deprecated Search Endpoints
The old endpoints are being removed:
- `GET /rest/api/3/search` → **410 Gone**
- `POST /rest/api/3/search` → **410 Gone / Deprecated**

**Use instead**: `POST /rest/api/3/search/jql` with `nextPageToken` for pagination (replaces `startAt`).

```python
def get_issues_with_tokens(session, base_url, jql):
    url = f"{base_url}/rest/api/3/search/jql"
    issue_keys = []
    next_token = None
    while True:
        payload = {"jql": jql, "maxResults": 50, "nextPageToken": next_token}
        response = session.post(url, json=payload)
        data = response.json()
        issues = data.get('issues', [])
        issue_keys.extend([i['key'] for i in issues])
        next_token = data.get('nextPageToken')
        if not next_token:
            break
    return issue_keys
```

## Jira Issue Counts

### The Correct Endpoint
`POST /rest/api/3/search/approximate-count` with body `{"jql": "project = \"KEY\""}` returns `{"count": N}`.

### Dead Endpoints (Do Not Use)
| Endpoint | Error |
|----------|-------|
| `GET /rest/api/3/search` | 410 Gone |
| `POST /rest/api/3/issue/search` | 405 Method Not Allowed |
| `POST /rest/api/3/search/jql` with `maxResults: 0` | 400 Bad Request (`total` field removed) |

## User & Account Type Handling

### Account Types
| `accountType` | What it is | Include? |
|---------------|-----------|----------|
| `"atlassian"` | Regular Atlassian user | Yes |
| `"customer"` | Human external/Connect account (prefix `712020:`) | Yes |
| `"app"` | Bot/service account | **No** |

**Rule**: Filter with `accountType != "app"` — NOT `accountType == "atlassian"`. The latter misses `"customer"` type human accounts.

### Active Status Checks
The Confluence v1 user endpoint (`/wiki/rest/api/user?accountId=...`) does **NOT** return `accountStatus`. It simply omits the field.

**Only reliable method**: Identity API
```python
url = f"https://api.atlassian.com/users/{account_id}/manage/lifecycle"
resp = session.get(url)
status = resp.json().get('account_status')  # 'active', 'inactive', 'closed'
```

### Group Membership as Source of Truth
If your organization syncs groups from an identity provider (Azure AD, Okta, etc.), group membership can serve as the authoritative source for "active user" detection rather than individual API calls per user.

## Rate Limiting

### Jira 429 Responses
- Read the `Retry-After` header directly from the response
- Exponential backoff: start at 2s, double each retry, cap at 60s
- Maximum 5 retry attempts
- Use **5 thread workers** (not 10) for Jira API calls to stay under rate limits

```python
import time

def jira_request_with_backoff(session, method, url, **kwargs):
    backoff = 2
    for attempt in range(5):
        resp = getattr(session, method)(url, **kwargs)
        if resp.status_code == 429:
            wait = int(resp.headers.get('Retry-After', backoff))
            time.sleep(min(wait, 60))
            backoff = min(backoff * 2, 60)
            continue
        return resp
    return resp  # Return last response after all retries
```

### Session Retry Configuration
The `urllib3.util.retry.Retry` in `create_session()` handles most transient errors automatically, but explicit 429 handling with `Retry-After` is still recommended for critical operations.

## Confluence Permissions & Roles

### v2 Roles API vs v1 Permissions
- **Custom roles** (e.g., Space Admin, Editors, Viewers): Use Confluence v2 Roles API (`/wiki/api/v2/space-roles/`, `/wiki/api/v2/spaces/{id}/role-assignments`)
- **Native `administer:space` for Admins group**: Must use Confluence **v1** API (`PUT /wiki/rest/api/space/{spaceKey}/permission`)

### Contributor Lookback
When promoting active contributors to elevated roles, a 12-month lookback window (365 days) with two-layer filtering — first by recency, then by version count ranking — works well for identifying who actually uses a space.

## Atlassian Analytics SQL

### Correct Table Names
| Correct | Wrong (will fail) |
|---------|-------------------|
| `jira_issue_history` | `jira_issue_field_history` |

### Field Value Names
| Correct | Wrong |
|---------|-------|
| `'duedate'` | `'due_date'` |

### Schema Discovery
**Always** fetch the schema documentation before writing any history/changelog query:
```
https://support.atlassian.com/analytics/docs/schema-for-jira-software/
```

This surfaces correct table names, column names, and field value constants — avoiding multiple rounds of trial and error.

## Identity API

### Base URL
`https://api.atlassian.com/users/{accountId}/manage/`

### Key Endpoints
- `GET /lifecycle` — Account status (active/inactive/closed)
- `GET /profile` — User profile details

### Auth
Uses the same API token as Jira/Confluence, but with `Bearer` token auth for Atlassian admin APIs (org-scoped), or Basic auth for user-scoped operations.

## General Patterns

### Script Structure
Every script follows this exact order:
1. `setup_runtime()` — Check/install dependencies
2. `get_session_config()` — Environment selection + Dry Run gate
3. `create_session()` — Requests session with retry logic
4. Core logic with `ThreadPoolExecutor`
5. `log_action()` — CSV audit logging with progress counter

### Dry Run Guard
All state-changing API calls (POST, PUT, DELETE) must be wrapped:
```python
if not cfg['dry_run']:
    resp = session.post(url, json=payload)
else:
    print(f"[DRY RUN] Would POST to {url} with payload: {json.dumps(payload, indent=2)}")
```

### Bug Fix Protocol
1. Examine the specific audit log entry showing wrong behavior
2. State expected behavior concisely
3. Diagnose root cause from evidence before any code changes
4. Apply fix via Python string replacement
5. AST syntax validation after edit
6. Assertion-based verification before deployment
