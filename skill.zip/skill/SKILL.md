---
name: atlassian-enterprise
description: "Manages Jira, Confluence, JSM, and Atlassian Analytics using Python scripts and Atlassian Cloud REST APIs. Triggers on: creating/searching/updating Jira issues, Confluence space permissions, RBAC role migration, sprint planning, epic management, bulk operations, Atlassian Analytics SQL queries, permission audits, user/group management, JQL queries, or any mention of Jira, Confluence, or Atlassian. Also triggers when working with the base_script.py pattern, config.json environment setup, or any Atlassian REST API endpoint. Use this skill even if the user just says 'write a script for Jira' or 'help me with Confluence' — it covers the full Atlassian Cloud platform."
---

# Atlassian Enterprise Automation Skill

Comprehensive skill for automating Jira Cloud (v3), Confluence Cloud (v2), JSM, Organizations API, and Atlassian Analytics using Python scripts against the Atlassian Cloud REST API.

## Architecture Overview

All scripts use direct Python `requests` against Atlassian Cloud REST APIs — **not** the Atlassian MCP server. This gives full control over payloads, rate limiting, and audit logging.

Every script follows the **base_script.py** pattern (see `templates/base_script.py`):
1. **Environment selection** — Production vs Sandbox (or any custom environments) from `config.json`
2. **Dry Run gate** — Default `True`; all state-changing calls guarded by `if not cfg['dry_run']:`
3. **Session with retries** — Exponential backoff for 429/5xx via `urllib3.util.retry`
4. **Concurrent execution** — `ThreadPoolExecutor` with configurable workers (default 10, use 5 for Jira to avoid rate limits)
5. **CSV audit logging** — Every action logged to `Audit_Log_YYYYMMDD_HHMM.csv`

Read `templates/base_script.py` before writing any new script — it is the canonical starting point.

## Configuration

Scripts load credentials from a local `config.json` file. If it doesn't exist, the script creates a template and exits with instructions. The structure is:

```json
{
  "environments": {
    "Production": {
      "Production": {
        "base_url": "https://your-instance.atlassian.net",
        "email": "YOUR_EMAIL@company.com",
        "api_token": "YOUR_API_TOKEN"
      }
    },
    "Sandbox": {
      "Sandbox": {
        "base_url": "https://your-instance-sandbox.atlassian.net/wiki",
        "email": "YOUR_EMAIL@company.com",
        "api_token": "YOUR_API_TOKEN"
      }
    }
  }
}
```

Config path: `config.json` is auto-detected next to the script being run. If it doesn't exist, the script creates a template and exits with instructions to fill in credentials. Placeholder credentials are detected and blocked before any API call is made.  
Output path: `/mnt/user-data/outputs/`

URL handling: strip `/wiki` from base_url first, then append `/wiki` for Confluence or use bare URL for Jira.

You can add as many environments as you need — the script dynamically lists them at startup.

## API Version Standards

| Product | API Version | Base Path | Content Format |
|---------|------------|-----------|----------------|
| Jira | v3 | `/rest/api/3/` | ADF (Atlassian Document Format) |
| Confluence | v2 | `/wiki/api/v2/` | Storage format (XHTML) |
| Confluence (legacy) | v1 | `/wiki/rest/api/` | Storage format (XHTML) |
| Identity | — | `https://api.atlassian.com/users/` | JSON |
| Organizations | — | `https://api.atlassian.com/admin/v1/orgs/` | JSON |

Use v2 for Confluence by default. Fall back to v1 only for features not yet in v2 (e.g., native `administer:space` permission grants).

## Critical API Gotchas (Hard-Won)

These are battle-tested findings. Read `references/api_gotchas.md` for the full list. The top ones:

1. **Jira search pagination** — `POST /rest/api/3/search/jql` with `nextPageToken`. The old `GET/POST /rest/api/3/search` endpoints are being removed (410/deprecated). Use `isLast` from the response to know when to stop, not the requested `maxResults`, because the API silently caps at 50.

2. **Jira approximate count** — `POST /rest/api/3/search/approximate-count` with `{"jql": "project = \"KEY\""}` returns `{"count": N}`. Dead alternatives: `GET /rest/api/3/search` (410), `POST /rest/api/3/issue/search` (405), `POST /rest/api/3/search/jql` with `maxResults: 0` (400, `total` field removed).

3. **User active status** — The Confluence v1 user endpoint does NOT return `accountStatus`. Only the Identity API (`https://api.atlassian.com/users/{accountId}/manage/lifecycle`) is reliable for active-status checks.

4. **Account type filtering** — Use `accountType != "app"` to filter bots. Do NOT use `accountType == "atlassian"` because human external/Connect accounts use `accountType: "customer"` (prefix `712020:`).

5. **Jira 429 handling** — Read the `Retry-After` header directly. Exponential backoff: double from 2s, cap at 60s, across 5 attempts. Use 5 thread workers (not 10) for Jira API calls.

6. **Atlassian Analytics** — Correct table is `jira_issue_history` (not `jira_issue_field_history`). Due date field value is `'duedate'` (no underscore). Always fetch the schema docs at `https://support.atlassian.com/analytics/docs/schema-for-jira-software/` before writing any history/changelog query.

7. **Confluence v2 pagination** — Use cursor-based pagination (`?cursor=...`). The response includes `_links.next` with the cursor parameter.

## Jira Engineering

### Search & Pagination

Use `POST /rest/api/3/search/jql` with token-based pagination:

```python
def get_issues(session, base_url, jql):
    url = f"{base_url}/rest/api/3/search/jql"
    all_issues = []
    next_token = None
    while True:
        payload = {"jql": jql, "maxResults": 50, "nextPageToken": next_token}
        resp = session.post(url, json=payload)
        data = resp.json()
        all_issues.extend(data.get('issues', []))
        next_token = data.get('nextPageToken')
        if not next_token:
            break
    return all_issues
```

For issue counts without fetching issues: `POST /rest/api/3/search/approximate-count`.

For comprehensive JQL reference, read `references/jql_guide.md`.

### Issue Creation

All description/comment fields use ADF (Atlassian Document Format), not plain text or markdown:

```python
def create_adf_paragraph(text):
    return {
        "version": 1,
        "type": "doc",
        "content": [{"type": "paragraph", "content": [{"type": "text", "text": text}]}]
    }

payload = {
    "fields": {
        "project": {"key": "PROJ"},
        "summary": "Issue title",
        "issuetype": {"name": "Task"},
        "description": create_adf_paragraph("Description here"),
        "priority": {"name": "High"},
        "labels": ["label1"]
    }
}
session.post(f"{base_url}/rest/api/3/issue", json=payload)
```

See `templates/issue_creation.json` for field format reference and common templates.  
See `references/custom_field_discovery.md` for finding custom field IDs.

### Transitions

```python
# Get available transitions
resp = session.get(f"{base_url}/rest/api/3/issue/{issue_key}/transitions")
transitions = resp.json()['transitions']

# Execute transition
payload = {"transition": {"id": transition_id}}
session.post(f"{base_url}/rest/api/3/issue/{issue_key}/transitions", json=payload)
```

### Bulk Operations

Use `concurrent.futures.ThreadPoolExecutor` with 5 workers for Jira (rate-limit safe):

```python
with concurrent.futures.ThreadPoolExecutor(max_workers=5) as executor:
    futures = {executor.submit(worker, key): key for key in issue_keys}
    for i, future in enumerate(concurrent.futures.as_completed(futures)):
        result = future.result()
        log_action(log_file, result)
        print(f"Progress: {((i+1)/total)*100:.1f}%", end='\r')
```

## Confluence Engineering

### Space Roles (RBAC) — v2 API

The Confluence v2 Roles API lets you define custom roles for space access control. Example 4-role model:

| Role | Purpose |
|------|---------|
| Space Admin | Full space management |
| Editors | Create and edit content |
| View & Comment | Read-only with commenting |
| Externals | Limited access for external users |

Key endpoints (all under `/wiki/api/v2/`):

```
GET    /space-roles              — List available roles
POST   /space-roles              — Create a role
GET    /space-roles/:id          — Get role by ID
PUT    /space-roles/:id          — Update a role
DELETE /space-roles/:id          — Delete a role
GET    /space-role-mode          — Get role mode (enabled/disabled)
GET    /spaces/:id/role-assignments    — Get current assignments
POST   /spaces/:id/role-assignments    — Set role assignments
```

For the Admins group native `administer:space` permission, use the **v1** API:
```
PUT /wiki/rest/api/space/{spaceKey}/permission
```

### Pages

```python
# Create page
payload = {
    "spaceId": space_id,
    "status": "current",
    "title": "Page Title",
    "body": {
        "representation": "storage",
        "value": "<p>XHTML content here</p>"
    }
}
session.post(f"{base_url}/wiki/api/v2/pages", json=payload)

# Get pages in space (cursor pagination)
url = f"{base_url}/wiki/api/v2/spaces/{space_id}/pages"
while url:
    resp = session.get(url)
    data = resp.json()
    pages = data.get('results', [])
    url = data.get('_links', {}).get('next')
```

### Space Permissions (v2)

```
GET /wiki/api/v2/spaces/:id/permissions         — Get permission assignments
GET /wiki/api/v2/space-permissions               — Get available permissions
```

## Organizations & Identity APIs

### Organizations REST API

Base: `https://api.atlassian.com/admin/v1/orgs/{orgId}/`

Key endpoints:
- `GET /users` — List org users
- `GET /groups` — List org groups
- `POST /groups` — Create group
- `GET /groups/{groupId}` — Group details
- `POST /groups/{groupId}/users` — Add user to group
- `DELETE /groups/{groupId}/users/{userId}` — Remove user
- `GET /events` — Audit log events

### API Access

Base: `https://api.atlassian.com/admin/v1/orgs/{orgId}/`

- `GET /api-tokens` — List all API tokens
- `POST /api-tokens/revoke` — Bulk revoke tokens
- `GET /api-keys` — List API keys

### Identity API (User Status)

```python
def check_user_active(session, account_id):
    """Only reliable method for active-status checks."""
    url = f"https://api.atlassian.com/users/{account_id}/manage/lifecycle"
    resp = session.get(url)
    return resp.json().get('account_status') == 'active'
```

## Atlassian Analytics (SQL)

For querying Jira data via Atlassian Analytics SQL:

1. **Always fetch the schema first**: `https://support.atlassian.com/analytics/docs/schema-for-jira-software/`
2. Correct table for changelog: `jira_issue_history` (NOT `jira_issue_field_history`)
3. Due date field value: `'duedate'` (no underscore)
4. Use ISO 8601 dates in WHERE clauses

## Confluence Permissions Migration (Example Use Case)

A common enterprise task is migrating Confluence spaces from legacy individual permission grants to a standardised RBAC role model. Typical migration steps:

1. Enumerate space members via current permissions
2. Check group membership to determine active users
3. Filter by `accountType != "app"` to exclude bots
4. Map legacy roles to new custom roles (e.g., Admin → Space Admin, Collaborator → Editors)
5. Promote top contributors (based on version count over a lookback period) to elevated roles
6. Log all changes to audit CSV for rollback capability

## Debugging Protocol

When investigating bugs in automation scripts:
1. Examine the specific audit log entry showing wrong behavior
2. State expected behavior concisely
3. Diagnose root cause from evidence **before** making any code changes
4. Apply fix via Python string replacement with AST syntax validation
5. Verify with assertion-based checks before deployment

## API Reference Files

For complete endpoint listings, read the appropriate reference file:

| File | Content |
|------|---------|
| `references/jql_guide.md` | Comprehensive JQL syntax, operators, functions, pitfalls |
| `references/custom_field_discovery.md` | Finding and mapping custom field IDs |
| `references/api_gotchas.md` | Battle-tested API quirks and workarounds |
| `references/jira_api_reference.md` | Full Jira Cloud v3 endpoint catalog |
| `references/confluence_api_reference.md` | Full Confluence Cloud v2 endpoint catalog |
| `references/org_api_reference.md` | Organizations + API Access endpoint catalog |
| `templates/base_script.py` | Canonical script template |
| `templates/issue_creation.json` | Issue creation field format reference |
