import os
import sys
import json
import csv
import subprocess
import concurrent.futures
import urllib3
import requests
from datetime import datetime
from requests.auth import HTTPBasicAuth
from urllib3.util.retry import Retry
from requests.adapters import HTTPAdapter

# 1. ── PRE-FLIGHT SETTINGS ──────────────────────────────────────────────────
urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)

def setup_runtime():
    """Checks and installs missing libraries automatically."""
    required = ["requests", "atlassian-python-api"]
    for package in required:
        try:
            __import__(package.replace('-', '_'))
        except ImportError:
            print(f"📦 Missing dependency found. Installing {package}...")
            subprocess.check_call([sys.executable, "-m", "pip", "install", package])

# 2. ── SESSION & RETRY MANAGEMENT ───────────────────────────────────────────
def create_session(email, token):
    """Creates a requests session with built-in retries for 429 and 5xx errors."""
    session = requests.Session()
    session.auth = HTTPBasicAuth(email, token)
    session.headers.update({"Accept": "application/json", "Content-Type": "application/json"})

    # Exponential backoff for rate limiting
    retries = Retry(
        total=5,
        backoff_factor=1,
        status_forcelist=[429, 500, 502, 503, 504],
        raise_on_status=False,
        allowed_methods=["GET", "POST", "PUT", "DELETE"]
    )

    adapter = HTTPAdapter(max_retries=retries)
    session.mount("http://", adapter)
    session.mount("https://", adapter)
    return session

# 3. ── CONFIGURATION LOADER ─────────────────────────────────────────────────
CONFIG_TEMPLATE = {
    "environments": {
        "Production": {
            "Production": {
                "base_url": "https://your-instance.atlassian.net",
                "email": "YOUR_EMAIL@company.com",
                "api_token": "YOUR_API_TOKEN"
            }
        },
        "Sandbox": {
            "Sandbox": {
                "base_url": "https://your-instance-sandbox.atlassian.net/wiki",
                "email": "YOUR_EMAIL@company.com",
                "api_token": "YOUR_API_TOKEN"
            }
        }
    }
}

def get_session_config():
    """Handles App selection, Env selection, and Dry Run gating."""
    # config.json lives next to the script being executed
    script_dir = os.path.dirname(os.path.abspath(__file__))
    config_path = os.path.join(script_dir, 'config.json')

    if not os.path.isfile(config_path):
        with open(config_path, 'w') as f:
            json.dump(CONFIG_TEMPLATE, f, indent=4)
        print(f"⚠️  config.json was not found — created a template at:\n   {config_path}")
        print(f"\n   Open it and replace YOUR_EMAIL and YOUR_API_TOKEN with your")
        print(f"   Atlassian credentials, then re-run this script.")
        sys.exit(0)

    with open(config_path, 'r') as f:
        config_data = json.load(f)

    # Warn if credentials are still placeholder values
    for env_name, env_block in config_data.get('environments', {}).items():
        for inner_name, inner_block in env_block.items():
            if inner_block.get('api_token') in ('YOUR_API_TOKEN', 'TOKEN', ''):
                print(f"⚠️  Credentials missing in config.json → {env_name} / {inner_name}")
                print(f"   Open {config_path} and fill in your email + API token.")
                sys.exit(0)

    # Step A: Select Application
    print("\nSelect Application:\n1. Jira\n2. Confluence")
    app_choice = input("Enter 1 or 2: ")
    app_type = "Jira" if app_choice == '1' else "Confluence"

    # Step B: Select Environment
    envs = list(config_data['environments'].keys())
    print(f"\nSelect Environment for {app_type}:")
    for i, env in enumerate(envs, 1):
        print(f"{i}. {env}")
    env_choice = int(input(f"Enter 1-{len(envs)}: ")) - 1
    target = envs[env_choice]
    inner = list(config_data['environments'][target].keys())[0]

    try:
        env_info = config_data['environments'][target][inner]
    except (KeyError, IndexError):
        print(f"❌ Error: Structure for {target} not found in config.json")
        sys.exit(1)

    # Step C: URL Formatting (Jira root vs Confluence /wiki)
    base_url = env_info['base_url'].replace('/wiki', '').rstrip('/')
    final_url = f"{base_url}/wiki" if app_type == "Confluence" else base_url

    # Step D: Dry Run Gate
    print(f"\n⚠️  Targeting: {target} ({final_url})")
    dr_choice = input("Enable Dry Run? (Y/n): ").strip().lower()
    dry_run = False if dr_choice == 'n' else True

    return {
        "url": final_url,
        "email": env_info['email'],
        "token": env_info['api_token'],
        "app": app_type,
        "dry_run": dry_run,
        "env_label": target
    }

# 4. ── AUDIT LOGGING ────────────────────────────────────────────────────────
def log_action(filename, data):
    """Writes results to a CSV log with enterprise-standard columns."""
    file_exists = os.path.isfile(filename)
    with open(filename, 'a', newline='') as f:
        writer = csv.writer(f)
        if not file_exists:
            writer.writerow(['Timestamp', 'Environment', 'Action', 'Entity_Key', 'Status', 'Resp_Code'])
        writer.writerow(data)

# 5. ── CORE EXECUTION ───────────────────────────────────────────────────────
def main():
    setup_runtime()
    cfg = get_session_config()
    session = create_session(cfg['email'], cfg['token'])
    log_file = f"Audit_Log_{datetime.now().strftime('%Y%m%d_%H%M')}.csv"

    print(f"\n🚀 Execution Started | Mode: {'🛡️ DRY RUN' if cfg['dry_run'] else '🔥 LIVE'}")

    # --- JIRA SEARCH LOGIC (Token-based Pagination) ---
def get_approximate_count(session, base_url, jql):
    """Specific endpoint for Enterprise-scale counts."""
    url = f"{base_url}/rest/api/3/search/approximate-count"
    response = session.post(url, json={"jql": jql})
    return response.json().get("count", 0)

def get_issues_with_tokens(session, base_url, jql):
    """Correct POST /search/jql logic using nextPageToken."""
    url = f"{base_url}/rest/api/3/search/jql"
    issue_keys = []
    next_token = None
    
    while True:
        payload = {
            "jql": jql,
            "maxResults": 50,
            "nextPageToken": next_token  # Replaces startAt
        }
        response = session.post(url, json=payload)
        data = response.json()
        
        issues = data.get('issues', [])
        issue_keys.extend([i['key'] for i in issues])
        
        next_token = data.get('nextPageToken')
        if not next_token:
            break
            
    return issue_keys

    # Example: Process issues from a specific JQL
    issue_keys = get_all_issues("project = 'PROJ' AND status = 'Open'")
    total = len(issue_keys)

    def worker_task(issue_key):
        now = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
        if cfg['dry_run']:
            return [now, cfg['env_label'], "SIMULATE", issue_key, "DRY_RUN", "000"]
        
        # Example: Perform an action on the issue
        url = f"{cfg['url']}/rest/api/3/issue/{issue_key}"
        response = session.get(url)
        return [now, cfg['env_label'], "GET", issue_key, "SUCCESS", response.status_code]

    # --- MULTITHREADED EXECUTION ---
    with concurrent.futures.ThreadPoolExecutor(max_workers=10) as executor:
        future_to_item = {executor.submit(worker_task, key): key for key in issue_keys}
        
        for i, future in enumerate(concurrent.futures.as_completed(future_to_item)):
            result = future.result()
            log_action(log_file, result)
            
            progress = ((i + 1) / total) * 100 if total > 0 else 100
            print(f"Progress: {progress:.1f}% | Last Entity: {result[3]}", end='\r')

    print(f"\n\n✅ Done. Audit log saved to: {log_file}")

if __name__ == "__main__":
    main()
