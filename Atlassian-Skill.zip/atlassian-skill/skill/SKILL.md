---
name: atlassian-enterprise
description: "Generates production-ready Python automation scripts for Jira Cloud (v3), Confluence Cloud (v2), JSM, and Atlassian Analytics. Triggers on: any request to automate Jira or Confluence, JQL queries, bulk issue operations, space permissions, user/group management, Atlassian Analytics SQL, sprint/epic management, permission audits, or any mention of Jira, Confluence, Atlassian, or Atlassian Cloud REST APIs. Also triggers when working with base_script.py, config.json environment setup, or Atlassian API endpoints."
---

# Atlassian Cloud Automation Skill

Expert Atlassian Cloud engineer skill. Generates production-ready Python scripts for Jira (v3), Confluence (v2), JSM, Organizations API, and Atlassian Analytics using direct `requests` against the Atlassian Cloud REST API.

## Core Instruction

Read `skill/SYSTEM_PROMPT.md` — it contains all engineering standards, API gotchas, and code patterns. Apply everything in it to every script generated.

## Additional Files

| File | Purpose |
|------|---------|
| `skill/SYSTEM_PROMPT.md` | Complete engineering standards (start here) |
| `skill/references/api_gotchas.md` | Extended API quirks with code examples |
| `skill/references/jql_guide.md` | JQL syntax, operators, functions |
| `skill/references/custom_field_discovery.md` | Finding custom field IDs |
| `skill/references/jira_api_reference.md` | Jira v3 endpoint catalog |
| `skill/references/confluence_api_reference.md` | Confluence v2 endpoint catalog |
| `skill/references/org_api_reference.md` | Organizations + Identity API catalog |
| `skill/templates/base_script.py` | Canonical script template — always use as starting point |
| `skill/templates/issue_creation.json` | Issue creation field format reference |

## Claude-Specific Behavior

- When a user describes what they want in plain English, generate the complete script without asking for clarification first
- When debugging, examine evidence before writing any code
- Prefer `requests` over `atlassian-python-api` for all v3/v2 endpoints
- Use `max_workers=5` for Jira, `max_workers=10` for Confluence
