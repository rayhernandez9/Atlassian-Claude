import os
import sys
import json
import csv
import subprocess
import concurrent.futures
import urllib3
import requests
from datetime import datetime
from requests.auth import HTTPBasicAuth
from urllib3.util.retry import Retry
from requests.adapters import HTTPAdapter

# ── PRE-FLIGHT ───────────────────────────────────────────────────────────────
urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)

SCRIPT_DIR = os.path.dirname(os.path.abspath(__file__))
CONFIG_PATH = os.path.join(SCRIPT_DIR, "config.json")

CONFIG_TEMPLATE = {
    "environments": {
        "Production": {
            "Production": {
                "base_url": "https://your-instance.atlassian.net",
                "email": "YOUR_EMAIL@company.com",
                "api_token": "YOUR_API_TOKEN"
            }
        },
        "Sandbox": {
            "Sandbox": {
                "base_url": "https://your-sandbox.atlassian.net",
                "email": "YOUR_EMAIL@company.com",
                "api_token": "YOUR_API_TOKEN"
            }
        }
    }
}

def setup_runtime():
    """Checks and installs missing libraries automatically."""
    required = ["requests", "urllib3"]
    for package in required:
        try:
            __import__(package.replace("-", "_"))
        except ImportError:
            print(f"📦 Installing missing dependency: {package}...")
            subprocess.check_call([sys.executable, "-m", "pip", "install", package])


# ── SESSION & RETRY ──────────────────────────────────────────────────────────
def create_session(email, token):
    """Creates a requests session with exponential backoff for 429/5xx."""
    session = requests.Session()
    session.auth = HTTPBasicAuth(email, token)
    session.headers.update({"Accept": "application/json", "Content-Type": "application/json"})

    retries = Retry(
        total=5,
        backoff_factor=2,
        status_forcelist=[429, 500, 502, 503, 504],
        raise_on_status=False,
        allowed_methods=["GET", "POST", "PUT", "DELETE"]
    )
    adapter = HTTPAdapter(max_retries=retries)
    session.mount("http://", adapter)
    session.mount("https://", adapter)
    return session


# ── CONFIG LOADER ────────────────────────────────────────────────────────────
def get_session_config():
    """Handles environment selection and Dry Run gating."""
    if not os.path.isfile(CONFIG_PATH):
        with open(CONFIG_PATH, "w") as f:
            json.dump(CONFIG_TEMPLATE, f, indent=4)
        print(f"\n⚠️  config.json was not found — created a template at:\n   {CONFIG_PATH}")
        print("\n   Open it and replace the placeholder values with your Atlassian credentials,")
        print("   then re-run this script.\n")
        sys.exit(0)

    with open(CONFIG_PATH, "r") as f:
        config_data = json.load(f)

    environments = config_data.get("environments", {})
    env_names = list(environments.keys())

    if not env_names:
        print("❌ No environments found in config.json")
        sys.exit(1)

    # Step A: Select Application
    print("\nSelect Application:\n1. Jira\n2. Confluence")
    app_choice = input("Enter 1 or 2: ").strip()
    app_type = "Jira" if app_choice == "1" else "Confluence"

    # Step B: Select Environment
    print(f"\nSelect Environment for {app_type}:")
    for i, name in enumerate(env_names, 1):
        print(f"{i}. {name}")
    env_idx = int(input(f"Enter 1-{len(env_names)}: ").strip()) - 1
    env_name = env_names[env_idx]
    inner_key = list(environments[env_name].keys())[0]
    env_info = environments[env_name][inner_key]

    # Step C: URL Formatting
    base_url = env_info["base_url"].replace("/wiki", "").rstrip("/")
    final_url = f"{base_url}/wiki" if app_type == "Confluence" else base_url

    # Step D: Dry Run Gate
    print(f"\n⚠️  Targeting: {env_name} ({final_url})")
    dr_choice = input("Enable Dry Run? (Y/n): ").strip().lower()
    dry_run = dr_choice != "n"

    return {
        "url": final_url,
        "email": env_info["email"],
        "token": env_info["api_token"],
        "app": app_type,
        "dry_run": dry_run,
        "env_label": env_name
    }


# ── AUDIT LOGGING ────────────────────────────────────────────────────────────
def log_action(filename, data):
    """Appends a result row to the CSV audit log."""
    file_exists = os.path.isfile(filename)
    with open(filename, "a", newline="") as f:
        writer = csv.writer(f)
        if not file_exists:
            writer.writerow(["Timestamp", "Environment", "Action", "Entity_Key", "Status", "Resp_Code"])
        writer.writerow(data)


# ── JIRA HELPERS ─────────────────────────────────────────────────────────────
def get_issues(session, base_url, jql):
    """Paginates POST /rest/api/3/search/jql using nextPageToken."""
    url = f"{base_url}/rest/api/3/search/jql"
    all_issues, next_token = [], None
    while True:
        payload = {"jql": jql, "maxResults": 50, "nextPageToken": next_token}
        data = session.post(url, json=payload).json()
        all_issues.extend(data.get("issues", []))
        next_token = data.get("nextPageToken")
        if not next_token:
            break
    return all_issues


def get_approximate_count(session, base_url, jql):
    """Returns issue count without fetching issues."""
    url = f"{base_url}/rest/api/3/search/approximate-count"
    return session.post(url, json={"jql": jql}).json().get("count", 0)


def adf_paragraph(text):
    """Wraps plain text in Atlassian Document Format."""
    return {
        "version": 1, "type": "doc",
        "content": [{"type": "paragraph", "content": [{"type": "text", "text": text}]}]
    }


# ── CORE EXECUTION ───────────────────────────────────────────────────────────
def main():
    setup_runtime()
    cfg = get_session_config()
    session = create_session(cfg["email"], cfg["token"])
    log_file = f"Audit_Log_{datetime.now().strftime('%Y%m%d_%H%M')}.csv"

    print(f"\n🚀 Execution Started | Mode: {'🛡️ DRY RUN' if cfg['dry_run'] else '🔥 LIVE'}\n")

    # ── YOUR LOGIC GOES HERE ─────────────────────────────────────────────────
    # Example: fetch issues matching a JQL query
    issue_keys = [i["key"] for i in get_issues(session, cfg["url"], "project = 'MYPROJ' AND status = 'Open'")]
    total = len(issue_keys)
    print(f"Found {total} issues to process.\n")

    def worker_task(issue_key):
        now = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
        if cfg["dry_run"]:
            print(f"  [DRY RUN] Would process: {issue_key}")
            return [now, cfg["env_label"], "SIMULATE", issue_key, "DRY_RUN", "000"]

        url = f"{cfg['url']}/rest/api/3/issue/{issue_key}"
        resp = session.get(url)
        status = "SUCCESS" if resp.status_code == 200 else "ERROR"
        return [now, cfg["env_label"], "GET", issue_key, status, resp.status_code]

    with concurrent.futures.ThreadPoolExecutor(max_workers=5) as executor:
        futures = {executor.submit(worker_task, key): key for key in issue_keys}
        for i, future in enumerate(concurrent.futures.as_completed(futures)):
            result = future.result()
            log_action(log_file, result)
            print(f"Progress: {((i+1)/total)*100:.1f}% | Last: {result[3]}", end="\r")

    print(f"\n\n✅ Done. Audit log: {log_file}")


if __name__ == "__main__":
    main()
