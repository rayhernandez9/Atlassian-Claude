# Using This Skill with OpenAI

## Custom GPTs (ChatGPT)

Custom GPTs let you attach a system prompt and knowledge files that persist across conversations.

1. Go to [chatgpt.com](https://chatgpt.com) → **Explore GPTs → Create**
2. Click **Configure**
3. In the **Instructions** field, paste the full contents of `skill/SYSTEM_PROMPT.md`
4. Under **Knowledge**, upload:
   - `skill/references/api_gotchas.md`
   - `skill/templates/base_script.py`
   - `config.sample.json`
   - Any other reference files you want the GPT to use
5. Set **Capabilities**: enable Code Interpreter if you want it to run/test scripts
6. Save and publish (to yourself or your team)

**Tip:** In the GPT name/description, include "Atlassian" so it's easy to find.

**Example prompt to test:**
> "Write a script to export all Jira issues from project MYPROJ that are overdue, to a CSV file."

---

## Assistants API

If you're using the OpenAI Assistants API, attach the system prompt and upload reference files as knowledge:

```python
from openai import OpenAI
import os

client = OpenAI(api_key=os.environ["OPENAI_API_KEY"])

# Upload reference files
files = []
for filename in ["skill/references/api_gotchas.md", "skill/templates/base_script.py"]:
    with open(filename, "rb") as f:
        uploaded = client.files.create(file=f, purpose="assistants")
        files.append(uploaded.id)

# Read system prompt
with open("skill/SYSTEM_PROMPT.md", "r") as f:
    system_prompt = f.read()

# Create assistant
assistant = client.beta.assistants.create(
    name="Atlassian Automation Engineer",
    instructions=system_prompt,
    model="gpt-4o",
    tools=[{"type": "file_search"}, {"type": "code_interpreter"}],
    tool_resources={
        "file_search": {"vector_store_ids": []},  # attach a vector store if needed
    }
)
```

---

## Direct API (Chat Completions)

For one-off use via the Chat Completions API:

```python
from openai import OpenAI

client = OpenAI()

with open("skill/SYSTEM_PROMPT.md", "r") as f:
    system_prompt = f.read()

response = client.chat.completions.create(
    model="gpt-4o",
    messages=[
        {"role": "system", "content": system_prompt},
        {"role": "user", "content": "Write a script to find all Confluence spaces where no page has been edited in 6 months."}
    ]
)
print(response.choices[0].message.content)
```

---

## Notes on GPT-4 Compatibility

The system prompt uses markdown formatting and code blocks that GPT-4 and GPT-4o handle natively. No modifications needed.

If you hit token limits with very long reference files, either:
- Use the Assistants API with file search (recommended)
- Truncate the reference files to the sections most relevant to your use case
