# Using This Skill with Claude

## Claude.ai Projects (Recommended)

Claude Projects let you attach files that Claude reads at the start of every conversation.

1. Open [claude.ai](https://claude.ai) and create or open a **Project**
2. In the Project sidebar, click **Project Knowledge → Add content**
3. Upload the entire `skill/` folder, or at minimum:
   - `skill/SYSTEM_PROMPT.md` ← Required
   - `skill/SKILL.md` ← Required for auto-triggering
   - `skill/references/api_gotchas.md` ← Strongly recommended
   - `skill/templates/base_script.py` ← Required

4. Start a new conversation in the Project. Claude will apply the skill automatically when you mention Jira, Confluence, or Atlassian.

**Example prompt to test:**
> "Write me a script that finds all Jira issues in project MYPROJ that haven't been updated in 30 days and exports them to CSV."

Claude will generate a complete, production-ready script using the base template.

---

## Claude Code (CLI)

If you use [Claude Code](https://docs.anthropic.com/en/docs/claude-code), place the `skill/` folder in your project directory and reference it in your `CLAUDE.md`:

```markdown
# CLAUDE.md

## Atlassian Automation
When writing Atlassian automation scripts, read and follow skill/SKILL.md and skill/SYSTEM_PROMPT.md.
```

Claude Code will pick this up automatically on every session.

---

## API / System Prompt

If you're calling the Claude API directly, paste the contents of `skill/SYSTEM_PROMPT.md` into the `system` parameter:

```python
import anthropic

with open("skill/SYSTEM_PROMPT.md", "r") as f:
    system_prompt = f.read()

client = anthropic.Anthropic()
message = client.messages.create(
    model="claude-opus-4-5",
    max_tokens=4096,
    system=system_prompt,
    messages=[
        {"role": "user", "content": "Write a script to bulk-transition all open issues in project DEMO to Done."}
    ]
)
```

For longer context (reference files), append them after the system prompt or include them as user-turn content.
