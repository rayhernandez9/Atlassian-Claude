# Using This Skill with Gemini

## Gemini Gems (gemini.google.com)

Gems are custom Gemini configurations with a persistent system prompt, similar to Custom GPTs.

1. Go to [gemini.google.com](https://gemini.google.com)
2. In the left sidebar, click **Gems → New Gem**
3. Give it a name (e.g., "Atlassian Engineer")
4. In the **Instructions** field, paste the full contents of `skill/SYSTEM_PROMPT.md`
5. Click **Save**

Gems don't currently support file uploads as persistent knowledge. For reference files, paste their contents directly into the Instructions field after the system prompt, separated by a heading:

```
[paste SYSTEM_PROMPT.md contents here]

---

## Reference: API Gotchas

[paste api_gotchas.md contents here]
```

**Example prompt to test:**
> "Write a Python script to find all Jira issues in project MYPROJ assigned to a specific user and transition them to Done."

---

## Google AI Studio (System Instructions)

For API-level use or testing, Google AI Studio lets you set system instructions directly.

1. Go to [aistudio.google.com](https://aistudio.google.com)
2. Create a new **Prompt** or open an existing one
3. Click **System Instructions** (top of the prompt editor)
4. Paste the contents of `skill/SYSTEM_PROMPT.md`
5. Optionally, upload `skill/templates/base_script.py` and reference files using the file attachment button

---

## Gemini API (Python SDK)

```python
import google.generativeai as genai
import os

genai.configure(api_key=os.environ["GEMINI_API_KEY"])

with open("skill/SYSTEM_PROMPT.md", "r") as f:
    system_prompt = f.read()

model = genai.GenerativeModel(
    model_name="gemini-1.5-pro",
    system_instruction=system_prompt
)

chat = model.start_chat()
response = chat.send_message(
    "Write a script that bulk-updates the priority of all open Jira issues in project DEMO to High."
)
print(response.text)
```

---

## Including Reference Files

Gemini 1.5 Pro has a 1M token context window, so you can include all reference files inline:

```python
# Load all reference files into context
import os

ref_dir = "skill/references"
reference_content = ""
for fname in os.listdir(ref_dir):
    if fname.endswith(".md"):
        with open(os.path.join(ref_dir, fname)) as f:
            reference_content += f"\n\n## {fname}\n\n" + f.read()

full_system = system_prompt + "\n\n---\n\n# Reference Files\n" + reference_content
```

This is the most effective approach for Gemini — it can reason over the full reference library in one context window.

---

## Notes on Gemini Compatibility

The system prompt uses standard markdown. Gemini handles this natively.

Gemini Gems currently do not support file attachments as persistent knowledge (as of 2025). The workaround — pasting reference content directly into instructions — works well given the large context window.
